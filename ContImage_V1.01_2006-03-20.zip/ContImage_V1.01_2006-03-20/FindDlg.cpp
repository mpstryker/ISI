// FindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "FindDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog

CFindDlg::CFindDlg(CWnd* pParent /*=NULL*/) : CFindReplaceDialog(){
	//{{AFX_DATA_INIT(CFindDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bFindTextOld=FALSE;
	m_bFindDown=TRUE;
	m_hFindBitmaps[0].LoadBitmap(IDB_FIND_MAYBE);
	m_hFindBitmaps[1].LoadBitmap(IDB_FIND_YES);
	m_hFindBitmaps[2].LoadBitmap(IDB_FIND_NO);

}


void CFindDlg::DoDataExchange(CDataExchange* pDX){
	CFindReplaceDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindDlg)
	DDX_Control(pDX, IDC_FIND_BITMAP, m_staticFindBitmap);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindDlg, CFindReplaceDialog)
	//{{AFX_MSG_MAP(CFindDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindDlg message handlers

BOOL CFindDlg::OnInitDialog(){
	CFindReplaceDialog::OnInitDialog();
	
	m_bFindTextOld=TRUE;
	m_bFindStatus=-1;
	ResetState();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFindDlg::OnTextFound(){
	ResetState(1);
	m_bFindTextOld=TRUE;
}

void CFindDlg::OnTextNotFound(){
	ResetState(2);
	m_bFindTextOld=TRUE;
}

BOOL CFindDlg::OnCommand(WPARAM wParam, LPARAM lParam){
	if(m_bFindTextOld && HIWORD(wParam) == EN_UPDATE){
		m_bFindTextOld=FALSE;
		ResetState();
	}
	if(wParam == ID_FIND_DOWN){
		if(!m_bFindDown){
			m_bFindDown=TRUE;
			ResetState();
		}
	}
	if(wParam == ID_FIND_UP){
		if(m_bFindDown){
			m_bFindDown=FALSE;
			ResetState();
		}
	}
	return CFindReplaceDialog::OnCommand(wParam, lParam);
}

void CFindDlg::ResetState(int iState){
	if(m_bFindStatus != iState){ 
		m_staticFindBitmap.SetBitmap((HBITMAP)(m_hFindBitmaps[iState]));
		m_bFindStatus=iState;
	}
}
