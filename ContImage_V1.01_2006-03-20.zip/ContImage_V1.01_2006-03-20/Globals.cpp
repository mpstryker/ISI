// Globals.cpp: global functions.
#include "stdafx.h"
#include "ContImage.h"
//#include "Globals.h"
#include "ContImageView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_PRINT_THREAD_MESSAGE = ::RegisterWindowMessage(_T("UWM_PRINT_THREAD_MESSAGE"));


LRESULT PrintMessage(HWND hWnd, DWORD dwData, HWND hRxWnd, LPCVOID lpData, DWORD cbData){
	if (lpData && ::IsWindow(hWnd)){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = dwData;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = cbData;
		return ::SendMessage(hWnd, WM_COPYDATA, (WPARAM)hRxWnd, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(DWORD dwData, HWND hRxWnd, LPCVOID lpData, DWORD cbData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = dwData;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = cbData;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)hRxWnd, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(DWORD dwData, LPCVOID lpData, DWORD cbData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = dwData;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = cbData;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(DWORD dwData, char* lpData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = dwData;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = strlen(lpData)+1;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

// Debugging PrintMessage

LRESULT PrintMessage(LPCVOID lpData, DWORD cbData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = (DWORD)LEVEL_DEBUG;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = cbData;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

// Debugging lazy PrintMessage

LRESULT PrintMessage(CString* str){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (str->GetLength() && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = (DWORD)LEVEL_DEBUG;
		cd.lpData = (LPVOID)(LPCTSTR)(*str);
		cd.cbData = str->GetLength()+1;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(char* lpData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = (DWORD)LEVEL_DEBUG;
		cd.lpData = (LPVOID)lpData;
		cd.cbData = strlen(lpData)+1;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(int i1,int i2){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (pFrame){
		char str[128];
		sprintf(str,"%i %i\n",i1,i2);
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = (DWORD)LEVEL_DEBUG;
		cd.lpData = (LPVOID)str;
		cd.cbData = strlen(str)+1;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintMessage(RECT r){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (pFrame){
		char str[128];
		sprintf(str,"RECT %i %i %i %i\n",r.left,r.top,r.right-r.left,r.bottom-r.top);
		COPYDATASTRUCT cd;
		::ZeroMemory(&cd, sizeof(COPYDATASTRUCT));
		cd.dwData = (DWORD)LEVEL_DEBUG;
		cd.lpData = (LPVOID)str;
		cd.cbData = strlen(str)+1;
		return ::SendMessage(pFrame->m_hWnd, WM_COPYDATA, (WPARAM)0, (LPARAM)&cd);
	}
	return 0;
}

LRESULT PrintThreadMessage(DWORD dwData, char* lpData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		int i=strlen(lpData)+1;
		char *str = new char[i];
		memcpy(str,lpData,i);
		return ::PostMessage(pFrame->m_hWnd, UWM_PRINT_THREAD_MESSAGE, (WPARAM)dwData, (LPARAM)str);
	}
	return 0;
}

LRESULT PrintThreadMessage(char* lpData){
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (lpData && pFrame){
		int i=strlen(lpData)+1;
		char *str = new char[i];
		memcpy(str,lpData,i);
		return ::PostMessage(pFrame->m_hWnd, UWM_PRINT_THREAD_MESSAGE, (WPARAM)LEVEL_THREAD, (LPARAM)str);
	}
	return 0;
}

LRESULT PrintErrorMessage(char* lpData){
	return PrintMessage(LEVEL_ERROR,lpData);
}

// Other global functions

char NumberToChar(int i){
	if(i<0 || i>=FILENAME_SCHEME_MAX){
		char str[128];
		sprintf(str,"NumberToChar: argument i=%i out of range (0-%i)\n",i,FILENAME_SCHEME_MAX-1);
		PrintThreadMessage(LEVEL_ERROR,str);
//		CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
//		::SendMessage(pFrame->m_hWnd, WM_COMMAND, (WPARAM)ID_SETTINGS_EXPERIMENT, (LPARAM)0);
		return('?');
	}
	else{
		if(i<10) return((char)(i+48));
		else return((char)(i+55));
	}
}

int DataTypeToSizeOf(int iDataType){
	switch(iDataType){
	case DATATYPE_UCHAR:
		return(sizeof(unsigned char));
		break;
	case DATATYPE_USHORT:
		return(sizeof(USHORT));
		break;
	case DATATYPE_ULONG:
		return(sizeof(ULONG));
		break;
	case DATATYPE_FLOAT:
		return(sizeof(FLOAT));
		break;
	default:
		char str[128];
		sprintf(str,"DataTypeToSizeOf: Unknown data type %u",(ULONG)iDataType);
		PrintMessage(LEVEL_ERROR,str);
	}
	return(-1);
}

void* FindChunk(void *pMultiChunk,ULONG ulMultiChunkSize,const char *strName){
	BYTE *pb=(BYTE*)pMultiChunk;
//	char str[64];
	if(!memcmp("ISOI",pb,4)){
		if(!memcmp(strName,"ISOI",4)) return(pMultiChunk);
		pb+=12;
	}
	for(;(pb < (BYTE*)pMultiChunk+ulMultiChunkSize) && memcmp(strName,pb,4);pb+=8+*(ULONG*)(pb+4)){
//		sprintf(str,"Find %c%c%c%c %lu",*pb,*(pb+1),*(pb+2),*(pb+3),*(ULONG*)(pb+4));
//		PrintMessage(str);
	}
	if(pb < (BYTE*)pMultiChunk+ulMultiChunkSize) return((void*)pb);
	else return(NULL);
}


union _LARGE_INTEGER unionLargeInteger;
double dFrequency,dFrequencyUsec;

void SetHighPrecisionClockFrequency(){
	QueryPerformanceFrequency( &unionLargeInteger  );
	dFrequency = (double)unionLargeInteger.LowPart + (((double)unionLargeInteger.HighPart) * 4294967296.) ;
	dFrequencyUsec = dFrequency*1.0e-6;
}

double HighPrecisionClock(){
	QueryPerformanceCounter(&unionLargeInteger);
	return(((double)unionLargeInteger.LowPart + (((double)unionLargeInteger.HighPart) * 4294967296.))/dFrequency);
}

double HighPrecisionClock(_LARGE_INTEGER* pLargeInteger){
	QueryPerformanceCounter(pLargeInteger);
	return(((double)(pLargeInteger->LowPart) + (((double)(pLargeInteger->HighPart)) * 4294967296.))/dFrequency);
}

double HighPrecisionClockUsec(){
	QueryPerformanceCounter(&unionLargeInteger);
	return(((double)unionLargeInteger.LowPart + (((double)unionLargeInteger.HighPart) * 4294967296.))/dFrequencyUsec);
}


BOOL StopGenericThread(HANDLE* phThread,BOOL volatile *pbShutdown,DWORD dwThreadID,
					   const char* strName,HANDLE volatile hEvent /*=NULL*/,int iShutdownType /*=1*/){
	DWORD dwExitCode=0;
	DWORD dwTimeout=1000;
	char str[256];
	if(iShutdownType == 1){
		dwTimeout=INFINITE;
		sprintf(str,"SGT: GenericThread Stop for %s ...",strName);
	}
	else sprintf(str,"SGT: GenericThread Abort for %s ...",strName);
	PrintMessage(str);

	if(!GetExitCodeThread(*phThread, &dwExitCode)){ 
		sprintf(str,"SGT: Cannot get %s Exit Code GetLastError=%lu",strName,GetLastError());
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}

	if(dwExitCode == STILL_ACTIVE){
		*pbShutdown = iShutdownType;
		if(hEvent) SetEvent(hEvent);
		switch(WaitForSingleObject(*phThread,dwTimeout)){
		case WAIT_OBJECT_0:
			sprintf(str,"SGT: %s Signaled",strName);
			PrintMessage(LEVEL_NORMAL,str);
			break;
		case WAIT_TIMEOUT:
			sprintf(str,"SGT: %s Timeout(%imsec)",strName,dwTimeout);
			PrintMessage(LEVEL_NORMAL,str);
			break;
		case WAIT_ABANDONED:
			sprintf(str,"SGT: %s WAIT_ABANDONED",strName);
			PrintMessage(LEVEL_NORMAL,str);
			break;
		case WAIT_FAILED:
			sprintf(str,"SGT: %s WAIT_FAILED",strName);
			PrintMessage(LEVEL_NORMAL,str);
			break;
		default:
			sprintf(str,"SGT: %s default???",strName);
			PrintMessage(LEVEL_NORMAL,str);
		}
		if(!GetExitCodeThread(*phThread, &dwExitCode)){ 
			sprintf(str,"SGT: Cannot get %s Exit Code GetLastError=%lu",strName,GetLastError());
			PrintMessage(LEVEL_ERROR,str);
			return(FALSE);
		}
		sprintf(str,"SGT: %s %lu Exit Code %i",strName,dwThreadID,(int)dwExitCode);
		PrintMessage(LEVEL_NORMAL,str);
	}
	else{
//		sprintf(str,"%s %lu already exited with Exit Code %i",strName,dwThreadID,(int)dwExitCode);
//		PrintMessage(LEVEL_NORMAL,str);
	}

	if(!CloseHandle(*phThread)){
		sprintf(str,"SGT: %s Cannot close handle GetLastError=%lu",strName,GetLastError());
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}
	*phThread = 0;

	return(TRUE);
}

void StorageToSaveUCHAR(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor){
	register ULONG*	pulSrc=pulStorageBuffer;
	register unsigned char*	pucDest=(unsigned char*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pucDest++) *pucDest=(unsigned char)((*pulSrc)/nDivisor);
}

void StorageToSaveUCHARFast(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nShift){
	register ULONG*	pulSrc=pulStorageBuffer;
	register unsigned char*	pucDest=(unsigned char*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pucDest++) *pucDest=(unsigned char)((*pulSrc)>>nShift);
}

void StorageToSaveUSHORT(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor){
	register ULONG*	pulSrc=pulStorageBuffer;
	register USHORT*	pusDest=(USHORT*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pusDest++) *pusDest=(USHORT)((*pulSrc)/nDivisor);
}

void StorageToSaveUSHORTFast(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nShift){
	register ULONG*	pulSrc=pulStorageBuffer;
	register USHORT*	pusDest=(USHORT*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pusDest++) *pusDest=(USHORT)((*pulSrc)>>nShift);
}

void StorageToSaveULONG(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor){
	register ULONG*	pulSrc=pulStorageBuffer;
	register ULONG*	pulDest=(ULONG*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pulDest++) *pulDest=(*pulSrc)>>4;
}

void StorageToSaveFLOAT(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor){
	register ULONG*	pulSrc=pulStorageBuffer;
	register FLOAT*	pfDest=(FLOAT*)pSaveBuffer;
	for(register ULONG i=0;i<nRecords;i++,pulSrc++,pfDest++) *pfDest=(FLOAT)((*pulSrc)>>4);
}

void SlowPowerSpectrum(ULONG ulCount,ULONG *pulBuffer,double *pdSpectrumBuffer,double& dMin,double& dMax){
	double	co,si,coN,siN,CO,SI,CON,SIN,re,im,dumd;
	double	M_PI=4.0*atan(1.0);
	ULONG	ulSpectrumCount=(ulCount-1)/2;
	ULONG	i,k;

	CO=cos(2.0*M_PI/(double)ulCount);
	SI=sin(2.0*M_PI/(double)ulCount);
	CON=1.0;
	SIN=0.0;
	for(k=0;k<ulSpectrumCount;k++){
		co=dumd=CON*CO-SIN*SI;
		si=SIN=SIN*CO+CON*SI;
		CON=dumd;
		coN=1.0; 
		siN=0.0; 
		re=(double)pulBuffer[0];
		im=0.0;
		for(i=1;i<ulCount;i++){
			dumd=coN*co-siN*si;
			siN=siN*co+coN*si;
			coN=dumd;

			dumd=(double)pulBuffer[i];
			re+=dumd*coN;
			im+=dumd*siN;
		}
		pdSpectrumBuffer[k]=log10((re*re+im*im)/ulCount);
		if(k){
			dMin = dMin < pdSpectrumBuffer[k] ? dMin : pdSpectrumBuffer[k];
			dMax = dMax > pdSpectrumBuffer[k] ? dMax : pdSpectrumBuffer[k];
		}
		else{
			dMin = dMax = pdSpectrumBuffer[k];
		}
	}
}

#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)

static long lSeed=666;

void InitSeedRan3(long seed){
	lSeed=seed;
}

double Ran3(){
  static int inext,inextp;
  static long ma[56];
  static int iff=0;
  long mj,mk;
  int i,ii,k;
 
  if (lSeed < 0 || iff==0) {
    iff=1;
    mj = MSEED-(lSeed<0 ? -lSeed:-lSeed);
    mj %= MBIG;
    ma[55]=mj;
    mk=1;
    for (i=1;i<=54;i++){
      ii=(21*i) % 55;
      ma[ii]=mk;
      mk=mj-mk;
      if (mk<MZ) mk+=MBIG;
      mj=ma[ii];
    }
    for (k=1;k<=4;k++)
      for (i=1;i<=55;i++) {
        ma[i]-=ma[1+(i+30) % 55];
        if (ma[i]<MZ) ma[i]+=MBIG;
      }
    inext=0;
    inextp=31;
    lSeed=1;
  }
  if (++inext == 56) inext=1;
  if (++inextp == 56) inextp=1;
  mj=ma[inext]-ma[inextp];
  if (mj<MZ) mj+=MBIG;
  ma[inext]=mj;
  return mj*FAC;
}


// Returns random number from semi-interval [iLo,iHi)
int GetRandomNumber(int iLo,int iHi){
//	int i=rand();
//	PrintMessage(i,iLo+(int)(((double)(iHi-iLo)*(double)(i))/(RAND_MAX+1.0)));
//	return(iLo+(int)(((double)(iHi-iLo)*(double)(i))/(RAND_MAX+1.0)));
	return(iLo+(int)floor((iHi-iLo)*Ran3()));
}

// Shuffles a list of iN integers 
void ShuffleList(int iN, int *piList,int iNewHeadNotEqualOldTail){
	int i, j, temp;

	if(iNewHeadNotEqualOldTail) i=1;
	else i=0;

	temp=piList[0];
	piList[0]=piList[j=GetRandomNumber(0,iN-i)];
	piList[j]=temp;  
//	PrintMessage(j,iNewHeadNotEqualOldTail);

	for( i = 1; i < iN-1; i++){
		temp=piList[i];
		piList[i]=piList[j=GetRandomNumber(i,iN)];
		piList[j]=temp;  
//		PrintMessage(j,iN);
	}
}


ULONG COSTExperimentCallback(WPARAM wParam,LPARAM lParam,double dArrivalTimeUsec){
	if(!lParam){
		PrintThreadMessage("COST reset");
		return(0);
	}
	SYNCH_IN_OUT *pSynchInOut = (SYNCH_IN_OUT *) (((COST_CONTROL*)wParam)->pSynchInOut);
	FRAM_COST_CHUNK *pChunk = (FRAM_COST_CHUNK *)lParam;
	ULONG ulError=0;
//	char str[128];
	for(int i=0;i<pSynchInOut->iNumChannelsIn;i++){
		if(pSynchInOut->ppulValueIn[i]){
      // If the pointer to value on given channel is not NULL
      // we will read the value from the provided memory location
			pChunk->SynchChannel[i]=*(pSynchInOut->ppulValueIn[i]);
			pChunk->SynchChannelDelay[i]=(long)(*(pSynchInOut->ppdTimeInUsec[i])-dArrivalTimeUsec);
//			sprintf(str,"Synch %lu",pChunk->SynchChannel[i]);
//			PrintThreadMessage(str);
		}
		else{
      // If the pointer to value on given channel is NULL
      // we will read the value using the function pointer
			ulError|=pSynchInOut->ppfunSynchIn[i](pChunk->SynchChannel[i]);
			pChunk->SynchChannelDelay[i]=(long)(HighPrecisionClockUsec()-dArrivalTimeUsec);
//			sprintf(str,"Synch %lu",pChunk->SynchChannel[i]);
//			PrintThreadMessage(str);
//			sprintf(str,"Delay %i",pChunk->SynchChannelDelay[i]);
//			PrintThreadMessage(str);
		}
	}
	return(ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT);
}

#define EPST_FRAME_ITI			0
#define EPST_FRAME_STIM			1
#define EPST_FRAME_PRE_STIM		2
#define EPST_FRAME_POST_STIM	3
#define EPST_FRAME_PAUSE		4

#define EPST_COMMAND_START	0x3EUL
#define EPST_COMMAND_STOP	0x3CUL

#define EPST_STAGE_INITIALIZE		0
#define EPST_STAGE_PRE_STIMULUS		1
#define EPST_STAGE_STIMULUS			2
#define EPST_STAGE_POST_STIMULUS	3
#define EPST_STAGE_FINISHED			4

ULONG EPSTExperimentCallback(WPARAM wParam,LPARAM lParam,double dArrivalTimeUsec){
	char str[256];
	static ULONG ulNConditions;
	static ULONG ulNRepetitions;
	static ULONG ulRandomize;
	static ULONG ulNFramesITI;
	static ULONG ulNFramesStim;
	static ULONG ulNFramesTotal;
	static ULONG ulNFramesBlankPre;
	static ULONG ulNFramesBlankPost;
	static ULONG ulNFramesCondition;

	static ULONG ulExperimentStage=EPST_STAGE_INITIALIZE; 
	static ULONG ulCurrentBlankFrame=0;
	static ULONG ulCurrentFrame=0; // Not paused frame counter. Trigger Thread sets frame counter
	static ULONG ulCurrentRepetition=0;
	static ULONG ulCurrentTrial=0; // Sequantial
	static ULONG ulCurrentCondition=0;  // Identical to ulCurrentTrial for ulRandomize=0
	static ULONG ulCurrentFrameOfCondition=0;
	static BOOL	bPaused=FALSE;
	static BOOL	bPauseWhenAble=FALSE;
	static ULONG ulCommand=0;
	static ULONG ulFrameCount=0;
	ULONG ulError=0;

	SYNCH_IN_OUT *pSynchInOut = (SYNCH_IN_OUT *) (((EPST_CONTROL*)wParam)->pSynchInOut);
	EPST_CHUNK *pEPSTChunk = NULL;

	if(!lParam){
		// Reset variables
		ulExperimentStage = EPST_STAGE_INITIALIZE;
		ulCurrentBlankFrame = 0;
		ulCurrentFrame = 0;
		ulCurrentRepetition = 0;
		ulCurrentTrial = 0;
		ulCurrentCondition = 0;
		ulCurrentFrameOfCondition = 0;
		bPaused=FALSE;
		ulFrameCount=0;

//		RUNSTART;
		ulError|=pSynchInOut->ppfunSynchOut[0](EPST_COMMAND_START);

		PrintThreadMessage("EPST variables reset");
		return(ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT);
	}

	FRAM_EPST_CHUNK *pChunk = (FRAM_EPST_CHUNK *)lParam;

	ulFrameCount++;

	// Set FramePaused chunk entry
	if((pChunk->FramePaused=*(((EPST_CONTROL*)wParam)->pbPause))){
		if(bPaused){
			pChunk->FrameType = EPST_FRAME_PAUSE;
			return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_PAUSED);
		}
	}
	else{
		if(bPaused){
			if((ulFrameCount-1)%((EPST_CONTROL*)wParam)->ulTemporalBinning){
				pChunk->FrameType = EPST_FRAME_PAUSE;
				return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_PAUSED);
			}
			else bPaused=FALSE;
		}
	}

	switch(ulExperimentStage){
	case EPST_STAGE_INITIALIZE:
		// Reset parameters

		ulExperimentStage++;

		ulNConditions = ((EPST_CONTROL*)wParam)->ulNConditions;
		ulNRepetitions = ((EPST_CONTROL*)wParam)->ulNRepetitions;
		ulRandomize = ((EPST_CONTROL*)wParam)->ulRandomize;
		ulNFramesITI = ((EPST_CONTROL*)wParam)->ulNFramesITI;
		ulNFramesStim = ((EPST_CONTROL*)wParam)->ulNFramesStim;
		ulNFramesBlankPre = ((EPST_CONTROL*)wParam)->ulNFramesBlankPre;
		ulNFramesBlankPost = ((EPST_CONTROL*)wParam)->ulNFramesBlankPost;

		ulNFramesTotal = ulNFramesITI+ulNFramesStim;
		ulNFramesCondition = ulNFramesTotal*ulNConditions;

		PrintThreadMessage("EPST Parameters reset");

	case EPST_STAGE_PRE_STIMULUS:
		if(ulNFramesBlankPre){
			pChunk->FrameType = EPST_FRAME_PRE_STIM;
			// Send PCV commands here
			if(++ulCurrentBlankFrame == ulNFramesBlankPre){
				ulCurrentBlankFrame=0;
				ulExperimentStage++;
				sprintf(str,"EPST Finished PRE_STIMULUS stage (%lu)",ulNFramesBlankPre);
				PrintThreadMessage(str);
			}
			return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_RUNNING);
		}
		else{
			ulExperimentStage++;
			PrintThreadMessage("EPST No PRE_STIMULUS stage");
		}
	case EPST_STAGE_STIMULUS:
		if(!(ulCurrentFrameOfCondition = ulCurrentFrame%ulNFramesTotal)){
			if(pChunk->FramePaused){ 
				bPaused=TRUE;
				PrintThreadMessage("EXPERIMENT PAUSED");
				return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_PAUSED);
			}
			int *piConditionList=(int *) ((EPST_CONTROL*)wParam)->piConditionList;
			if(!(ulCurrentTrial = (ulCurrentFrame/ulNFramesTotal)%ulNConditions)){
				ulCurrentRepetition=(ulCurrentFrame/ulNFramesTotal)/ulNConditions;
				if(ulRandomize) ShuffleList((int)ulNConditions, piConditionList,ulCurrentFrame);
				PrintThreadMessage("\n");
			}
//			TTLSTOP;
			ulError|=pSynchInOut->ppfunSynchOut[0](ulCurrentCondition<<1);

			ulCurrentCondition = piConditionList[ulCurrentTrial];

//			TTLSET_CONDITION(cond);
			ulError|=pSynchInOut->ppfunSynchOut[0](ulCurrentCondition<<1);
		}

		// Set all other chunk entry
		pChunk->SeqNumber = ulCurrentFrame;						//03 03 sequence number 0,1,2,...NOT including paused frames
		pChunk->Repetition = ulCurrentRepetition;				//04 04 repetition number of this cycle
		pChunk->Trial = ulCurrentTrial;							//05 05 sequential number of stimulus in this cycle
		pChunk->Condition = ulCurrentCondition;					//06 06 stimulus number
		pChunk->FrameOfCondition = ulCurrentFrameOfCondition;	//07 07 which frame in relation to start of stimulus
//		pChunk->FramePaused;									//08 08 BOOL variable, marks paused frames(=1[actually !=0])

		if(ulCurrentFrameOfCondition<ulNFramesITI) pChunk->FrameType = EPST_FRAME_ITI;
		else{
			pChunk->FrameType = EPST_FRAME_STIM;				//09 09 frame type, iti and stim for now
			if(ulCurrentFrameOfCondition==ulNFramesITI){
//				TTLGO;
				ulError|=pSynchInOut->ppfunSynchOut[0]((ulCurrentCondition<<1) | 0x1UL);
			}
		}

	// Report variables' values
			sprintf(str,"EPST: Frame=%.04d Rep=%.02d Trial=%.02d Cond=%.02d FoC=%.02lu Type=%lu",
				ulCurrentFrame,ulCurrentRepetition,ulCurrentTrial,ulCurrentCondition,ulCurrentFrameOfCondition,pChunk->FrameType);       
		if(!ulCurrentFrameOfCondition || ulCurrentFrameOfCondition==ulNFramesITI){
			PrintThreadMessage(str);
		}

		ulCurrentFrame++;

		if((ulCurrentFrame/ulNFramesTotal)/ulNConditions == ulNRepetitions){ 
//			TTLSTOP;
			ulError|=pSynchInOut->ppfunSynchOut[0](ulCurrentCondition<<1);
//			RUNSTOP;
			ulError|=pSynchInOut->ppfunSynchOut[0](EPST_COMMAND_STOP);

			ulExperimentStage++;

			if(ulNFramesBlankPost){
				return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_RUNNING);
			}
			else{
				ulExperimentStage++;
				PrintThreadMessage("EPST No POST_STIMULUS stage");
				return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_FINISHED);
			}
		}
		else return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_RUNNING);
	case EPST_STAGE_POST_STIMULUS:
		if(ulNFramesBlankPost){
			pChunk->FrameType = EPST_FRAME_POST_STIM;
			// Send PCV commands here
			if(++ulCurrentBlankFrame == ulNFramesBlankPost){
				ulCurrentBlankFrame=0;
				ulExperimentStage++;
				sprintf(str,"EPST Finished POST_STIMULUS stage (%lu)",ulNFramesBlankPost);
				PrintThreadMessage(str);
				return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_FINISHED);
			}
			return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_RUNNING);
		}
		else{
			ulExperimentStage++;
			PrintThreadMessage("EPST No POST_STIMULUS stage");
			return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_FINISHED);
		}
	default:
		PrintThreadMessage("EPST Unknown stage");
		ulError|=16;
		return((ulError<<EXPERIMENT_MESSAGE_ERROR_SHIFT) | EXPERIMENT_MESSAGE_FINISHED);	
	}

	// Main Loop  
/*
	for(kf=0,kf_all=0,time_binned_count=0; kf < corrected_number_frames; kf++,kf_all++) {

		rep = kf/ntrials_times_nframes;
		tr = (kf/nframes) % ntrials;
		fr  = kf%nframes;
		fr_all  = kf_all%nframes;

		pparams->pframehead->seqnum=(unsigned long)kf;
		pparams->pframehead->seqnum_all=(long)kf_all;
		pparams->pframehead->frame_of_cond=(long)fr;

		if( !(kf%ntrials_times_nframes) ){ 
			if (shd.sumRandomize)  ranlst1(ntrials,condlist);
			pparams->pframehead->rep=(long)rep;
		}

		// detect pause switch on control box 
   		TTLGET_CH ( &trigin ) ;
		if( trigin & CHIN_PAUSE ) { 
			if(!experiment_pause_on_from_switch){
				experiment_pause_on_from_switch=TRUE;
				experiment_pause_on_from_soft=FALSE;
				CheckMenuItem(hMenuNun,IDM_EXPERIMENT_PAUSE,MF_CHECKED);
				MonitorBox("ECT: Experiment pause from switch","");
			}
		}
		else{
			if(experiment_pause_on_from_switch){
				experiment_pause_on_from_switch=FALSE;
				experiment_pause_on_from_soft=FALSE;
				CheckMenuItem(hMenuNun,IDM_EXPERIMENT_PAUSE,MF_UNCHECKED);
				MonitorBox("ECT: Experiment resume from switch","");
			}
		}

		if(!fr_all){
			if(experiment_pause_on_from_switch || experiment_pause_on_from_soft){
				experiment_pause_on=TRUE;
			}
			else{
				experiment_pause_on=FALSE;
			}
			ExperimentPause(*pparams->hwnd);
			pparams->pframehead->frame_paused=(long)experiment_pause_on;
		}		

		if(!fr){
			if(experiment_pause_on){
				kf--;
				to_be_written_frame_count++;
			}
			else{
				cond = condlist[tr];
				pparams->pframehead->condition=(long)cond;
				pparams->pframehead->trial=(long)tr;
				pparams->pframehead->frame_type=FRAME_ITI;
				TTLSTOP;
				TTLSET_CONDITION(cond);
			}
		}

		if(fr == nframeiti){
			pparams->pframehead->frame_type=FRAME_STIM;
			TTLGO;
		}
		sprintf(str,"ECT: ft=%d kf=%.03d re=%.02d tr=%.02d co=%.02d fr=%.02d/%i",
			pparams->pframehead->frame_type,kf,rep,tr,cond,fr,pparams->pframehead->frame_paused);       
		MonitorBox(str,"");
		if(fpexperiment_log_file != NULL) fflush(fpexperiment_log_file);


		TTLGET_B(&b_in);
		pparams->pframehead->synch_in=(unsigned long)(b_in & 0xFE);

	} // End of main loop 

*/
}

int WritePhysicalPortA(ULONG ulData){
	return(cbDOut(BOARD_NUM, FIRSTPORTA, (USHORT)(ulData&0xFF)));
}

int WritePhysicalPortCL(ULONG ulData){
	return(cbDOut(BOARD_NUM, FIRSTPORTCL, (USHORT)(ulData&0xF)));
}

int ReadPhysicalPortB(ULONG& ulData){
	USHORT usData;
	int iError=cbDIn(BOARD_NUM,FIRSTPORTB,&usData);
	ulData=usData&0xFF;
	return(iError);
}

int ReadPhysicalPortCH(ULONG& ulData){
	USHORT usData;
	int iError=cbDIn(BOARD_NUM,FIRSTPORTCH,&usData);
	ulData=usData&0xF;
	return(iError);
}
