#if !defined(AFX_ROIDLG_H__07ACF8D3_0001_4373_AB7A_4D20166E1DE7__INCLUDED_)
#define AFX_ROIDLG_H__07ACF8D3_0001_4373_AB7A_4D20166E1DE7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ROIDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CROIDlg dialog

class CROIDlg : public CDialog
{
// Construction
public:
	CROIDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CROIDlg)
	enum { IDD = IDD_ROI_DIALOG };
	CListCtrl	m_ROIListCtrl;
	BOOL	m_bKeepOriginalNumbers;
	BOOL	m_bMaximizeNewNumbers;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CROIDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

public:

	CROI *m_pCROI;
	
protected:

	CImageList m_ROIImages;

	enum{
		COLUMN_INDEX = 0,
		COLUMN_NUMBER,
		COLUMN_LEFT,
		COLUMN_RIGHT,
		COLUMN_SIZEX,
		COLUMN_TOP,
		COLUMN_BOTTOM,
		COLUMN_SIZEY,
		COLUMN_LAST,
	};

	// Generated message map functions
	//{{AFX_MSG(CROIDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnRoiKeepOriginalNumbers();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ROIDLG_H__07ACF8D3_0001_4373_AB7A_4D20166E1DE7__INCLUDED_)
