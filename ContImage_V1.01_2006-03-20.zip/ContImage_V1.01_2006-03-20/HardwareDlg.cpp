// HardwareDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "HardwareDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DWORD UsableLinesPerFrame[N_VERTICAL_BINNING]={ // =1024/Vbinning
	1024,//1024,
	512,//512,
	340,//341,
	256,//256,
	204,//204,
	168,//170,
	144,//146,
	128 //128
};

DWORD HorizontalOffset[N_VERTICAL_BINNING]={
	26,//25-32
	16,//15-18
	14,//13-16
	11,//10-11
	11,//11
	12,//11-12
	11,//10-11
	8//8
};

DWORD VerticalOffset[N_VERTICAL_BINNING]={
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
};

float MaxFrameRates[N_VERTICAL_BINNING]={ 
	30.0,
	54.0,
	72.0,
	88.0,
	101.0,
	112.0,
	122.0,
	129.0
};

/////////////////////////////////////////////////////////////////////////////
// CHardwareDlg dialog


CHardwareDlg::CHardwareDlg(CWnd* pParent /*=NULL*/)	: CDialog(CHardwareDlg::IDD, pParent){
	//{{AFX_DATA_INIT(CHardwareDlg)
	m_dwHardwareBinning = 1;
	m_dwHardwareGain = 1;
	m_lHardwareOffset = 0;
	m_dHardwareFrameRate = 0.0;
	m_dwHardwareIntegrationTime = 0;
	m_dwHardwareInterFrameTime = 0;
	m_dwHardwareResolution = 0;
	m_fHardwareMaxFrameRate = MaxFrameRates[N_VERTICAL_BINNING-1];
	m_dwHardwareMaxInterFrameTime = 0x3ffff;
	m_dwHardwareMinInterFrameTime = 0;
	m_iTotalPhysicalMB = 0;
	m_iAvailablePhysicalMB = 0;
	m_nPhysicalMemoryUsageMB = 0;
	m_iPhysicalMemoryUsagePercent = 0;
	m_iRadioMemoryAllocationOption = -1;
	m_nPhysicalMemoryUsageFrames = 1;
	//}}AFX_DATA_INIT
	m_fHardwareMinFrameRate = (float)(1.0e+6/(double)m_dwHardwareMaxInterFrameTime);
	m_bHardwareResetCamera = FALSE;
	m_ulMaxFrames = 65536;
	m_bDisableAll=FALSE;
}


void CHardwareDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHardwareDlg)
	DDX_Control(pDX, IDC_RESET_TO_DEFAULTS, m_buttonResetToDefaults);
	DDX_Control(pDX, IDCANCEL, m_buttonCancel);
	DDX_Control(pDX, IDC_HARDWARE_MAX_INTEGARTION_TIME, m_buttonHardwareMaxIntegrationTime);
	DDX_Text(pDX, IDC_HARDWARE_BINNING, m_dwHardwareBinning);
	DDV_MinMaxDWord(pDX, m_dwHardwareBinning, 1, 8);
	DDX_Text(pDX, IDC_HARDWARE_GAIN, m_dwHardwareGain);
	DDV_MinMaxDWord(pDX, m_dwHardwareGain, 1, 10);
	DDX_Text(pDX, IDC_HARDWARE_OFFSET, m_lHardwareOffset);
	DDV_MinMaxLong(pDX, m_lHardwareOffset, -4095, 4095);
	DDX_Text(pDX, IDC_HARDWARE_FRAME_RATE, m_dHardwareFrameRate);
	DDV_MinMaxFloat(pDX, (float)m_dHardwareFrameRate, m_fHardwareMinFrameRate, m_fHardwareMaxFrameRate);
	DDX_Text(pDX, IDC_HARDWARE_INTEGRATION_TIME, m_dwHardwareIntegrationTime);
	DDX_Text(pDX, IDC_HARDWARE_INTERFRAME_TIME, m_dwHardwareInterFrameTime);
	DDV_MinMaxDWord(pDX, m_dwHardwareInterFrameTime, m_dwHardwareMinInterFrameTime, m_dwHardwareMaxInterFrameTime);
	DDX_Text(pDX, IDC_HARDWARE_RESOLUTION, m_dwHardwareResolution);
	DDX_Text(pDX, IDC_HARDWARE_MAX_FRAME_RATE, m_fHardwareMaxFrameRate);
	DDX_Text(pDX, IDC_HARDWARE_MAX_INTERFRAME_TIME, m_dwHardwareMaxInterFrameTime);
	DDX_Text(pDX, IDC_HARDWARE_MIN_INTERFRAME_TIME, m_dwHardwareMinInterFrameTime);
	DDX_Text(pDX, IDC_MEMORY_PHYSICAL_TOTAL, m_iTotalPhysicalMB);
	DDX_Text(pDX, IDC_MEMORY_PHYSICAL_AVAILABLE, m_iAvailablePhysicalMB);
	DDX_Text(pDX, IDC_MEMORY_PHYSICAL_USAGE, m_nPhysicalMemoryUsageMB);
	DDX_Text(pDX, IDC_MEMORY_USAGE_PERCENT, m_iPhysicalMemoryUsagePercent);
	DDV_MinMaxInt(pDX, m_iPhysicalMemoryUsagePercent, 0, 100);
	DDX_Radio(pDX, IDC_RADIO_MEMORY_FRAMES, m_iRadioMemoryAllocationOption);
	DDX_Text(pDX, IDC_MEMORY_USAGE_FRAMES, m_nPhysicalMemoryUsageFrames);
	DDV_MinMaxUInt(pDX, m_nPhysicalMemoryUsageFrames, 1, m_ulMaxFrames);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHardwareDlg, CDialog)
	//{{AFX_MSG_MAP(CHardwareDlg)
	ON_BN_CLICKED(IDC_HARDWARE_MAX_INTEGARTION_TIME, OnHardwareMaxIntegrationTime)
	ON_WM_PAINT()
	ON_EN_KILLFOCUS(IDC_HARDWARE_BINNING, OnKillfocusHardwareBinning)
	ON_BN_CLICKED(IDC_RESET_TO_DEFAULTS, OnResetToDefaults)
	ON_EN_KILLFOCUS(IDC_HARDWARE_INTEGRATION_TIME, OnKillfocusHardwareIntegrationTime)
	ON_EN_KILLFOCUS(IDC_MEMORY_USAGE_FRAMES, OnKillfocusMemoryUsageFrames)
	ON_EN_KILLFOCUS(IDC_MEMORY_USAGE_PERCENT, OnKillfocusMemoryUsagePercent)
	//}}AFX_MSG_MAP
	ON_CONTROL_RANGE(EN_KILLFOCUS, IDC_HARDWARE_INTERFRAME_TIME, IDC_HARDWARE_FRAME_RATE, OnKillfocusInterFrameTimeAndFrameRate)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_RADIO_MEMORY_FRAMES, IDC_RADIO_MEMORY_AVAILABLE, OnUpdateMemoryAllocationOption)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHardwareDlg message handlers

BOOL CHardwareDlg::OnInitDialog(){
	CDialog::OnInitDialog();
	BOOL bHardwareMaxIntegrationTime = (m_dwHardwareIntegrationTime == m_dwHardwareInterFrameTime-m_dwHardwareMinDataShiftTime);
	m_buttonHardwareMaxIntegrationTime.SetCheck(bHardwareMaxIntegrationTime);
	GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->EnableWindow(!bHardwareMaxIntegrationTime);
	
	m_ulAllowedPhysicalB = m_ulTotalPhysicalB < m_ulAvailablePhysicalB ? m_ulTotalPhysicalB : m_ulAvailablePhysicalB;
	m_iTotalPhysicalMB = (int)(m_ulTotalPhysicalB>>20);
	m_iAvailablePhysicalMB = (int)(m_ulAvailablePhysicalB>>20);
	CalculateHardwareBinning();

	GetDlgItem(IDC_MEMORY_USAGE_FRAMES)->EnableWindow(!m_iRadioMemoryAllocationOption);
	GetDlgItem(IDC_MEMORY_USAGE_PERCENT)->EnableWindow(m_iRadioMemoryAllocationOption);

	UpdateData(FALSE);

	DisableAll(m_bDisableAll);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CHardwareDlg::OnHardwareMaxIntegrationTime(){
	if(m_buttonHardwareMaxIntegrationTime.GetCheck()){
		UpdateData (TRUE);
		m_dwHardwareIntegrationTime = m_dwHardwareInterFrameTime - m_dwHardwareMinDataShiftTime;
		GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->EnableWindow(FALSE);
		UpdateData(FALSE);
	}
	else{
		GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->EnableWindow(TRUE);
	}	
}
	
void CHardwareDlg::OnKillfocusInterFrameTimeAndFrameRate(UINT nID){
	if(m_buttonCancel.GetState() == 0x70 || m_buttonResetToDefaults.GetState() == 0x70) return;
	if(!UpdateData (TRUE)) return;
	if(nID == IDC_HARDWARE_FRAME_RATE){
		m_dwHardwareInterFrameTime=(DWORD)(1.0e+6/m_dHardwareFrameRate);
	}
	if(nID == IDC_HARDWARE_INTERFRAME_TIME){
		m_dHardwareFrameRate=1.0e-2*floor(1.0e+8/(double)m_dwHardwareInterFrameTime);
	}
	if(m_buttonHardwareMaxIntegrationTime.GetCheck()){
		m_dwHardwareIntegrationTime = m_dwHardwareInterFrameTime - m_dwHardwareMinDataShiftTime;
	}
	UpdateData (FALSE);
}
	
void CHardwareDlg::CalculateInterFrameTimeAndFrameRate(UINT nID){
	if(nID == IDC_HARDWARE_FRAME_RATE){
		m_dwHardwareInterFrameTime=(DWORD)(1.0e+6/m_dHardwareFrameRate);
	}
	if(nID == IDC_HARDWARE_INTERFRAME_TIME){
		m_dHardwareFrameRate=1.0e-2*floor(1.0e+8/(double)m_dwHardwareInterFrameTime);
	}
	if(m_buttonHardwareMaxIntegrationTime.GetCheck()){
		m_dwHardwareIntegrationTime = m_dwHardwareInterFrameTime - m_dwHardwareMinDataShiftTime;
	}
}

void CHardwareDlg::OnKillfocusHardwareBinning(){
	if(m_buttonCancel.GetState() == 0x70 || m_buttonResetToDefaults.GetState() == 0x70) return;
	if(!UpdateData (TRUE)) return;
	CalculateHardwareBinning();
	UpdateData (FALSE);	
}

void CHardwareDlg::CalculateHardwareBinning(){
	CalculateFrameSize();
	m_fHardwareMaxFrameRate	= (float)(0.1*floor(10.0*(double)MaxFrameRates[m_dwHardwareBinning-1]));
	m_dwHardwareMinInterFrameTime=(DWORD)(1.0e+6/(double)m_fHardwareMaxFrameRate);
	if(m_dHardwareFrameRate > m_fHardwareMaxFrameRate){
		m_dHardwareFrameRate = m_fHardwareMaxFrameRate;
		m_dwHardwareInterFrameTime = m_dwHardwareMinInterFrameTime;
	}
	CalculateInterFrameTimeAndFrameRate(IDC_HARDWARE_INTERFRAME_TIME);
}

void CHardwareDlg::OnKillfocusHardwareIntegrationTime(){
	if(	m_buttonCancel.GetState() == 0x70 || 
		m_buttonResetToDefaults.GetState() == 0x70 || 
		m_buttonHardwareMaxIntegrationTime.GetState() == 0x70) return;
	UpdateData (TRUE);
	if(m_dwHardwareIntegrationTime < 1 || m_dwHardwareIntegrationTime > m_dwHardwareInterFrameTime-m_dwHardwareMinDataShiftTime){
		GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->SetFocus();
		return;
	}	
}

void CHardwareDlg::OnResetToDefaults(){
	m_bHardwareResetCamera = TRUE;
	m_dwHardwareBinning = 1;
	m_dwHardwareResolution	= UsableLinesPerFrame[m_dwHardwareBinning-1];
	m_fHardwareMaxFrameRate	= MaxFrameRates[m_dwHardwareBinning-1];
	m_dwHardwareMinInterFrameTime = (DWORD)(1.0e+6/(double)m_fHardwareMaxFrameRate);
	m_dwHardwareGain = 1;
	m_lHardwareOffset = 0;
	m_dwHardwareInterFrameTime = 33333;
	m_dHardwareFrameRate = 1.0e-2*floor(1.0e+8/(double)m_dwHardwareInterFrameTime);
	m_buttonHardwareMaxIntegrationTime.SetCheck(TRUE);
	m_dwHardwareIntegrationTime = m_dwHardwareInterFrameTime - m_dwHardwareMinDataShiftTime;
	GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->EnableWindow(FALSE);
	UpdateData (FALSE);	
}

void CHardwareDlg::OnUpdateMemoryAllocationOption(UINT nID){
	GetDlgItem(IDC_MEMORY_USAGE_FRAMES)->EnableWindow(nID == IDC_RADIO_MEMORY_FRAMES);
	GetDlgItem(IDC_MEMORY_USAGE_PERCENT)->EnableWindow(nID != IDC_RADIO_MEMORY_FRAMES);
	UpdateData(TRUE);
	CalculateMaxFrames();
	UpdateData(FALSE);
}

void CHardwareDlg::OnKillfocusMemoryUsageFrames(){
	if(m_buttonCancel.GetState() == 0x70 || m_buttonResetToDefaults.GetState() == 0x70) return;
	UpdateData (TRUE);
	CalculateMaxFrames();
	UpdateData (FALSE);	
}

void CHardwareDlg::OnKillfocusMemoryUsagePercent(){
	if(m_buttonCancel.GetState() == 0x70 || m_buttonResetToDefaults.GetState() == 0x70) return;
	UpdateData (TRUE);
	CalculateMaxFrames();
	UpdateData (FALSE);	
}

void CHardwareDlg::CalculateFrameSize(){
	m_dwHardwareResolution	= UsableLinesPerFrame[m_dwHardwareBinning-1];
	m_ulFrameSizeB = 2*m_dwHardwareResolution*(1024/m_dwHardwareBinning);
	CalculateMaxFrames();
}

void CHardwareDlg::CalculateMaxFrames(){
	switch(m_iRadioMemoryAllocationOption){
	case 0:
		m_ulMaxFrames = m_ulAllowedPhysicalB/m_ulFrameSizeB;
		m_nPhysicalMemoryUsageFrames = m_nPhysicalMemoryUsageFrames < m_ulMaxFrames ? m_nPhysicalMemoryUsageFrames : m_ulMaxFrames;
		m_ulPhysicalMemoryUsageB = (UINT)(m_ulFrameSizeB*m_nPhysicalMemoryUsageFrames);	
		m_iPhysicalMemoryUsagePercent = (int)((100.0*m_ulPhysicalMemoryUsageB)/m_ulAllowedPhysicalB);
		break;
	case 1:
		m_ulMaxFrames = m_ulTotalPhysicalB/m_ulFrameSizeB;
		m_iPhysicalMemoryUsagePercent = m_iPhysicalMemoryUsagePercent < 100 ? m_iPhysicalMemoryUsagePercent : 100;
		m_ulPhysicalMemoryUsageB = (UINT)(m_ulTotalPhysicalB*0.01*m_iPhysicalMemoryUsagePercent);
		m_nPhysicalMemoryUsageFrames = m_ulPhysicalMemoryUsageB/m_ulFrameSizeB;
		break;
	case 2:
		m_ulMaxFrames = m_ulAvailablePhysicalB/m_ulFrameSizeB;
		m_iPhysicalMemoryUsagePercent = m_iPhysicalMemoryUsagePercent < 100 ? m_iPhysicalMemoryUsagePercent : 100;
		m_ulPhysicalMemoryUsageB = (UINT)(m_ulAvailablePhysicalB*0.01*m_iPhysicalMemoryUsagePercent);
		m_nPhysicalMemoryUsageFrames = m_ulPhysicalMemoryUsageB/m_ulFrameSizeB;
		break;
	default:
		return;
	}
	m_nPhysicalMemoryUsageMB=m_ulPhysicalMemoryUsageB>>20;
}

void CHardwareDlg::DisableAll(BOOL bDisable){
	if(bDisable){
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_INTERFRAME_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_FRAME_RATE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_MAX_INTEGARTION_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_BINNING)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_GAIN)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_OFFSET)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_RESOLUTION)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_MAX_FRAME_RATE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_MAX_INTERFRAME_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_HARDWARE_MIN_INTERFRAME_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_RESET_TO_DEFAULTS)->EnableWindow(FALSE);
		GetDlgItem(IDC_MEMORY_PHYSICAL_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_MEMORY_PHYSICAL_AVAILABLE)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_MEMORY_FRAMES)->EnableWindow(FALSE);

		GetDlgItem(IDC_RADIO_MEMORY_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_MEMORY_AVAILABLE)->EnableWindow(FALSE);
		GetDlgItem(IDC_MEMORY_USAGE_FRAMES)->EnableWindow(FALSE);
		GetDlgItem(IDC_MEMORY_USAGE_PERCENT)->EnableWindow(FALSE);
		GetDlgItem(IDC_MEMORY_PHYSICAL_USAGE)->EnableWindow(FALSE);

	}
}

void CHardwareDlg::OnPaint(){
	CPaintDC dc(this); // device context for painting
	
	CRect r1,r2;
	CPoint p1,p2,pa=CPoint(6,2);

	CPen *hPen = new CPen(PS_SOLID | PS_JOIN_BEVEL | PS_ENDCAP_ROUND,1,RGB(0,0,255));
	dc.SelectObject(hPen);

	GetDlgItem(IDC_HARDWARE_FRAME_RATE)->GetWindowRect(&r1);
	ScreenToClient(&r1);
	p1.x=r1.left;
	p1.y=(r1.top+r1.bottom)/2;

	GetDlgItem(IDC_HARDWARE_INTERFRAME_TIME)->GetWindowRect(&r2);
	ScreenToClient(&r2);
	p2.x=r2.right;
	p2.y=(r2.top+r2.bottom)/2;
	
	dc.MoveTo(p1);
	dc.LineTo(p2);
	p1.x-=1;
	p2.x+=1;
	dc.MoveTo(p2);
	dc.LineTo(p2.x+pa.x,p2.y-pa.y);
	dc.MoveTo(p2);
	dc.LineTo(p2.x+pa.x,p2.y+pa.y);
	dc.MoveTo(p1);
	dc.LineTo(p1.x-pa.x,p1.y-pa.y);
	dc.MoveTo(p1);
	dc.LineTo(p1.x-pa.x,p1.y+pa.y);

	GetDlgItem(IDC_HARDWARE_MAX_INTEGARTION_TIME)->GetWindowRect(&r1);
	ScreenToClient(&r1);
	p1.x=(r1.left+r1.right)/2;
	p1.y=r1.top;
	p2.x=r2.left;
	p2.y=(r2.top+r2.bottom)/2;

	dc.MoveTo(p2);
	dc.LineTo(p1.x,p2.y);
	dc.LineTo(p1);

	GetDlgItem(IDC_HARDWARE_INTEGRATION_TIME)->GetWindowRect(&r2);
	ScreenToClient(&r2);

	p1.y=r1.bottom;
	p2.x=r2.left;
	p2.y=(r2.top+r2.bottom)/2;

	dc.MoveTo(p2);
	dc.LineTo(p1.x,p2.y);
	dc.LineTo(p1);

	// Arrow head
	p2.x-=1;

	dc.MoveTo(p2);
	dc.LineTo(p2.x-pa.x,p2.y-pa.y);
	dc.MoveTo(p2);
	dc.LineTo(p2.x-pa.x,p2.y+pa.y);

	delete(hPen);
}


