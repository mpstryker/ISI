// MonitorBox.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "MonitorBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_ON_FIND_TEXT_IN_MONITORBOX = ::RegisterWindowMessage(FINDMSGSTRING);

static const UINT UWM_ON_NULL_ERROR_COUNT = ::RegisterWindowMessage(_T("UWM_ON_NULL_ERROR_COUNT"));
static const UINT UWM_ON_FIND_TEXT_DIALOG = ::RegisterWindowMessage(_T("UWM_ON_FIND_TEXT_DIALOG"));
static const UINT UWM_ON_EMPTY_MONITOR_BOX = ::RegisterWindowMessage(_T("UWM_ON_EMPTY_MONITOR_BOX"));

/////////////////////////////////////////////////////////////////////////////
// CMonitorBox

CMonitorBox::CMonitorBox(){
	m_hFont = NULL;
    m_nStartChar = 0;
    m_nStopChar = 0;
	m_iErrorCount = 0;
	m_iWarningCount = 0;
	m_bLogFileOpened = FALSE;
	m_fpLogFile = NULL;
}

CMonitorBox::~CMonitorBox(){
}


BEGIN_MESSAGE_MAP(CMonitorBox, baseCMonitorBox)
	//{{AFX_MSG_MAP(CMonitorBox)
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE( UWM_ON_FIND_TEXT_IN_MONITORBOX, OnFindText )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMonitorBox drawing


/////////////////////////////////////////////////////////////////////////////
// CMonitorBox message handlers

int CMonitorBox::OnCreate(LPCREATESTRUCT lpCreateStruct){
	if (baseCMonitorBox::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	SetSCBStyle(GetSCBStyle() | SCBS_SHOWEDGES | SCBS_SIZECHILD);

	if (!m_wndChild.Create(
		WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL |
		ES_MULTILINE | ES_WANTRETURN | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
		CRect(0,0,0,0), this, 123))
		return -1;

	DWORD dwBGColor=0x00000000;
	m_wndChild.ModifyStyleEx(0, WS_EX_CLIENTEDGE);
	m_wndChild.SetBackgroundColor(FALSE,dwBGColor);
	CFont font;
	if(font.CreatePointFont(80, "MS Sans Serif")) m_hFont = (HFONT)font.Detach();
	m_wndChild.SendMessage(WM_SETFONT,(WPARAM)m_hFont,TRUE);

	m_wndChild.GetSelectionCharFormat(m_cfDebug);
	m_cfDebug.dwEffects = 0;
	m_cfDebug.crTextColor=RGB(0,200,0);
	m_cfDebug.dwMask = CFM_COLOR;

	m_wndChild.GetSelectionCharFormat(m_cfLow);
	m_cfLow.dwEffects = 0;
	m_cfLow.crTextColor=RGB(0,0,255);
	m_cfLow.dwMask = CFM_COLOR;

	m_wndChild.GetSelectionCharFormat(m_cfNormal);
	m_cfNormal.dwEffects = 0;
	m_cfNormal.crTextColor=0x00ffffff ^ dwBGColor;
	m_cfNormal.dwMask = CFM_COLOR;

	m_wndChild.GetSelectionCharFormat(m_cfHigh);
	m_cfHigh.dwEffects = 0;
	m_cfHigh.crTextColor=RGB(0,255,255);
	m_cfHigh.dwMask = CFM_COLOR;

	m_wndChild.GetSelectionCharFormat(m_cfError);
	m_cfError.dwEffects = 0;
	m_cfError.crTextColor=RGB(255,0,0);
	m_cfError.dwMask = CFM_COLOR;

	m_wndChild.GetSelectionCharFormat(m_cfThread);
	m_cfThread.dwEffects = 0;
	m_cfThread.crTextColor=RGB(255,0,255);
	m_cfThread.dwMask = CFM_COLOR;
	
	return 0;
}


void CMonitorBox::Append(LPCTSTR lpszStr,DWORD len,DWORD level){
	char *str = (char*) ::_alloca(len+1);
	CHARFORMAT cf;
	cf.cbSize = sizeof(cf);
	memcpy(str,lpszStr,len);
	if(*(str+(len-2))!='\n'){
		*(str+(len-1))='\n';
		*(str+len)='\0';
	}

//	DeleteExtraLines();
    m_wndChild.SetSel(-1, -1);				        // end of edit text

	switch (level){

	case LEVEL_DEBUG:
		m_wndChild.SetSelectionCharFormat(m_cfDebug);
		break;

	case LEVEL_LOW:
		m_wndChild.SetSelectionCharFormat(m_cfLow);
		break;

	case LEVEL_NORMAL:
		m_wndChild.SetSelectionCharFormat(m_cfNormal);
		break;

	case LEVEL_HIGH:
		m_iWarningCount++;
		m_wndChild.SetSelectionCharFormat(m_cfHigh);
		break;

	case LEVEL_ERROR:
		m_iErrorCount++;
		m_wndChild.SetSelectionCharFormat(m_cfError);
		break;

	case LEVEL_THREAD:
		m_wndChild.SetSelectionCharFormat(m_cfThread);
		break;

	}
    m_wndChild.ReplaceSel(str);					// append string..
//	m_wndChild.SendMessage(EM_SCROLLCARET);	        // ..and show caret
//    m_wndChild.GetSel(m_nStartChar, m_nStopChar);     // save position
	
	if(m_bLogFileOpened){
		if(fwrite(str,strlen(str), 1, m_fpLogFile) != 1){ 
			PrintMessage(LEVEL_ERROR,"Cannot write to log file");
			CloseLogFile();
		}
		fflush(m_fpLogFile);
	}
}

void CMonitorBox::OnContextMenu(CWnd* pWnd, CPoint point){
//	PrintMessage("CMonitorBox::OnContextMenu");
	SetFocus();
    CMenu menu;
    menu.CreatePopupMenu();
    BOOL bReadOnly = GetStyle() & ES_READONLY;
    DWORD flags = m_wndChild.GetTextLength() ? 0 : MF_GRAYED;
	char str[128];
    int iMenuItem = 0;
//	PrintMessage(m_wndChild.GetLineCount(),m_wndChild.GetTextLength());
    if(m_iErrorCount){
		sprintf(str,"Error count: %i",m_iErrorCount);
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION , UWM_ON_NULL_ERROR_COUNT, _T(str));
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION | MF_SEPARATOR);
	}
	menu.InsertMenu(iMenuItem++, MF_BYPOSITION | flags, UWM_ON_FIND_TEXT_DIALOG, _T("&Find"));
	menu.InsertMenu(iMenuItem++, MF_BYPOSITION | MF_SEPARATOR);
	menu.InsertMenu(iMenuItem++, MF_BYPOSITION | flags, UWM_ON_EMPTY_MONITOR_BOX, _T("&Empty Monitor Box"));

	menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON, point.x, point.y, this);
}

BOOL CMonitorBox::OnCommand(WPARAM wParam, LPARAM lParam){

	if(wParam == UWM_ON_FIND_TEXT_DIALOG){
		pFindDlg = new CFindDlg();
		pFindDlg->m_fr.lpTemplateName=MAKEINTRESOURCE(IDD_FIND_DIALOG);
		if(!pFindDlg->Create(TRUE, NULL, NULL, FR_ENABLETEMPLATE | FR_DOWN, this)){
			PrintMessage(LEVEL_ERROR," Cannot create Find Dialog");	
			return(TRUE);
		}
		pFindDlg->SetActiveWindow();
		pFindDlg->ShowWindow(TRUE);
		return (TRUE);
	}
	if(wParam == UWM_ON_EMPTY_MONITOR_BOX){
		m_wndChild.SetSel(0,-1);
		m_wndChild.Clear( );
		m_wndChild.EmptyUndoBuffer();
		return (TRUE);
	}
	if(wParam == UWM_ON_NULL_ERROR_COUNT){
		m_iErrorCount=0;
		return (TRUE);
	}
	return baseCMonitorBox::OnCommand(wParam, lParam);
}

LONG CMonitorBox::OnFindText(WPARAM wParam, LPARAM lParam){
//	PrintMessage("CMonitorBox::OnFindText");
	CFindReplaceDialog* pFindReplace = CFindReplaceDialog::GetNotifier(lParam);
    ASSERT(pFindReplace != NULL);

    if(pFindReplace->IsTerminating()){
        pFindReplace = NULL;
		return(-1);
    }
	if(pFindReplace->FindNext()){
		DWORD dwFlags = (pFindReplace->MatchWholeWord()?FR_WHOLEWORD:0)|(pFindReplace->MatchCase()?FR_MATCHCASE:0);
		CString str = pFindReplace->GetFindString();
		FINDTEXTEX structFindTextEx;
		CHARRANGE structCharRange={-1,-1},*pCharRange;

		structFindTextEx.lpstrText=str.GetBuffer(0);

		m_wndChild.GetSel(m_nStartChar, m_nStopChar);
		pCharRange=&(structFindTextEx.chrgText);
		if(pFindReplace->SearchDown()){
			structFindTextEx.chrg.cpMin = m_nStopChar;
			structFindTextEx.chrg.cpMax = -1;
			m_wndChild.FindText(dwFlags,&structFindTextEx);
		}
		else{
			structFindTextEx.chrg.cpMin = 0;
			structFindTextEx.chrg.cpMax = m_nStartChar;
			while(m_wndChild.FindText(dwFlags,&structFindTextEx) != -1){
				structFindTextEx.chrg.cpMin=(structCharRange.cpMin = pCharRange->cpMin)+1;
				structCharRange.cpMax = pCharRange->cpMax;
			}
			pCharRange=&structCharRange;
		}

		if(pCharRange->cpMin != -1){
			m_wndChild.SetSel(*pCharRange);
			m_wndChild.HideSelection( FALSE, FALSE);
			pFindDlg->OnTextFound();
		}
		else{
			pFindDlg->OnTextNotFound();
		}

	}
	return(0);
}

BOOL CMonitorBox::OpenLogFile(char *pcFileNameBase,char *pcLogDirectory){
	if(m_bLogFileOpened){
		PrintMessage(LEVEL_ERROR,"Log file has been opened already");
		return(FALSE);
	}
	if(!pcFileNameBase){
		PrintMessage(LEVEL_ERROR,"CMonitorBox::OpenLogFile Empty log file name");
		return(FALSE);
	}

	char str[384];

	strcpy(m_strLogFileFullName,pcLogDirectory);
	strcat(m_strLogFileFullName,pcFileNameBase);
	strcat(m_strLogFileFullName,".log");

	if((m_fpLogFile = fopen(m_strLogFileFullName, "wt")) == NULL){
		sprintf(str,"Cannot open log file",m_strLogFileFullName);
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}
	m_bLogFileOpened=TRUE;
	sprintf(str,"Opened Log file %s",m_strLogFileFullName);
	PrintMessage(LEVEL_NORMAL,str);
	return(TRUE);
}

BOOL CMonitorBox::CloseLogFile(){
	if(!m_bLogFileOpened){
		PrintMessage(LEVEL_WARNING,"Log file has not been opened");
		return(FALSE);
	}
	char str[384];
	sprintf(str,"Closing Log file %s",m_strLogFileFullName);
	PrintMessage(LEVEL_NORMAL,str);
	m_bLogFileOpened=FALSE;
	fclose(m_fpLogFile);
	m_fpLogFile=NULL;
	return(TRUE);
}