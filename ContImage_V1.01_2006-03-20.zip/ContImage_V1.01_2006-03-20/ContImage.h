// ContImage.h : main header file for the CONTIMAGE application
//

#if !defined(AFX_CONTIMAGE_H__15F5F0F4_D2A3_4E95_9CC1_7EAA12212A09__INCLUDED_)
#define AFX_CONTIMAGE_H__15F5F0F4_D2A3_4E95_9CC1_7EAA12212A09__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

extern char * g_szVersion;

// Useful define for testing on a no-hardware machine
// Comment out next line for actual code
//#define _DEBUG_NO_CAMERA  

#include "FrameServer.h"
#include "ROI.h"

#include "resource.h"       // main symbols

#define LEVELN 5
#define LEVEL_DEBUG		0
#define LEVEL_LOW		1
#define LEVEL_NORMAL	2
#define LEVEL_HIGH		3
#define LEVEL_WARNING	LEVEL_HIGH
#define LEVEL_ERROR		4
#define LEVEL_THREAD	5

#define MODE_NUMBER		5
#define MODE_NONE		0
#define MODE_GREEN		1	// FOCUS_MODE
#define MODE_EXPOSURE	2	// FOCUS_MODE
#define MODE_SUM		3	// EXPERIMENT_MODE - obsolete
#define MODE_CONTINUOUS	4	// EXPERIMENT_MODE - has two submodes
#define DEFAULT_MODE	MODE_GREEN

#define APPLICATION_MODE_NUMBER		3
#define APPLICATION_MODE_NONE		0
#define APPLICATION_MODE_FOCUS		1
#define APPLICATION_MODE_EXPERIMENT	2
#define DEFAULT_APPLICATION_MODE	APPLICATION_MODE_FOCUS

#define FOCUS_MODE_NUMBER	3
#define FOCUS_MODE_NONE		0
#define FOCUS_MODE_GREEN	1
#define FOCUS_MODE_EXPOSURE	2
#define DEFAULT_FOCUS_MODE	FOCUS_MODE_GREEN

#define EXPERIMENT_MODE_NUMBER		3
#define EXPERIMENT_MODE_NONE		0
#define EXPERIMENT_MODE_SUM			1
#define EXPERIMENT_MODE_CONTINUOUS	2
#define DEFAULT_EXPERIMENT_MODE		EXPERIMENT_MODE_CONTINUOUS

#define EXPERIMENT_SUM_MODE_NUMBER	2
#define EXPERIMENT_SUM_MODE_NONE	0
#define EXPERIMENT_SUM_MODE_SUM		1
#define DEFAULT_EXPERIMENT_SUM_MODE	EXPERIMENT_SUM_MODE_SUM

#define EXPERIMENT_CONTINUOUS_MODE_NUMBER		3
#define EXPERIMENT_CONTINUOUS_MODE_NONE			0
#define EXPERIMENT_CONTINUOUS_MODE_CONTINUOUS	1
#define EXPERIMENT_CONTINUOUS_MODE_EPISODIC		2
#define DEFAULT_EXPERIMENT_CONTINUOUS_MODE		EXPERIMENT_CONTINUOUS_MODE_CONTINUOUS

#define DATATYPE_UCHAR		11L
#define DATATYPE_USHORT		12L
#define DATATYPE_ULONG		13L
#define DATATYPE_FLOAT		14L
#define DEFAULT_DATATYPE	DATATYPE_USHORT

// FileType constants
#define ORRAWBLOCK_FILE		11L
#define ORDCBLOCK_FILE		12L
#define ORSUM_FILE			13L
#define ORIMAGE_FILE		14L
#define ORSTREAM_FILE		15L
#define DEFAULT_FILE_TYPE	ORSTREAM_FILE	

#define SERVER_DYNAMIC_MODE_NUMBER		4
#define SERVER_DYNAMIC_MODE_ROI			0
#define SERVER_DYNAMIC_MODE_FAST		1
#define SERVER_DYNAMIC_MODE_EXPERIMENT	2
#define SERVER_DYNAMIC_MODE_NONE		3
#define DEFAULT_SERVER_DYNAMIC_MODE		SERVER_DYNAMIC_MODE_FAST

#define FOCUS_FILE_SAVE_MODE_NUMBER		3
#define FOCUS_FILE_SAVE_MODE_JPG		0
#define FOCUS_FILE_SAVE_MODE_TIF		1
#define FOCUS_FILE_SAVE_MODE_BMP		2
#define DEFAULT_FOCUS_FILE_SAVE_MODE	FOCUS_FILE_SAVE_MODE_JPG

#define FILENAME_LENGHT_MAX	_MAX_PATH+1

#define FILENAME_SCHEME_MAX	36
#define FILENAME_SIZE		16

#define FILENAME_TAG_OFFSET 2 // E.g. T_???.?? Tag=T_

// T_YMD.NRVFOO
#define FILENAME_POSITION_YEAR		2
#define FILENAME_POSITION_MONTH		3
#define FILENAME_POSITION_DAY		4
#define FILENAME_POSITION_NUMBER	6
#define FILENAME_POSITION_RUN		7
#define FILENAME_POSITION_ROI		8

#define FILENAME_FOCUS_POSITION_OVERWRITE	9

#define FILENAME_EXPERIMENT_POSITION_FILE				9
#define FILENAME_EXPERIMENT_POSITION_OVERWRITE			10
#define FILENAME_EXPERIMENT_POSITION_OVERWRITE_EXTRA	11

#define N_VERTICAL_BINNING 8

#define MAX_EXPERIMENT_FILE_SIZE 660000000
//#define MAX_EXPERIMENT_FILE_SIZE 1000000

#define EXPERIMENT_MESSAGE_MASK			0xFFFFUL
#define EXPERIMENT_MESSAGE_ERROR_SHIFT	16
// ORable messages
#define EXPERIMENT_MESSAGE_FINISHED		0x0
#define EXPERIMENT_MESSAGE_RUNNING		0x1
#define EXPERIMENT_MESSAGE_NOT_PAUSED	0x0
#define EXPERIMENT_MESSAGE_PAUSED		0x2
#define EXPERIMENT_MESSAGE_SLAVE		0x0
#define EXPERIMENT_MESSAGE_MASTER		0x4

//#define PRINT_DEBUG_MESSAGES

typedef union DWORD_BYTE{
	DWORD dw;
	BYTE str[4];
}DWORD_BYTE;

typedef union DWORD_WORD{
	DWORD dw;
	WORD w[2];
}DWORD_WORD;

/////////////////////////////////////////////////////////////////////////////
// API

#include "Globals.h"
#include "Synchronization.h"
/////////////////////////////////////////////////////////////////////////////
// CContImageApp:
// See ContImage.cpp for the implementation of this class
//

#define DEFAULT_USER "default"
#define DEFAULT_DATA_DIRECTORY "C:\\TEMP\\"
#define DEFAULT_LOG_DIRECTORY "C:\\TEMP\\"
#define DEFAULT_SPATIAL_FOCUS_BINNING 1
#define DEFAULT_TEMPORAL_FOCUS_BINNING 1
#define DEFAULT_SPATIAL_EXPERIMENT_BINNING 2
#define DEFAULT_TEMPORAL_EXPERIMENT_BINNING 1
#define DEFAULT_HARDWARE_INTERFRAME_TIME_USEC 33333
#define DEFAULT_HARDWARE_INTEGRATION_TIME_USEC 31173

#define DEFAULT_NFRAMES 100

class CContImageApp : public CWinApp
{
public:
	CContImageApp();

	CMultiDocTemplate* pDocTemplate;

	CFrameServer *m_pFrameServer;
	CROI *m_pROI;


	CSynchronization *m_pSynch;


	// Settings
	int m_iDocCount;

	int m_iMode;
	int m_iApplicationMode;
	int m_iFocusMode;
	int m_iExperimentMode;
	int m_iExperimentSumMode;
	int m_iExperimentContinuousMode;

	CString m_strUserName;
	CString m_strSubjectID;

	CString m_strDataDirectory;
	CString m_strLogDirectory;

	short m_sMonth;
	short m_sDay;
	short m_sYear;
	short m_sExperimentNumber;
	short m_sExperimentRun;
	
	int m_iDataType;
	int m_iFileType;

	int m_iSpatialBinningX;
	int m_iSpatialBinningY;
	int m_iSpatialFocusBinningX;
	int m_iSpatialFocusBinningY;
	int m_iSpatialExperimentBinningX;
	int m_iSpatialExperimentBinningY;

	int m_iTemporalBinning;
	int m_iTemporalFocusBinning;
	int m_iTemporalExperimentBinning;

	UINT m_nOpticsFocalLengthTop;
	UINT m_nOpticsFocalLengthBottom;

	UINT m_nWaveLength;
	UINT m_nFilterWidth;
	UINT m_nFocusWaveLength;
	UINT m_nFocusFilterWidth;
	UINT m_nExperimentWaveLength;
	UINT m_nExperimentFilterWidth;

	// COST data block
	double m_dStimulationPeriod; //seconds
	double m_dStimulationCycles;
	COST_CONTROL m_COSTControl;

	// EPST data block
	UINT m_nNFramesStim;	 // Stimulation frames
	UINT m_nNFramesITI;		 // Blank pre-stim frames
	UINT m_nNFramesBlankPre; // Blank pre-run frames
	UINT m_nNFramesBlankPost;// Blank post-run frames
	UINT m_nNConditions;
	UINT m_nNRepetitions;
	BOOL m_bRandomize;
	EPST_CONTROL m_EPSTControl;

	int  *m_piConditionList;

	float m_fTotalTime;

	UINT m_nNFrames;

	CString m_strComments;

	char m_strBaseFileName[20];

	BOOL m_bMainROIOpened;
	BOOL m_bGreenAcquired;
	BOOL m_bGreenSaved;
	BOOL m_bRunningFocus;
	BOOL m_bRunningExperiment;
	BOOL m_bExperimentPaused;

	int m_iServerDynamicMode;
	int m_iFocusDynamicMode;
	int m_iFocusFileSaveMode;

	int volatile m_iDisplayFrames;

	CMultiChunk m_MultiChunk;

	ULONG	m_ulFileHeaderSize;
	void	*m_pFileHeaderTemplate;
	ULONG	m_ulFrameHeaderSize;
	void	*m_pFrameHeaderTemplate;
	ULONG	(*m_pfunExperimentCallback)(WPARAM,LPARAM,double);
	void	*m_pExperimentControl;

	void InitVariables();

	void GetPrivateProfile();
	void SavePrivateProfile();

	BOOL OnROINew();

	char *MakeFileName(int,char*);
	char *MakeFileName();

	void SetApplicationMode(int iApplicationMode = -1);
	void SetFocusMode(int iFocusMode = -1);
	void SetExperimentMode(int iExperimentMode = -1);
	void SetExperimentSumMode(int iExperimentSumMode = -1);
	void SetExperimentContinuousMode(int iExperimentContinuousMode = -1);
	void SetSubModesFromMode();
	void UpdateFileHeader();

	void ResetHardwareBinning(DWORD ulBinning);
	BOOL StartGrabbing();
	BOOL StopGrabbing(int = THREAD_SHUTDOWN_STOP);
	BOOL OnFrameServerStart(int iMessage);
	BOOL OnFrameServerStop();

	BOOL SetHardwareFromChunk(HARD_CHUNK*);
	BOOL SetSoftwareFromChunk(SOFT_CHUNK*);

	int PrepareForNextExperiment();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContImageApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CContImageApp)
	afx_msg void OnAppAbout();
	afx_msg void OnSettingsExperiment();
	afx_msg void OnUpdateSettingsExperiment(CCmdUI* pCmdUI);
	afx_msg void OnSettingsGet();
	afx_msg void OnSettingsSave();
	afx_msg void OnFileNew();
	afx_msg void OnAcquireCamZoomCaps();
	afx_msg void OnAcquireCamAttr();
	afx_msg void OnAcquireMiscBrodcastMsg();
	afx_msg void OnFileClose(int);
	afx_msg void OnAcquireMiscSerialPortSettings();
	afx_msg void OnAcquireMiscHardwareSettings();
	afx_msg void OnSettingsHardware();
	afx_msg void OnAcquireCamSoftReset();
	afx_msg void OnAcquireCamHardReset();
	afx_msg void OnSettingsFocus();
	afx_msg void OnAcquireMiscTest();
	afx_msg void OnFileOpen();
	afx_msg void OnAcquireCamMisc();
	afx_msg void OnAcquireCamReadCaps();
	afx_msg void OnAcquireCamLutCaps();
	afx_msg void OnAcquireMiscMemoryStatus();
	afx_msg void OnUpdateFileSaveAll(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSettingsFocus(CCmdUI* pCmdUI);
	afx_msg void OnAcquireDestinationTotalArea();
	afx_msg void OnSettingsROI();
	afx_msg void OnUpdateSettingsROI(CCmdUI* pCmdUI);
	afx_msg void OnAcquireMiscDIOTest();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTIMAGE_H__15F5F0F4_D2A3_4E95_9CC1_7EAA12212A09__INCLUDED_)
