// ROIDlg.cpp : implementation file
//

#include "stdafx.h"
#include "contimage.h"
#include "ROIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CROIDlg dialog


CROIDlg::CROIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CROIDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CROIDlg)
	m_bKeepOriginalNumbers = FALSE;
	m_bMaximizeNewNumbers = FALSE;
	//}}AFX_DATA_INIT
}


void CROIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CROIDlg)
	DDX_Control(pDX, IDC_LIST_ROI, m_ROIListCtrl);
	DDX_Check(pDX, IDC_ROI_KEEP_ORIGINAL_NUMBERS, m_bKeepOriginalNumbers);
	DDX_Check(pDX, IDC_MAXIMIZE_NEW_NUMBERS, m_bMaximizeNewNumbers);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CROIDlg, CDialog)
	//{{AFX_MSG_MAP(CROIDlg)
	ON_BN_CLICKED(IDC_ROI_KEEP_ORIGINAL_NUMBERS, OnRoiKeepOriginalNumbers)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CROIDlg message handlers

BOOL CROIDlg::OnInitDialog(){
	CDialog::OnInitDialog();
	
	VERIFY(m_ROIImages.Create(IDB_ROI_STATE, 15, 0, RGB(192,192,192)));
	m_ROIListCtrl.SetImageList(&m_ROIImages, LVSIL_SMALL);

	m_ROIListCtrl.InsertColumn(COLUMN_INDEX,	"Index");
	m_ROIListCtrl.InsertColumn(COLUMN_NUMBER,	"Number");
	m_ROIListCtrl.InsertColumn(COLUMN_LEFT,		"Left");
	m_ROIListCtrl.InsertColumn(COLUMN_RIGHT,	"Right");
	m_ROIListCtrl.InsertColumn(COLUMN_SIZEX,	"Size X");
	m_ROIListCtrl.InsertColumn(COLUMN_TOP,		"Top");
	m_ROIListCtrl.InsertColumn(COLUMN_BOTTOM,	"Bottom");
	m_ROIListCtrl.InsertColumn(COLUMN_SIZEY,	"Size Y");
	
	int iWidth = m_ROIListCtrl.GetStringWidth("12345678");

	for (int i=0; i<COLUMN_LAST; i++) m_ROIListCtrl.SetColumnWidth(i, iWidth);//LVSCW_AUTOSIZE_USEHEADER);


	char str[32];
	ROI *pROI;
	for(i=0;i<m_pCROI->GetCount();i++){
		sprintf(str,"% 2i",i);
		m_ROIListCtrl.InsertItem(i, str, 0);
		pROI=m_pCROI->GetAt(m_pCROI->FindIndex(i));
		sprintf(str,"%i",pROI->iNumber);
		m_ROIListCtrl.SetItem(i, COLUMN_NUMBER, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->left);
		m_ROIListCtrl.SetItem(i, COLUMN_LEFT, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->right);
		m_ROIListCtrl.SetItem(i, COLUMN_RIGHT, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->right+1-pROI->pRect->left);
		m_ROIListCtrl.SetItem(i, COLUMN_SIZEX, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->top);
		m_ROIListCtrl.SetItem(i, COLUMN_TOP, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->bottom);
		m_ROIListCtrl.SetItem(i, COLUMN_BOTTOM, LVIF_TEXT, str, 0,0,0,0);
		sprintf(str,"%i",pROI->pRect->bottom+1-pROI->pRect->top);
		m_ROIListCtrl.SetItem(i, COLUMN_SIZEY, LVIF_TEXT, str, 0,0,0,0);
		m_ROIListCtrl.SetItemData(i, (DWORD)(m_pCROI->FindIndex(i)));
		m_ROIListCtrl.EnsureVisible(i, FALSE);
	}
//	m_ROIListCtrl.SetItemState(1, LVIS_SELECTED, LVIS_SELECTED );

	GetDlgItem(IDC_MAXIMIZE_NEW_NUMBERS)->EnableWindow(m_bKeepOriginalNumbers);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CROIDlg::OnRoiKeepOriginalNumbers(){
	UpdateData (TRUE);
	GetDlgItem(IDC_MAXIMIZE_NEW_NUMBERS)->EnableWindow(m_bKeepOriginalNumbers);
}
