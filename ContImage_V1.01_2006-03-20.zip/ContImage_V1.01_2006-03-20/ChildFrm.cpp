// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "ContImage.h"
//#include "ContImageView.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_ON_RESIZE_CLIENT_AREA = ::RegisterWindowMessage(_T("UWM_ON_RESIZE_CLIENT_AREA"));

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_GETMINMAXINFO()
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(UWM_ON_RESIZE_CLIENT_AREA, OnResizeClientArea)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame(){
	m_iWndSizeX=0;
	m_iWndSizeY=0;
	PrintMessage("Win created");
}

CChildFrame::~CChildFrame(){
	PrintMessage("Win destroyed");	
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs){
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style &= ~WS_MAXIMIZEBOX;
//	cs.style &= ~WS_SYSMENU;
	return CMDIChildWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

void CChildFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI){
//	PrintMessage("CChildFrame::OnGetMinMaxInfo");
//	PrintMessage(m_iWndSizeX,m_iWndSizeY);
//	PrintMessage(lpMMI->ptMaxSize.x,lpMMI->ptMaxSize.y);
//	PrintMessage(lpMMI->ptMaxTrackSize.x,lpMMI->ptMaxTrackSize.y);
//	PrintMessage(lpMMI->ptMinTrackSize.x,lpMMI->ptMinTrackSize.y);
	if(m_iWndSizeX !=0 && m_iWndSizeY != 0){
		CRect wr;
		CRect cr;
		GetWindowRect(&wr);
		GetClientRect(&cr);
		int iWidthAdjust = wr.right  - wr.left - cr.right  + 2*GetSystemMetrics(SM_CXEDGE);
		int iHeightAdjust = wr.bottom - wr.top  - cr.bottom + 2*GetSystemMetrics(SM_CYEDGE); 

		lpMMI->ptMaxSize.x = lpMMI->ptMaxTrackSize.x = m_iWndSizeX + iWidthAdjust;
		lpMMI->ptMaxSize.y = lpMMI->ptMaxTrackSize.y = m_iWndSizeY + iHeightAdjust;
		lpMMI->ptMinTrackSize.x = lpMMI->ptMinTrackSize.y = 0;
	}
//	PrintMessage(lpMMI->ptMinTrackSize.x,lpMMI->ptMinTrackSize.y);
//	PrintMessage(SM_CXSIZE,SM_CYSIZE);
	CMDIChildWnd::OnGetMinMaxInfo(lpMMI);
}

LRESULT CChildFrame::OnResizeClientArea(WPARAM wParam, LPARAM lParam){
	PrintMessage("CChildFrame::OnResizeClientArea");
	m_iWndSizeX=*(int*)wParam;
	m_iWndSizeY=*(int*)lParam;
	char str[64];
	sprintf(str,"%i %i",m_iWndSizeX,m_iWndSizeY);
	PrintMessage(str);
	return (LRESULT) TRUE;
}
