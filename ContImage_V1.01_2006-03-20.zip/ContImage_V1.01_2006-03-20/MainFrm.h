// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__C89E8A58_6CBA_4950_B697_A2245820178B__INCLUDED_)
#define AFX_MAINFRM_H__C89E8A58_6CBA_4950_B697_A2245820178B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ModeToolBar.h"
#include "MonitorBox.h"
#include "ExperimentDlg.h"
//#include "HardwareDlg.h"
#include "FocusDlg.h"
//#include "ROIDlg.h"

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
	void OnActiveDocuments(int);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	CMonitorBox m_wndMonitorBox;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;

	CToolBar    m_wndToolBar;
	CToolBar    m_wndSmallToolBar;
	CButton		m_buttonFocus;
	CButton		m_buttonExperiment;
	HFONT		m_hFont;

	CModeToolBar 	m_wndModeToolBar; 
private:
	CBitmap m_hFocusBitmap;
	CBitmap m_hExperimentBitmap;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewMonitorBox();
	afx_msg void OnUpdateViewMonitorBox(CCmdUI* pCmdUI);
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveAll();
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnFocus();
	afx_msg void OnExperiment();
	afx_msg void OnAcquireMiscWindows();
	//}}AFX_MSG

	afx_msg LRESULT OnChangeModes(WPARAM , LPARAM );

	afx_msg LRESULT OnPrintThreadMessage(WPARAM, LPARAM);
	afx_msg LRESULT OnTriggerThreadFinished(WPARAM, LPARAM = 0);
	afx_msg LRESULT OnExperimentThreadFinished(WPARAM, LPARAM);


	
	afx_msg void OnFocus1();
	afx_msg void OnExperiment1();

//	afx_msg void OnToolBarState(UINT nID);

//	afx_msg void OnUpdateToolBarState(CCmdUI* pCmdUI);

	afx_msg void OnUpdateFocus(CCmdUI* pCmdUI);
	afx_msg void OnUpdateExperiment(CCmdUI* pCmdUI);

	afx_msg void OnFocusGreen();
	afx_msg void OnUpdateFocusGreen(CCmdUI* pCmdUI);
	afx_msg void OnFocusExposure();
	afx_msg void OnUpdateFocusExposure(CCmdUI* pCmdUI);
	afx_msg void OnFocusRun();
	afx_msg void OnUpdateFocusRun(CCmdUI* pCmdUI);
	afx_msg void OnFocusStop();
	afx_msg void OnUpdateFocusStop(CCmdUI* pCmdUI);
	afx_msg void OnFocusSave();
//	afx_msg void OnUpdateFocusSave(CCmdUI* pCmdUI);

	afx_msg void OnExperimentRun();
	afx_msg void OnUpdateExperimentRun(CCmdUI* pCmdUI);
	afx_msg void OnExperimentPause();
	afx_msg void OnUpdateExperimentPause(CCmdUI* pCmdUI);
	afx_msg void OnExperimentStop();
	afx_msg void OnUpdateExperimentStop(CCmdUI* pCmdUI);
	afx_msg void OnExperimentAbort();
	afx_msg void OnUpdateExperimentAbort(CCmdUI* pCmdUI);
	afx_msg void OnFocusDisplay();
	afx_msg void OnUpdateFocusDisplay(CCmdUI* pCmdUI);
	afx_msg void OnExperimentDisplay();

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__C89E8A58_6CBA_4950_B697_A2245820178B__INCLUDED_)
