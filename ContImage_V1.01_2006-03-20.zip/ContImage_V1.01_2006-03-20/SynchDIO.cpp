// SynchDIO.cpp: implementation of the CSynchDIO class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "contimage.h"
#include "SynchDIO.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSynchDIO::CSynchDIO(){
	DIO_Open();
	InitPhysicalPorts();
	InitLogicalPorts();
}

CSynchDIO::~CSynchDIO(){
	DIO_Close();
}

int CSynchDIO::InitPhysicalPorts(){
	int iConfigVal;
	int iError=0;
	char str[128];

	for(int i=0;i<N_PHYSICAL_PORTS;i++){
		m_PhysicalPorts[i].iSeqPortNum=i;
		m_PhysicalPorts[i].iBoardNum=BOARD_NUM;
		if((iError=cbGetConfig(DIGITALINFO,BOARD_NUM,i,DICONFIG,&iConfigVal))){
			sprintf(str,"CSynchDIO::InitPhysicalPorts Error %i",iError);
			::MessageBox(NULL,"cbGetConfig DICONFIG",str,MB_OK);
		}
		else{
			m_PhysicalPorts[i].iDirection=iConfigVal;
		}
		if((iError=cbGetConfig(DIGITALINFO,BOARD_NUM,i,DINUMBITS,&iConfigVal))){
			sprintf(str,"CSynchDIO::InitPhysicalPorts Error %i",iError);
			::MessageBox(NULL,"cbGetConfig DINUMBITS",str,MB_OK);
		}
		else{
			m_PhysicalPorts[i].usBitCount=(USHORT)iConfigVal;
			m_PhysicalPorts[i].usBitMask=((USHORT)~0)>>(16-iConfigVal);
		}
		if((iError=cbGetConfig(DIGITALINFO,BOARD_NUM,i,DIDEVTYPE,&iConfigVal))){
			sprintf(str,"CSynchDIO::InitPhysicalPorts Error %i",iError);
			::MessageBox(NULL,"cbGetConfig DIDEVTYPE",str,MB_OK);
		}
		else{
			m_PhysicalPorts[i].iPort=iConfigVal;
		}
	}
	m_PhysicalPorts[0].pfunWrite=WritePhysicalPortA;
	m_PhysicalPorts[0].pfunRead=NULL;
	m_PhysicalPorts[1].pfunWrite=NULL;
	m_PhysicalPorts[1].pfunRead=ReadPhysicalPortB;
	m_PhysicalPorts[2].pfunWrite=WritePhysicalPortCL;
	m_PhysicalPorts[2].pfunRead=NULL;
	m_PhysicalPorts[3].pfunWrite=NULL;
	m_PhysicalPorts[3].pfunRead=ReadPhysicalPortCH;
	return(iError);
}

void CSynchDIO::InitLogicalPorts(){
	m_iNumLogicalPorts=N_PHYSICAL_PORTS;
	for(int i=0;i<N_PHYSICAL_PORTS;i++){
		m_LogicalPorts[i].iNumPhysicalPorts=1;
		m_LogicalPorts[i].ppPhysicalPorts[0]=m_PhysicalPorts+i;
		m_LogicalPorts[i].iDirection=m_PhysicalPorts[i].iDirection;
	}
}


int CSynchDIO::WritePhysicalPort(int iPhysicalPort,USHORT usData){
	if(iPhysicalPort>=N_PHYSICAL_PORTS || iPhysicalPort<0) return(-1);
	PHYSICAL_PORT *pPP=m_PhysicalPorts+iPhysicalPort;
	if(pPP->iDirection == DIGITALOUT) return(cbDOut(pPP->iBoardNum, pPP->iPort, usData&pPP->usBitMask));
	else return(-2);
}

int CSynchDIO::ReadPhysicalPort(int iPhysicalPort,USHORT& usData){
	if(iPhysicalPort>=N_PHYSICAL_PORTS || iPhysicalPort<0) return(-1);
	PHYSICAL_PORT *pPP=m_PhysicalPorts+iPhysicalPort;
	if(pPP->iDirection == DIGITALIN) return(cbDIn(pPP->iBoardNum, pPP->iPort, &usData));
	else return(-2);
}

int CSynchDIO::WriteLogicalPort(int iLogicalPort,ULONG ulData){
	if(iLogicalPort>=m_iNumLogicalPorts || iLogicalPort<0) return(-1);
	LOGICAL_PORT *pLP=m_LogicalPorts+iLogicalPort;
	if(pLP->iDirection != DIGITALOUT) return(-3);
	PHYSICAL_PORT *pPP;
	USHORT usData;
	int iError;
	for(int i=0;i<pLP->iNumPhysicalPorts;i++){
		pPP=pLP->ppPhysicalPorts[i];
		usData=(USHORT)(ulData & pPP->usBitMask);
		if((iError=WritePhysicalPort(pPP->iSeqPortNum,usData))) return(iError);
		ulData >>= pPP->usBitCount;
	}
	return(0);
}

int CSynchDIO::ReadLogicalPort(int iLogicalPort,ULONG& ulData){
	if(iLogicalPort>=m_iNumLogicalPorts || iLogicalPort<0) return(-1);
	LOGICAL_PORT *pLP=m_LogicalPorts+iLogicalPort;
	if(pLP->iDirection != DIGITALIN) return(-3);
	PHYSICAL_PORT *pPP;
	USHORT usData;
	int iError;
	ULONG ulShift=0;
	ulData=0;
	for(int i=pLP->iNumPhysicalPorts-1;i>=0;i--){
		pPP=pLP->ppPhysicalPorts[i];
		if((iError=ReadPhysicalPort(pPP->iSeqPortNum,usData))) return(iError);
		if(i != pLP->iNumPhysicalPorts-1) ulData <<= pPP->usBitCount;
		ulData |= usData & pPP->usBitMask;
	}
	return(0);
}


int CSynchDIO::DIO_Open(){
	int iError;
	char str[128];
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTA, DIGITALOUT))){
		sprintf(str,"CSynchDIO::DIO_Open Error %i",iError);
		::MessageBox(NULL,"Cannot configure port FIRSTPORTA for DIGITALOUT",str,MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTB, DIGITALIN))){
		sprintf(str,"CSynchDIO::DIO_Open Error %i",iError);
		::MessageBox(NULL,"Cannot configure port FIRSTPORTB for DIGITALIN",str,MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTCL, DIGITALOUT))){
		sprintf(str,"CSynchDIO::DIO_Open Error %i",iError);
		::MessageBox(NULL,"Cannot configure port FIRSTPORTCL for DIGITALOUT",str,MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTCH, DIGITALIN))){
		sprintf(str,"CSynchDIO::DIO_Open Error %i",iError);
		::MessageBox(NULL,"Cannot configure port FIRSTPORTCH for DIGITALIN",str,MB_OK);
		return(iError);
	}
	return(0);
}

int CSynchDIO::DIO_Close(){
	int iError;
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTA, DIGITALIN))){
		::MessageBox(NULL,"Cannot configure port FIRSTPORTA for DIGITALOUT","CSynchDIO::DIO_Close",MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTB, DIGITALIN))){
		::MessageBox(NULL,"Cannot configure port FIRSTPORTB for DIGITALIN","CSynchDIO::DIO_Close",MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTCL, DIGITALIN))){
		::MessageBox(NULL,"Cannot configure port FIRSTPORTCL for DIGITALOUT","CSynchDIO::DIO_Close",MB_OK);
		return(iError);
	}
	if((iError=cbDConfigPort(BOARD_NUM, FIRSTPORTCH, DIGITALIN))){
		::MessageBox(NULL,"Cannot configure port FIRSTPORTCH for DIGITALIN","CSynchDIO::DIO_Close",MB_OK);
		return(iError);
	}
	return(0);
}

