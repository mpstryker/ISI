#if !defined(AFX_MONITORBOX_H__39C6F57D_C93D_4674_AED5_EC7CC97119DD__INCLUDED_)
#define AFX_MONITORBOX_H__39C6F57D_C93D_4674_AED5_EC7CC97119DD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MonitorBox.h : header file
//


#include "FindDlg.h"


/////////////////////////////////////////////////////////////////////////////
// CMonitorBox view

#ifndef baseCMonitorBox
#define baseCMonitorBox CSizingControlBarG
#endif

class CMonitorBox : public baseCMonitorBox
{
// Construction
public:
	CMonitorBox();
	virtual ~CMonitorBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitorBox)
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	void Append(LPCTSTR lpszStr,DWORD len,DWORD level);
	BOOL OpenLogFile(char *pcFileNameBase,char *pcLogDirectory);
	BOOL CloseLogFile();

//protected:
	CRichEditCtrl	m_wndChild;
	HFONT	m_hFont;
	CHARFORMAT m_cfDebug;
	CHARFORMAT m_cfLow;
	CHARFORMAT m_cfNormal;
	CHARFORMAT m_cfHigh;
	CHARFORMAT m_cfError;
	CHARFORMAT m_cfThread;

    long m_nStartChar, m_nStopChar;
	int m_iErrorCount;
	int m_iWarningCount;

	CFindDlg* pFindDlg;

	BOOL	m_bLogFileOpened;
	FILE	*m_fpLogFile;
	char	m_strLogFileFullName[256];

	// Generated message map functions
protected:
	//{{AFX_MSG(CMonitorBox)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG

	afx_msg LONG OnFindText(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITORBOX_H__39C6F57D_C93D_4674_AED5_EC7CC97119DD__INCLUDED_)
