// ContImageDoc.cpp : implementation of the CContImageDoc class
//

#include "stdafx.h"
#include "ContImage.h"

#include "ContImageDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_ON_STOP_GRABBING = ::RegisterWindowMessage(_T("UWM_ON_STOP_GRABBING"));

/////////////////////////////////////////////////////////////////////////////
// CContImageDoc

IMPLEMENT_DYNCREATE(CContImageDoc, CDocument)

BEGIN_MESSAGE_MAP(CContImageDoc, CDocument)
	//{{AFX_MSG_MAP(CContImageDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP


END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContImageDoc construction/destruction

CContImageDoc::CContImageDoc(){
	
	CContImageApp* theApp = (CContImageApp*)AfxGetApp();
	char str[64];

	m_iDocIndex=theApp->m_pROI->GetROI(&m_prectROI);
	m_iDocNumber=theApp->m_pROI->GetNumber(m_prectROI);

	if(m_iDocIndex){
		sprintf(str,"SubROI %c",NumberToChar(m_iDocNumber));
		SetTitle(str);
		sprintf(str,"Creating doc %i",m_iDocNumber);
		PrintMessage(str);
	}
	else{
		SetTitle("Main");
		sprintf(str,"Creating main doc");
		PrintMessage(str);
	}
	m_piSpatialBinningX	=&(theApp->m_iSpatialBinningX);
	m_piSpatialBinningY	=&(theApp->m_iSpatialBinningY);
	m_piTemporalBinning	=&(theApp->m_iTemporalBinning);
	m_sizeROI=CSize(m_prectROI->right-m_prectROI->left+1,m_prectROI->bottom-m_prectROI->top+1);
	sprintf(str,"Dimensions (%i %i) (%i %i)",m_prectROI->left,m_prectROI->top,m_prectROI->right,m_prectROI->bottom);
	PrintMessage(str);
	
	PrintMessage("Doc created");
}

CContImageDoc::~CContImageDoc(){	
	if(m_iDocIndex){
		PrintMessage("SubROI doc destroyed");
	}
	else{
		PrintMessage("Main doc destroyed");	
	}	
}

BOOL CContImageDoc::OnNewDocument(int iDocIndex){
	char str[128];
	if (!CDocument::OnNewDocument())	return FALSE;
	sprintf(str,"CContImageDoc::OnNewDocument %i",iDocIndex);
	PrintMessage(str);

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CContImageDoc serialization

void CContImageDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CContImageDoc diagnostics

#ifdef _DEBUG
void CContImageDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CContImageDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContImageDoc commands


void CContImageDoc::OnCloseDocument(){
	PrintMessage("CContImageDoc::OnCloseDocument");	
	CContImageApp* theApp = (CContImageApp*)AfxGetApp();
	int iShutdown=0;
	POSITION pos;
	if(theApp->m_bRunningExperiment){
		switch(AfxMessageBox("Save data?", MB_ICONQUESTION | MB_YESNOCANCEL | MB_DEFBUTTON3)){
		case IDCANCEL:
			return;
			break;
		case IDNO:
			iShutdown=THREAD_SHUTDOWN_ABORT;
			break;
		default:
			iShutdown=THREAD_SHUTDOWN_STOP;
			break;
		}
		pos = GetFirstViewPosition();
		while(pos){
			CView* pView = GetNextView(pos);
			pView->SendMessage(UWM_ON_STOP_GRABBING,iShutdown,iShutdown);
		}   		
	}
	if(theApp->m_bRunningFocus){
		pos = GetFirstViewPosition();
		while(pos){
			CView* pView = GetNextView(pos);
			pView->SendMessage(UWM_ON_STOP_GRABBING);
		}   		
	}

	theApp->m_pROI->RemoveROI(m_prectROI);
	theApp->OnFileClose(m_iDocIndex);
	CDocument::OnCloseDocument();
}
