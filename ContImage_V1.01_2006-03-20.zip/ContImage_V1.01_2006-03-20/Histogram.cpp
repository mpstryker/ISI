// Histogram.cpp : implementation file
//

#include "stdafx.h"
#include "contimage.h"
#include "Histogram.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_ON_HISTOGRAM_DESTROY = ::RegisterWindowMessage(_T("UWM_ON_HISTOGRAM_DESTROY"));

/////////////////////////////////////////////////////////////////////////////
// CHistogram

CHistogram::CHistogram(){
	m_pulBuffer=NULL;
	m_hMsgWnd=NULL;
	m_strWindowName=NULL;
	m_pBitmap = NULL;
	VERIFY(m_cFont.CreatePointFont(90, "MS Sans Serif"));
	m_crTextColor=0xffffff;
	m_crBkColor=0xff0000;

	m_ulMost=m_ulMostC=0;
	m_ulLeast=m_ulLeastC=0;
	m_ulMax=m_ulMaxC=0;
	m_ulMin=m_ulMinC=0;
	m_ulMean=0;
	m_ulTotal=1;

	m_ulMostP=m_ulMostCP=0;
	m_ulLeastP=m_ulLeastCP=0;
	m_ulMaxP=m_ulMaxCP=0;
	m_ulMinP=m_ulMinCP=0;
	m_ulMeanP=0;
	m_ulTotalP=1;
}

CHistogram::~CHistogram(){
	if(m_strWindowName) free(m_strWindowName);
	if(m_pulBuffer) free(m_pulBuffer);
}


BEGIN_MESSAGE_MAP(CHistogram, CWnd)
	//{{AFX_MSG_MAP(CHistogram)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_GETMINMAXINFO()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CHistogram message handlers

BOOL CHistogram::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext){
	m_hMsgWnd=pParentWnd->m_hWnd;
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

BOOL CHistogram::Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName){
	PrintMessage("CHistogram::Create");
	char str[256];
	m_ulWidth=iWidth;
	m_ulHeight=iHeight;
	if(!m_ulWidth*m_ulHeight) return(FALSE);

	m_ulWndWidth=iWidth+HISTOGRAM_WIDTH_RIGHT_PANEL+2*GetSystemMetrics(SM_CXSIZEFRAME);
	m_ulWndHeight=iHeight+2*GetSystemMetrics(SM_CYSIZEFRAME)+GetSystemMetrics(SM_CYCAPTION);

	m_hMsgWnd=hwndParent;
	m_strWindowName=(char*)malloc(strlen(strWindowName)+1);
	memcpy(m_strWindowName,strWindowName,strlen(strWindowName)+1);
	sprintf(str,"%s %c",m_strWindowName,iNumber);
	return CWnd::CreateEx( 0,lpszClassName,_T(str),WS_POPUPWINDOW | WS_OVERLAPPEDWINDOW,x,y,
		m_ulWndWidth,m_ulWndHeight,	hwndParent, NULL,NULL);
}

BOOL CHistogram::Create(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hwndParent, HMENU nIDorHMenu, LPVOID lpParam){	
	m_hMsgWnd=hwndParent;
	return CWnd::CreateEx(dwExStyle,lpszClassName,lpszWindowName,dwStyle,x,y,nWidth,nHeight,hwndParent,nIDorHMenu,lpParam);
}


void CHistogram::OnPaint(){
	CPaintDC dc(this); // device context for painting
	char str[32];
	if(m_pBitmap){

		CDC DCMem;
		DCMem.CreateCompatibleDC(NULL);
		CBitmap* pOldBitmap = DCMem.SelectObject(m_pBitmap);
		dc.BitBlt(0,0,m_ulWidth,m_ulHeight,&DCMem,0,0,SRCCOPY);

		dc.SetTextColor(m_crBkColor);


		sprintf(str," Min %i (%i)",m_ulMinP,m_ulMinCP);
		dc.TextOut(m_ulWidth,(1*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Max %i (%i)",m_ulMaxP,m_ulMaxCP);
		dc.TextOut(m_ulWidth,(2*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Mean %i",m_ulMeanP);
		dc.TextOut(m_ulWidth,(3*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Most %i (%i  %.1f%%)",m_ulMostP,m_ulMostCP,(100.0*m_ulMostCP)/m_ulTotalP);
		dc.TextOut(m_ulWidth,(4*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Least %i (%i)",m_ulLeastP,m_ulLeastCP);
		dc.TextOut(m_ulWidth,(5*m_ulHeight)/6,str,strlen(str));

		m_ulMostP=m_ulMost;
		m_ulMostCP=m_ulMostC;
		m_ulLeastP=m_ulLeast;
		m_ulLeastCP=m_ulLeastC;
		m_ulMaxP=m_ulMax;
		m_ulMaxCP=m_ulMaxC;
		m_ulMinP=m_ulMin;
		m_ulMinCP=m_ulMinC;
		m_ulMeanP=m_ulMean;
		m_ulTotalP=m_ulTotal;

		dc.SetTextColor(m_crTextColor);

		sprintf(str," Min %i (%i)",m_ulMinP,m_ulMinCP);
		dc.TextOut(m_ulWidth,(1*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Max %i (%i)",m_ulMaxP,m_ulMaxCP);
		dc.TextOut(m_ulWidth,(2*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Mean %i",m_ulMeanP);
		dc.TextOut(m_ulWidth,(3*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Most %i (%i  %.1f%%)",m_ulMostP,m_ulMostCP,(100.0*m_ulMostCP)/m_ulTotalP);
		dc.TextOut(m_ulWidth,(4*m_ulHeight)/6,str,strlen(str));
		sprintf(str," Least %i (%i)",m_ulLeastP,m_ulLeastCP);
		dc.TextOut(m_ulWidth,(5*m_ulHeight)/6,str,strlen(str));

		DCMem.SelectObject(pOldBitmap);
		DCMem.DeleteDC();
	}
}

void CHistogram::CreateHistogramBitmap(){
	DWORD dwCount=4*m_ulWidth*m_ulHeight;

	m_pulBuffer=(ULONG*)calloc(dwCount,1);

	ULONG i,j,k;
	for(k=j=0;j<m_ulHeight;j++)
		for(i=0;i<m_ulWidth;i++,k++){
			if(i==0 || i==m_ulWidth-1 || j==0 || j==m_ulHeight-1) m_pulBuffer[k]=RGB(255,255,255);
			else m_pulBuffer[k] = RGB(0,(j*255)/m_ulHeight,(i*255)/m_ulWidth);
		}

	m_pBitmap = new CBitmap;
	CDC* pDC = GetDC();

	m_pBitmap->CreateCompatibleBitmap(pDC,m_ulWidth,m_ulHeight);
	m_pBitmap->SetBitmapBits(dwCount,m_pulBuffer);

	pDC->SelectObject(&m_cFont);
	pDC->SetBkColor(m_crBkColor);

	ReleaseDC(pDC);
}

void CHistogram::UpdateHistogram(ULONG ulBins,ULONG *pulVals,ULONG ulMin,ULONG ulMax){
	ULONG i,j,k;
	ULONG ul;
	ULONG *pul;
	for(i=0;i<ulBins;i++)
		if(pulVals[i]){
			m_ulMinC=pulVals[i];
			m_ulMin=i;
			break;
		}
	for(i=ulBins-1;i>=0;i--)
		if(pulVals[i]){
			m_ulMaxC=pulVals[i];
			m_ulMax=i;
			break;
		}
	for(i=m_ulMin,m_ulMostC=m_ulLeastC=m_ulMinC,m_ulTotal=m_ulMean=0;i<=m_ulMax;i++){
		if(m_ulMostC<=pulVals[i]){
			m_ulMostC=pulVals[i];
			m_ulMost=i;
		}
		if(m_ulLeastC>=pulVals[i]){
			m_ulLeastC=pulVals[i];
			m_ulLeast=i;
		}
		m_ulMean+=i*pulVals[i];
		m_ulTotal+=pulVals[i];
	}
	m_ulMean/=m_ulTotal;

	for(k=j=0,pul=m_pulBuffer;j<m_ulHeight && j<ulBins;j++,pul+=m_ulWidth){
		ul=(pulVals[j]*m_ulWidth)/m_ulMostC;
		if(ul<m_ulWidth){
			memset(pul,0,ul*sizeof(ULONG));
			memset(pul+ul,0xff,(m_ulWidth-ul)*sizeof(ULONG));
		}
		else{
			memset(pul,0,m_ulWidth*sizeof(ULONG));
		}
	}
	if(ulMin>=0 && ulMin<m_ulHeight) memset(m_pulBuffer+m_ulWidth*ulMin,0x80,m_ulWidth*sizeof(ULONG));
	if(ulMax>=0 && ulMax<m_ulHeight) memset(m_pulBuffer+m_ulWidth*ulMax,0x80,m_ulWidth*sizeof(ULONG));

/*	
	for(k=j=0;j<m_ulHeight && j<ulBins;j++){
		ul=(pulVals[j]*m_ulWidth)/ulMax;
		for(i=0;i<m_ulWidth;i++,k++){
			if(i<ul) m_pulBuffer[k] = 0xffff00;
			else m_pulBuffer[k] = 0x0000ff;
		}
	}
*/	
	m_pBitmap->SetBitmapBits(4*m_ulHeight*m_ulWidth,m_pulBuffer);
	Invalidate(FALSE);
	PostMessage(WM_PAINT);
}

void CHistogram::OnDestroy(){
	PrintMessage("CHistogram::OnDestroy");
	CWnd::OnDestroy();
	::SendMessage(m_hMsgWnd,UWM_ON_HISTOGRAM_DESTROY,0,0);
}


void CHistogram::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI){
	lpMMI->ptMaxSize.x = lpMMI->ptMaxTrackSize.x = m_ulWndWidth;
	lpMMI->ptMaxSize.y = lpMMI->ptMaxTrackSize.y = m_ulWndHeight;
	lpMMI->ptMinTrackSize.x = lpMMI->ptMinTrackSize.y = 0;
	CWnd::OnGetMinMaxInfo(lpMMI);
}

void CHistogram::OnClose(){
	PrintMessage("CHistogram::OnClose");
	CWnd::OnClose();
}
