// Globals.h: global functions.

LRESULT PrintMessage(HWND hWnd, DWORD dwData, HWND hRxWnd, LPCVOID lpData, DWORD cbData);
LRESULT PrintMessage(DWORD dwData, HWND hRxWnd, LPCVOID lpData, DWORD cbData);
LRESULT PrintMessage(DWORD dwData, LPCVOID lpData, DWORD cbData);
LRESULT PrintMessage(LPCVOID lpData, DWORD cbData);
LRESULT PrintMessage(DWORD dwData, char* lpData);
LRESULT PrintMessage(CString* str);
LRESULT PrintMessage(char* lpData);
LRESULT PrintMessage(int i1,int i2);
LRESULT PrintMessage(RECT r);
LRESULT PrintThreadMessage(DWORD dwData, char* lpData);
LRESULT PrintThreadMessage(char* lpData);
LRESULT PrintErrorMessage(char* lpData);

char	NumberToChar(int);
int		DataTypeToSizeOf(int iDataType);
void*	FindChunk(void *pMultiChunk,ULONG ulMultiChunkSize,const char *strName);

void	SetHighPrecisionClockFrequency();
double	HighPrecisionClock();
double	HighPrecisionClock(_LARGE_INTEGER*);
double	HighPrecisionClockUsec();

inline double HighPrecisionClockUsecFast(double frequencyUsec){
	union _LARGE_INTEGER unionLargeIntegher;
	QueryPerformanceCounter(&unionLargeIntegher);
	return(((double)unionLargeIntegher.LowPart + (((double)unionLargeIntegher.HighPart) * 4294967296.))/frequencyUsec);
}

// Given source buffer(SrcBuffer - pointer to "rect" subregion 
// (X=DestCopyRecordsX*BinningX=SrcCopyRecords, Y=DestCopyRecordsY*BinningY) 
// of a not smaller "rect" region(X=SrcCopyRecords+SrcShiftRecords Y>=DestCopyRecordsY*BinningY)) of USHORTs 
// sets destination buffer (X=DestCopyRecordsX, Y=DestCopyRecordsY) of ULONGs to binned(BinningX,BinningY) values 
inline void InitBuffer(ULONG* DestBuffer,USHORT* SrcBuffer,ULONG* AuxBuffer,
					ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY,
					ULONG BinningX,ULONG BinningY){
	
	const ULONG SrcCopyRecords = DestCopyRecordsX*BinningX;
	register ULONG  *p_dest,*p_ul;
	register USHORT	*p_src;
	register ULONG	i,j,k;
	for(k=0,p_src=SrcBuffer,p_dest=DestBuffer;k<DestCopyRecordsY;k++){
		for(i=0,p_ul=AuxBuffer;i<SrcCopyRecords;i++){
			*(p_ul++)=(ULONG)*(p_src++);
		}
		for(j=1,p_src+=SrcShiftRecords;j<BinningY;j++,p_src+=SrcShiftRecords){
			for(i=0,p_ul=AuxBuffer;i<SrcCopyRecords;i++){
				*(p_ul++)+=(ULONG)*(p_src++);
			}
		}
		for(j=0,p_ul=AuxBuffer;j<DestCopyRecordsX;j++,p_dest++){
			*(p_dest)=(ULONG)*(p_ul++);
			for(i=1;i<BinningX;i++) *p_dest+=(ULONG)*(p_ul++);
		}
	}
}

inline void InitBufferNoAux(ULONG* DestBuffer,USHORT* SrcBuffer,
					ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY,
					ULONG BinningX,ULONG BinningY){
	
	register ULONG  *p_dest,*p_destL;
	register USHORT	*p_src;
	register ULONG	i,j,k;
	for(k=0,p_destL=(p_dest=DestBuffer)+DestCopyRecordsX,p_src=SrcBuffer;
		k<DestCopyRecordsY;
		k++,p_destL=(p_dest+=DestCopyRecordsX)+DestCopyRecordsX){
		for(j=0,*p_dest=0;j<BinningY;j++,p_src+=SrcShiftRecords,p_dest-=DestCopyRecordsX){
			for(;p_dest<p_destL;p_dest++){
				for(i=0;i<BinningX;i++) *p_dest+=(ULONG)*(p_src++);
			}
		}
	}
}

inline void InitBufferFast(ULONG* DestBuffer,USHORT* SrcBuffer,ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY){
	register ULONG  *p_dest=DestBuffer;
	register USHORT	*p_src=SrcBuffer;
	register ULONG	i,j;
	for(j=0;j<DestCopyRecordsY;j++,p_src+=SrcShiftRecords)
		for(i=0;i<DestCopyRecordsX;i++) *(p_dest++)=*(p_src++);
}

// Given source buffer(SrcBuffer - pointer to "rect" subregion 
// (X=DestCopyRecordsX*BinningX=SrcCopyRecords, Y=DestCopyRecordsY*BinningY) 
// of a not smaller "rect" region(X=SrcCopyRecords+SrcShiftRecords Y>=DestCopyRecordsY*BinningY)) of USHORTs 
// augments destination buffer (X=DestCopyRecordsX, Y=DestCopyRecordsY) of ULONGs by binned(BinningX,BinningY) values 
inline void AugmentBuffer(ULONG* DestBuffer,USHORT* SrcBuffer,ULONG* AuxBuffer,
					ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY,
					ULONG BinningX,ULONG BinningY){
	const ULONG SrcCopyRecords = DestCopyRecordsX*BinningX;
	register ULONG  *p_dest,*p_ul;
	register USHORT*	p_src;
	register ULONG	i,j,k;
	for(k=0,p_src=SrcBuffer,p_dest=DestBuffer;k<DestCopyRecordsY;k++){
		for(i=0,p_ul=AuxBuffer;i<SrcCopyRecords;i++){
			*(p_ul++)=(ULONG)*(p_src++);
		}
		for(j=1,p_src+=SrcShiftRecords;j<BinningY;j++,p_src+=SrcShiftRecords){
			for(i=0,p_ul=AuxBuffer;i<SrcCopyRecords;i++){
				*(p_ul++)+=(ULONG)*(p_src++);
			}
		}
		for(j=0,p_ul=AuxBuffer;j<DestCopyRecordsX;j++,p_dest++){
			for(i=0;i<BinningX;i++) *p_dest+=(ULONG)*(p_ul++);
		}
	}
}

inline void AugmentBufferNoAux(ULONG* DestBuffer,USHORT* SrcBuffer,
					ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY,
					ULONG BinningX,ULONG BinningY){
	
	register ULONG  *p_dest;
	register USHORT	*p_src;
	register ULONG	i,j,k,l;
	for(l=0,p_src=SrcBuffer,p_dest=DestBuffer;l<DestCopyRecordsY;l++,p_dest+=DestCopyRecordsX){
		for(j=0;j<BinningY;j++,p_src+=SrcShiftRecords,p_dest-=DestCopyRecordsX){
			for(k=0;k<DestCopyRecordsX;k++,p_dest++){
				for(i=0;i<BinningX;i++) *p_dest+=(ULONG)*(p_src++);
			}
		}
	}
}

inline void AugmentBufferFast(ULONG* DestBuffer,USHORT* SrcBuffer,ULONG SrcShiftRecords,ULONG DestCopyRecordsX,ULONG DestCopyRecordsY){
	register ULONG  *p_dest=DestBuffer;
	register USHORT	*p_src=SrcBuffer;
	register ULONG	i,j;
	for(j=0;j<DestCopyRecordsY;j++,p_src+=SrcShiftRecords){
		for(i=0;i<DestCopyRecordsX;i++) *(p_dest++)+=(ULONG)*(p_src++);
	}
//	PrintMessage("A");
}

inline void FillDisplayBufferShift( USHORT* DestBuffer,ULONG* SrcBuffer,
						ULONG SrcCopyRecordsX,ULONG SrcCopyRecordsY,
						ULONG DestShiftRecords,ULONG DestDataShift){
	register USHORT*	p_dest;
	register ULONG*	p_src;
	register ULONG	i,j;
	for(j=0,p_src=SrcBuffer,p_dest=DestBuffer;j<SrcCopyRecordsY;j++,p_dest+=DestShiftRecords){
		for(i=0;i<SrcCopyRecordsX;i++,p_src++,p_dest++){
			*p_dest=(USHORT)((*p_src)>>DestDataShift);
		}
	}
//	PrintMessage((int)DestDataShift,0);
}

inline void FillDisplayBufferDivide( USHORT* DestBuffer,ULONG* SrcBuffer,
						ULONG SrcCopyRecordsX,ULONG SrcCopyRecordsY,
						ULONG DestShiftRecords,ULONG DestDataDivisor){
	register USHORT*	p_dest;
	register ULONG*	p_src;
	register ULONG	i,j;
	for(j=0,p_src=SrcBuffer,p_dest=DestBuffer;j<SrcCopyRecordsY;j++,p_dest+=DestShiftRecords){
		for(i=0;i<SrcCopyRecordsX;i++,p_src++,p_dest++){
			*p_dest=(USHORT)((*p_src)/DestDataDivisor);
		}
	}
}

inline void SourceToDisplay( USHORT* DestBuffer,USHORT* SrcBuffer,
						ULONG DestCopyBytesX,ULONG DestCopyRecordsY,ULONG DestShiftRecords,ULONG SrcShiftRecords){
	register USHORT*	p_dest=DestBuffer;
	register USHORT*	p_src=SrcBuffer;
	register ULONG	i;
	for(i=0;i<DestCopyRecordsY;i++,p_src+=SrcShiftRecords,p_dest+=DestShiftRecords){
		memcpy(p_dest,p_src,DestCopyBytesX);
	}
}

inline void MinMaxStats(ULONG *pulBuffer,ULONG ulBufferSize,ULONG& ulMin,ULONG& ulMax,ULONG& ulMinC,ULONG& ulMaxC,
						ULONG& ulAverage){
	register ULONG *pul=pulBuffer+1;
	const ULONG *pulMax=pulBuffer+ulBufferSize;
	for(ulAverage=ulMin=ulMax=*pulBuffer,ulMinC=ulMaxC=0;pul<pulMax;pul++){
		if(*pul>ulMax){
			ulMax=*pul;
			ulMaxC=pul-pulBuffer;
		}
		else{
			if(*pul<ulMin){
				ulMin=*pul;
				ulMinC=pul-pulBuffer;
			}
		}
		ulAverage += *pul>>4;
	}
//	ulAverage/=ulBufferSize;
}

inline void HistogramStats(ULONG *pulBuffer,ULONG ulBufferSize,ULONG *pulHistogram,int iBinning){
	const ULONG *pulMax=pulBuffer+ulBufferSize;
	for(register ULONG *pul=pulBuffer;pul<pulMax;pul++) pulHistogram[*pul/iBinning]++;
}

inline ULONG AverageStats(ULONG *pulBuffer,ULONG ulBufferSize){
	const ULONG *pulMax=pulBuffer+ulBufferSize;
	register ULONG ul=0;
	for(register ULONG *pul=pulBuffer;pul<pulMax;) ul+=*(pul++)>>4;
	return(ul/ulBufferSize);
}

BOOL StopGenericThread(HANDLE* hThread,BOOL volatile *pbShutdown,DWORD dwThreadID,const char* strName,HANDLE volatile hEvent = NULL,int iShutdownType = 1);

void StorageToSaveUCHAR(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor);
void StorageToSaveUCHARFast(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nShift);
void StorageToSaveUSHORT(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor);
void StorageToSaveUSHORTFast(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nShift);
void StorageToSaveULONG(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor);
void StorageToSaveFLOAT(void *pSaveBuffer,ULONG *pulStorageBuffer,ULONG nRecords,ULONG nDivisor);

void SlowPowerSpectrum(ULONG ulCount,ULONG *pulBuffer,double *pdSpectrumBuffer,double& dMin,double& dMax);

void InitSeedRan3(long seed);
double Ran3();
int GetRandomNumber(int iLo,int iHi);
void ShuffleList(int iN, int *piList,int iNewHeadNotEqualOldTail);

ULONG COSTExperimentCallback(WPARAM wParam,LPARAM lParam,double dArrivalTimeUsec);
ULONG EPSTExperimentCallback(WPARAM wParam,LPARAM lParam,double dArrivalTimeUsec);

int WritePhysicalPortA(ULONG ulData);
int WritePhysicalPortCL(ULONG ulData);
int ReadPhysicalPortB(ULONG& ulData);
int ReadPhysicalPortCH(ULONG& ulData);
