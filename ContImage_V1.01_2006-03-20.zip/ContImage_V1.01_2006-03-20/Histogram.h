#if !defined(AFX_HISTOGRAM_H__EEADC175_F551_4E49_B979_E01372D614B0__INCLUDED_)
#define AFX_HISTOGRAM_H__EEADC175_F551_4E49_B979_E01372D614B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Histogram.h : header file
//

#define HISTOGRAM_WIDTH_RIGHT_PANEL 120

/////////////////////////////////////////////////////////////////////////////
// CHistogram window

class CHistogram : public CWnd
{
// Construction
public:
	CHistogram();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistogram)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual BOOL Create(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hwndParent, HMENU nIDorHMenu = NULL, LPVOID lpParam = NULL );
	virtual BOOL Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHistogram();
	void CreateHistogramBitmap();
	void UpdateHistogram(ULONG ulBins,ULONG *pulVals,ULONG ulMin,ULONG ulMax);

	// Generated message map functions
protected:
	//{{AFX_MSG(CHistogram)
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	char*	m_strWindowName;
	HWND	m_hMsgWnd;
	CFont	m_cFont;
	COLORREF	m_crTextColor;
	COLORREF	m_crBkColor;
	CBitmap* m_pBitmap;
	ULONG*	m_pulBuffer;
	ULONG	m_ulWidth,m_ulHeight;
	ULONG	m_ulMost,m_ulMostC;
	ULONG	m_ulLeast,m_ulLeastC;
	ULONG	m_ulMax,m_ulMaxC;
	ULONG	m_ulMin,m_ulMinC;
	ULONG	m_ulTotal,m_ulMean;

	ULONG m_ulMostP,m_ulMostCP;
	ULONG m_ulLeastP,m_ulLeastCP;
	ULONG m_ulMaxP,m_ulMaxCP;
	ULONG m_ulMinP,m_ulMinCP;
	ULONG m_ulMeanP,m_ulTotalP;

	ULONG	m_ulWndWidth,m_ulWndHeight;

public:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTOGRAM_H__EEADC175_F551_4E49_B979_E01372D614B0__INCLUDED_)
