// FocusDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "FocusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFocusDlg dialog


CFocusDlg::CFocusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFocusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFocusDlg)
	m_iFocusDynamicMode = -1;
	m_iFocusSaveMode = -1;
	m_nFilterWidth = 0;
	m_nWaveLength = 0;
	m_iFocusBinningSpatialROI = 0;
	m_iFocusBinningTemporalROI = 0;
	m_iFocusBinningSpatialExperiment = 0;
	m_iFocusBinningTemporalExperiment = 0;
	//}}AFX_DATA_INIT
	m_bMainROIOnly=TRUE;
}


void CFocusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFocusDlg)
	DDX_Radio(pDX, IDC_FOCUS_RADIO_ROI, m_iFocusDynamicMode);
	DDX_Radio(pDX, IDC_FOCUS_RADIO_SAVE_JPG, m_iFocusSaveMode);
	DDX_Text(pDX, IDC_FOCUS_FILTER_WIDTH, m_nFilterWidth);
	DDX_Text(pDX, IDC_FOCUS_WAVE_LENGTH, m_nWaveLength);
	DDX_Text(pDX, IDC_FOCUS_BINNING_SPATIAL_ROI, m_iFocusBinningSpatialROI);
	DDV_MinMaxInt(pDX, m_iFocusBinningSpatialROI, 1, 512);
	DDX_Text(pDX, IDC_FOCUS_BINNING_TEMPORAL_ROI, m_iFocusBinningTemporalROI);
	DDV_MinMaxInt(pDX, m_iFocusBinningTemporalROI, 1, 65536);
	DDX_Text(pDX, IDC_FOCUS_BINNING_SPATIAL_EXPERIMENT, m_iFocusBinningSpatialExperiment);
	DDX_Text(pDX, IDC_FOCUS_BINNING_TEMPORAL_EXPERIMENT, m_iFocusBinningTemporalExperiment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFocusDlg, CDialog)
	//{{AFX_MSG_MAP(CFocusDlg)
	//}}AFX_MSG_MAP
	ON_CONTROL_RANGE(BN_CLICKED, IDC_FOCUS_RADIO_ROI, IDC_FOCUS_RADIO_EXPERIMENT, OnUpdateFocusRadio)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_FOCUS_RADIO_SAVE_JPG, IDC_FOCUS_RADIO_SAVE_BMP, OnUpdateFocusSaveMode)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFocusDlg message handlers

BOOL CFocusDlg::OnInitDialog(){
	CDialog::OnInitDialog();
	GetDlgItem(IDC_FOCUS_RADIO_FAST)->EnableWindow(m_bMainROIOnly);
	GetDlgItem(IDC_FOCUS_BINNING_SPATIAL_FAST)->SetWindowText("1");	
	GetDlgItem(IDC_FOCUS_BINNING_TEMPORAL_FAST)->SetWindowText("1");
	OnUpdateFocusRadio(m_iFocusDynamicMode+IDC_FOCUS_RADIO_ROI);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFocusDlg::OnUpdateFocusRadio(UINT nID){
	GetDlgItem(IDC_FOCUS_BINNING_SPATIAL_ROI)->EnableWindow(nID == IDC_FOCUS_RADIO_ROI);
	GetDlgItem(IDC_FOCUS_BINNING_TEMPORAL_ROI)->EnableWindow(nID == IDC_FOCUS_RADIO_ROI);
	GetDlgItem(IDC_FOCUS_BINNING_SPATIAL_FAST)->EnableWindow(nID == IDC_FOCUS_RADIO_FAST);
	GetDlgItem(IDC_FOCUS_BINNING_TEMPORAL_FAST)->EnableWindow(nID == IDC_FOCUS_RADIO_FAST);
	GetDlgItem(IDC_FOCUS_BINNING_SPATIAL_EXPERIMENT)->EnableWindow(nID == IDC_FOCUS_RADIO_EXPERIMENT);
	GetDlgItem(IDC_FOCUS_BINNING_TEMPORAL_EXPERIMENT)->EnableWindow(nID == IDC_FOCUS_RADIO_EXPERIMENT);
}

void CFocusDlg::OnUpdateFocusSaveMode(UINT nID){
}
