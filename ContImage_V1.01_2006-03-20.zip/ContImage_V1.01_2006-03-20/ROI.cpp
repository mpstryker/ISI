// ROI.cpp : implementation of the CROI class.
//

#include "stdafx.h"
#include "ContImage.h"


#include "ROI.h"
#include "ROIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CROI::CROI(UINT cx,UINT cy){
	m_sizeROIMain.cx=cx;
	m_sizeROIMain.cy=cy;

	m_rectROIMain.left=0;
	m_rectROIMain.right=cx-1;
	m_rectROIMain.top=0;
	m_rectROIMain.bottom=cy-1;

	m_ROIMain.bHidden=FALSE;
	m_ROIMain.bRealized=FALSE;
	m_ROIMain.bModified=FALSE;
	m_ROIMain.iNumber=0;
	m_ROIMain.pRect=&m_rectROIMain;

	AddHead(&m_ROIMain);

	m_bKeepOriginalNumbers=FALSE;
	m_bMaximizeNewNumbers=TRUE;

	PrintMessage(m_sizeROIMain.cx,m_sizeROIMain.cy);

}

CROI::~CROI(){
	RemoveAll();
}

void CROI::ResetMainROI(UINT cx,UINT cy){
	m_sizeROIMain.cx=cx;
	m_sizeROIMain.cy=cy;

	m_rectROIMain.left=0;
	m_rectROIMain.right=cx-1;
	m_rectROIMain.top=0;
	m_rectROIMain.bottom=cy-1;
}

void CROI::RescaleAllROI(UINT cx,UINT cy){
	if(cx<1 || cy<1 || cx>1024 || cy>1024){
		PrintMessage(LEVEL_ERROR,"CROI::RescaleAllROI: Cannot rescale ROIs");
		return;
	}
	double dx=(double)cx/(double)m_sizeROIMain.cx;
	double dy=(double)cy/(double)m_sizeROIMain.cy;
	CRect *prect;
	for(int i=1;i<GetCount();i++){
		prect=GetAt(FindIndex(i))->pRect;
		prect->left=(int)(floor((double)prect->left*dx));
		prect->right=(int)(floor((double)prect->right*dx));
		prect->top=(int)(floor((double)prect->top*dy));
		prect->bottom=(int)(floor((double)prect->bottom*dy));
	}
	
	ResetMainROI(cx,cy);
}


int CROI::GetIndex(CRect* pRect){
	for(int i=0;i<GetCount();i++){
		if(pRect==GetAt(FindIndex(i))->pRect) return(i);
	}
	return(-1);
}

int CROI::GetSeqIndex(CRect* pRect){
	if(GetHead()->bRealized) return(GetIndex(pRect));
	else return(GetIndex(pRect)-1);
}

int CROI::GetNumber(CRect* pRect){
	for(int i=0;i<GetCount();i++){
		if(pRect==GetAt(FindIndex(i))->pRect) return(GetAt(FindIndex(i))->iNumber);
	}
	return(-1);
}

int CROI::AddROI(CRect* pRect,int iNumber){
	if(GetCount() == MAX_NROI){
		PrintMessage(LEVEL_ERROR,"Max number of ROIs is reached");
		return(0);
	}
	ROI *pROI = new ROI;
	if(iNumber) pROI->iNumber=iNumber;
	else pROI->iNumber=GetAvailableNumber();
	pROI->pRect=pRect;
	pROI->bHidden=FALSE;
	pROI->bRealized=FALSE;
	pROI->bModified=FALSE;
	AddTail(pROI);
	return(GetCount());
}

int CROI::GetAvailableNumber(){
	if(m_bKeepOriginalNumbers){
		int i,j;
		if(m_bMaximizeNewNumbers){
			for(i=1,j=0;i<GetCount();i++){
				if(j<GetAt(FindIndex(i))->iNumber) j=GetAt(FindIndex(i))->iNumber;
			}
			return(j+1);
		}
		else{
			for(j=1;;j++){
				for(i=1;i<GetCount() && j!=GetAt(FindIndex(i))->iNumber;i++);
				if(i==GetCount()) return(j);
			}
		}
	}
	else return(GetCount());
}

int CROI::RemoveROI(CRect* pRect){
	if(pRect == GetHead()->pRect){
		GetHead()->bHidden=TRUE;
		GetHead()->bRealized=FALSE;
	}
	else{ 
		ROI* pROI=FindROI(pRect);
		if(!pROI) return(0);
		RemoveAt(Find(pROI));
		delete pRect;
		delete pROI;
		if(!m_bKeepOriginalNumbers){
			for(int i=0;i<GetCount();i++) GetAt(FindIndex(i))->iNumber=i;
		}
	}
	return(GetCount());
}

int CROI::GetROI(CRect** ppRect){
	ROI* pROI=GetUnrealizedROI();
	if(pROI){
		pROI->bRealized=TRUE;
		return(GetIndex(*ppRect=pROI->pRect));
	}
	else{
		*ppRect=NULL;
		return(-1);
	}
}

ROI* CROI::GetUnrealizedROI(){
	for(int i=0;i<GetCount();i++) 
		if(!GetAt(FindIndex(i))->bRealized && !GetAt(FindIndex(i))->bHidden){
			return(GetAt(FindIndex(i)));
		}
	return(NULL);
}

ROI* CROI::FindROI(CRect* pRect){
	for(int i=1;i<GetCount();i++){
		if(pRect==GetAt(FindIndex(i))->pRect) return(GetAt(FindIndex(i)));
	}
	return(NULL);
}

ROI* CROI::GetHeadROI(){
	if(FindIndex(1)) return(GetAt(FindIndex(1)));
	else return(NULL);
}

ROI* CROI::GetNextROI(ROI *pROI){
	POSITION pos=Find(pROI);
	if(pos) if(GetNext(pos) && pos) return(GetAt(pos));
	return(NULL);
}

float CROI::GetTotalArea(ULONG *pulTotalArea,ULONG *pulMainArea){
	ULONG ulMainArea=m_sizeROIMain.cx*m_sizeROIMain.cy;
	ULONG ulTotalArea=0;
	if(!ulMainArea){
		PrintMessage(LEVEL_ERROR,"CROI::GetTotalArea: Total disaster, MainArea=0");
		return(-1);
	}
	if(GetHead()->bRealized) ulTotalArea=ulMainArea;
	CRect *prect;
	for(int i=1;i<GetCount();i++){
		prect=GetAt(FindIndex(i))->pRect;
		ulTotalArea+=(ULONG)(prect->right-prect->left)*(ULONG)(prect->bottom-prect->top);
	}
	if(pulTotalArea) *pulTotalArea=ulTotalArea;
	if(pulMainArea) *pulMainArea=ulMainArea;
	return((float)((double)ulTotalArea/(double)ulMainArea));
}

BOOL CROI::EditROI(int iBinningX,int iBinningY){
	CROIDlg dlg;
	dlg.m_pCROI=this;
	dlg.m_bKeepOriginalNumbers=m_bKeepOriginalNumbers;
	dlg.m_bMaximizeNewNumbers=m_bMaximizeNewNumbers;
	if(dlg.DoModal()==IDOK){
		m_bMaximizeNewNumbers=dlg.m_bMaximizeNewNumbers;
		if(m_bKeepOriginalNumbers!=dlg.m_bKeepOriginalNumbers){
			m_bKeepOriginalNumbers=dlg.m_bKeepOriginalNumbers;
			if(!m_bKeepOriginalNumbers) for(int i=0;i<GetCount();i++) GetAt(FindIndex(i))->iNumber=i;
			return(TRUE);
		}
	}	
	return(FALSE);
}

