/******************************************************************************
 *
 * MODULE
 *    ifcbuild.h
 *
 * REVISION INFORMATION
 *    $Logfile: /ifc/include/Ifcbuild.h $
 *    $Revision: 17 $
 *    $Modtime: 4/30/01 3:00p $
 *
 * ABSTRACT
 *    IFC Build Version Include File
 *
 * TECHNICAL NOTES
 *
 *
 * Copyright (c) 1999-2000 Imaging Technology Incorporated  All rights reserved.
 *
 ******************************************************************************/

#ifndef _IFCBUILD_DEF
#define _IFCBUILD_DEF

#define VER_INTERNALNAME_STR        "Build 70.00"

#define VER_CORE_VERSION             5,2,0,0
#define VER_CORE_VERSION_STR        "5.2.0.0"

#define VER_CM_STUB_VERSION          5,2,0,0
#define VER_CM_STUB_VERSION_STR     "5.2.0.0"

#define VER_PA_STUB_VERSION          5,2,0,0
#define VER_PA_STUB_VERSION_STR     "5.2.0.0"

#define IFC_MAX_VER_CMPT_FILES	10	/* Max number of files in a component */
#define IFC_MAX_VER_LEN		20

#define IFC_CORE_LIBNAME "ifc15.lib"
#define IFC_DISPLAY_LIBNAME "ifcdsp15.lib"

#define IFC_DRIVER_DLL_NAME "ifcdrv15.dll"

#define IFC_CSC_SERVICE_NAME "ifccsc15"
#define IFC_CSC_SERVICE_NAMEW L"ifccsc15"

#define IFC_IFCUI_DLL_NAME "ifcui15.dll"


#endif
