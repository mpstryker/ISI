#if !defined(AFX_TRACE_H__F008DD81_F709_479E_A70F_3621E786331F__INCLUDED_)
#define AFX_TRACE_H__F008DD81_F709_479E_A70F_3621E786331F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Trace.h : header file
//

typedef struct TRACE_STATS{
	BOOL  bNew;
	ULONG ulCount; 
	ULONG ulCurrentPos;
	double dSumOfVals;
	double dSumOfValsSquared;
	ULONG ulMin;
	ULONG ulMax;
	ULONG ulMinPos;
	ULONG ulMaxPos;
	ULONG ulMinPrev;
	ULONG ulMaxPrev;
	ULONG ulMinPosPrev;
	ULONG ulMaxPosPrev;
	double	dSpectrumMin;
	double	dSpectrumMax;
} TRACE_STATS;

#define MAX_NTRACES	4

/////////////////////////////////////////////////////////////////////////////
// CTrace frame

class CTrace : public CMiniFrameWnd
{
//	DECLARE_DYNCREATE(CTrace)
public:
	CTrace(ULONG ulInterFrameTime,int = MAX_NTRACES);           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrace)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual BOOL Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName);
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL CreateTraceBitmap();
	BOOL AddTrace(const char *strTraceTag);
	BOOL SubstituteTrace(int iTrace,const char *strTraceTag);
	BOOL RemoveTrace(int iTrace);
	BOOL RemoveTrace(const char *strTraceTag);

	void UpdateTrace(ULONG ulNTraces,ULONG *pulVals,ULONG ulMin,ULONG ulMax);

	void UpdateInterFrameTime(ULONG ulInterFrameTime);

protected:
	virtual ~CTrace();

	// Generated message map functions
	//{{AFX_MSG(CTrace)
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnClose();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	char*	m_strWindowName;
	HWND	m_hMsgWnd;
	CFont	m_cFont;
	COLORREF	m_crTextColor;
	COLORREF	m_crBkColor;

	CBitmap* m_pBitmap;
	CBitmap* m_pSpectrumBitmap;

	ULONG*	m_pulBuffer;
	ULONG*	m_pulSpectrumBuffer;

	ULONG	m_ulWidth,m_ulHeight;
	ULONG	m_ulSpectrumWidth,m_ulSpectrumHeight;

	ULONG	m_ulMax,m_ulMin;
	ULONG	m_ulMaxP,m_ulMinP;

	ULONG	m_ulWndWidth,m_ulWndHeight;

	int		m_iMaxNTraces;
	int		m_iNTraces;
	int		m_iTraceCount;
	int		m_piTraceMap[MAX_NTRACES];
	char*	m_pstrTraceTag[MAX_NTRACES];
	TRACE_STATS	m_pTraceStats[MAX_NTRACES];

	ULONG*	m_ppulTraces[MAX_NTRACES];
	double*	m_ppdSpectrumTraces[MAX_NTRACES];

	ULONG	m_pulTraceColor[MAX_NTRACES];
	ULONG	m_pulTipColor[MAX_NTRACES];
	COLORREF	m_pCRTraceColor[MAX_NTRACES];
	COLORREF	m_pCRTipColor[MAX_NTRACES];
	ULONG	m_ulHighlightColor;
	RECT	m_rectInvalidate;
	RECT	m_rectTextPanel;
	BOOL	m_bUpdateTraces;

	ULONG	m_ulSpectrumUpdateCount;
	ULONG	m_ulInterFrameTimeUsec;
	double	m_dFrequencyHz;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACE_H__F008DD81_F709_479E_A70F_3621E786331F__INCLUDED_)
