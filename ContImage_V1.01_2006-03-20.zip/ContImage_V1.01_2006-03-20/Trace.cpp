// Trace.cpp : implementation file
//
// Val: 11-19-2002 added update of m_ulInterFrameTimeUsec (T-binning change) 
//		moved trace initialization from AddTrace to UpdateTrace to deal with underbinned ini values
#include "stdafx.h"
#include "contimage.h"
#include "Trace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TRACE_WIDTH_RIGHT_PANEL 100
#define TRACE_BORDER_TOP	2
#define TRACE_BORDER_BOTTOM 2

#define TRACE_TEXT_SHIFT 6

#define TRACE_SPECTRUM_UPDATE 20

#define TRACE_SPECTRUM_SET_FIXED_LOWER_LIMIT 1
#define TRACE_SPECTRUM_LOWER_LIMIT_VALUE     0

static const UINT UWM_ON_TRACE_DESTROY = ::RegisterWindowMessage(_T("UWM_ON_TRACE_DESTROY"));

/////////////////////////////////////////////////////////////////////////////
// CTrace

//IMPLEMENT_DYNCREATE(CTrace, CMiniFrameWnd)

CTrace::CTrace(ULONG ulInterFrameTime,int iNTraces){

	m_ulInterFrameTimeUsec=ulInterFrameTime;
	m_iMaxNTraces= iNTraces < MAX_NTRACES ? iNTraces : MAX_NTRACES;

	m_iNTraces = 0;
	m_iTraceCount = 0;

	memset(m_ppulTraces,0,MAX_NTRACES*sizeof(ULONG*));
	memset(m_ppdSpectrumTraces,0,MAX_NTRACES*sizeof(double*));

	m_pulBuffer=NULL;
	m_pulSpectrumBuffer=NULL;

	m_hMsgWnd=NULL;
	m_strWindowName=NULL;

	m_pBitmap = NULL;
	m_pSpectrumBitmap = NULL;

	VERIFY(m_cFont.CreatePointFont(90, "MS Sans Serif"));
	m_crTextColor=0xffffff;
	m_crBkColor=0x404040;
//	m_crBkColor=0xff0000;

	m_ulMax=m_ulMaxP=0;
	m_ulMin=m_ulMinP=0;

	m_pulTraceColor[0]=0xff0000;
	m_pulTraceColor[1]=0x0000ff;
	m_pulTraceColor[2]=0xff00ff;
	m_pulTraceColor[3]=0x009000;

	m_pulTipColor[0]=0x00ff00;
	m_pulTipColor[1]=0xffff00;
	m_pulTipColor[2]=0x00ffff;
	m_pulTipColor[3]=0xffffff;

	union {DWORD dw;BYTE b[4];} dwb;
	BYTE b;
	for(int i=0;i<MAX_NTRACES;i++){
		dwb.dw=m_pulTraceColor[i];
		b=dwb.b[0];
		dwb.b[0]=dwb.b[2];
		dwb.b[2]=b;
		m_pCRTraceColor[i]=dwb.dw;
		dwb.dw=m_pulTipColor[i];
		b=dwb.b[0];
		dwb.b[0]=dwb.b[2];
		dwb.b[2]=b;
		m_pCRTipColor[i]=dwb.dw;
	}

	m_ulHighlightColor=0x606060;

	m_bUpdateTraces = FALSE;

	m_ulSpectrumUpdateCount = 0;
	m_dFrequencyHz=0.0;

	char str[64];
	sprintf(str,"CTrace::CTrace %i",m_iMaxNTraces);
	PrintMessage(LEVEL_NORMAL,str);
}

CTrace::~CTrace(){
	for(int i=0;i<m_iNTraces;i++){
		if(m_ppulTraces[i]) free(m_ppulTraces[i]);
		if(m_ppdSpectrumTraces[i]) free(m_ppdSpectrumTraces[i]);
	}
	if(m_pulBuffer) free(m_pulBuffer);
	if(m_pulSpectrumBuffer) free(m_pulSpectrumBuffer);
	if(m_strWindowName) free(m_strWindowName);
}


BEGIN_MESSAGE_MAP(CTrace, CMiniFrameWnd)
	//{{AFX_MSG_MAP(CTrace)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_GETMINMAXINFO()
	ON_WM_CLOSE()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrace message handlers

BOOL CTrace::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext){
	
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

BOOL CTrace::Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName){
	PrintMessage("CTrace::Create");
	char str[256];
	m_ulWidth=iWidth;
	m_ulHeight=iHeight;
	if(m_ulWidth<2 || m_ulHeight<2+TRACE_BORDER_BOTTOM+TRACE_BORDER_TOP) return(FALSE);

	m_ulSpectrumWidth = 2+(m_ulWidth-1)/2;
	m_ulSpectrumHeight = m_ulHeight;

	m_rectInvalidate.top=TRACE_BORDER_TOP;
	m_rectInvalidate.bottom=m_ulHeight-TRACE_BORDER_BOTTOM;

	m_rectTextPanel.left=m_ulWidth+1;
	m_rectTextPanel.right=m_ulWidth+TRACE_WIDTH_RIGHT_PANEL-1;
	m_rectTextPanel.top=1;
	m_rectTextPanel.bottom=m_ulHeight-1;

	m_ulWndWidth=m_ulWidth+TRACE_WIDTH_RIGHT_PANEL+2*GetSystemMetrics(SM_CXSIZEFRAME)+m_ulSpectrumWidth;
	m_ulWndHeight=m_ulHeight+2*GetSystemMetrics(SM_CYSIZEFRAME)+GetSystemMetrics(SM_CYSMCAPTION);

	m_hMsgWnd=hwndParent;
	m_strWindowName=(char*)malloc(strlen(strWindowName)+1);
	memcpy(m_strWindowName,strWindowName,strlen(strWindowName)+1);
	sprintf(str,"%s %c",m_strWindowName,iNumber);
	return CWnd::CreateEx( 0,lpszClassName,_T(str),WS_POPUPWINDOW | WS_OVERLAPPEDWINDOW,x,y,
		m_ulWndWidth,m_ulWndHeight,	hwndParent, NULL,NULL);
}

void CTrace::OnPaint(){
	CPaintDC dc(this); // device context for painting
	char str[64];
	
	int i,j;
	TRACE_STATS *pTS;
	RECT rectFill;
	CPen pen,*pPen;
	CBrush brush,*pBrush;
	CBitmap* pOldBitmap=NULL;
	CDC DCMem;

	DCMem.CreateCompatibleDC(NULL);
	if(m_pBitmap){
		pOldBitmap = DCMem.SelectObject(m_pBitmap);
		dc.BitBlt(0,0,m_ulWidth,m_ulHeight,&DCMem,0,0,SRCCOPY);
	}
	if(m_pSpectrumBitmap){
		if(pOldBitmap) DCMem.SelectObject(m_pSpectrumBitmap);
		else pOldBitmap = DCMem.SelectObject(m_pSpectrumBitmap);
		dc.BitBlt(m_ulWidth+TRACE_WIDTH_RIGHT_PANEL,0,m_ulSpectrumWidth,m_ulSpectrumHeight,&DCMem,0,0,SRCCOPY);
	}
	if(pOldBitmap) DCMem.SelectObject(pOldBitmap);
	DCMem.DeleteDC();

	dc.FillSolidRect(&m_rectTextPanel,m_crBkColor);

	for(i=0;i<m_iNTraces;i++){
		j=m_piTraceMap[i];
		pTS=&(m_pTraceStats[j]);
		sprintf(str," %s",m_pstrTraceTag[j]);
		
		rectFill.left=m_ulWidth+5;
		rectFill.top=((2*i+1)*m_ulHeight)/10;
		rectFill.right=rectFill.left+12;
		rectFill.bottom=rectFill.top+12;
		pen.CreatePen(PS_SOLID,1,m_pCRTipColor[j]);
		brush.CreateSolidBrush(m_pCRTraceColor[j]);
		pPen = dc.SelectObject(&pen);
		pBrush = dc.SelectObject(&brush);
		dc.Rectangle(&rectFill);
		dc.SelectObject(pPen);
		dc.SelectObject(pBrush);
		pen.DeleteObject();
		brush.DeleteObject();

		dc.SetBkColor(m_crBkColor);
		dc.TextOut(m_ulWidth+20,((2*i+1)*m_ulHeight)/10-TRACE_TEXT_SHIFT,str,strlen(str));
		sprintf(str,"    %lu %lu",(pTS->ulMax+pTS->ulMin)/2,(pTS->ulMax-pTS->ulMin)/2);
		dc.TextOut(m_ulWidth+20,((2*i+2)*m_ulHeight)/10-TRACE_TEXT_SHIFT,str,strlen(str));
	}
	sprintf(str,"   F = %.2fHz",m_dFrequencyHz);
	dc.TextOut(m_ulWidth+16,(9*m_ulHeight)/10-TRACE_TEXT_SHIFT+2,str,strlen(str));
	
	// Do not call CMiniFrameWnd::OnPaint() for painting messages
}

void CTrace::UpdateInterFrameTime(ULONG ulInterFrameTime){
	m_ulInterFrameTimeUsec=ulInterFrameTime;
}

	
BOOL CTrace::CreateTraceBitmap(){
	DWORD dwBufferSize=4*m_ulWidth*m_ulHeight;
	DWORD dwSpectrumBufferSize=4*m_ulSpectrumWidth*m_ulSpectrumHeight;
	ULONG i,j,k;

	if(m_pBitmap || m_pSpectrumBitmap){
		PrintMessage(LEVEL_ERROR,"Bitmaps have been created already");
		return(FALSE);
	}

	if(!(m_pulBuffer=(ULONG*)calloc(dwBufferSize,1))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for m_pulBuffer");
		return(FALSE);
	}
	if(!(m_pulSpectrumBuffer=(ULONG*)calloc(dwSpectrumBufferSize,1))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for dwSpectrumBufferSize");
		return(FALSE);
	}

	for(k=j=0;j<m_ulHeight;j++){
		m_pulBuffer[k++]=RGB(255,255,255);
		for(i=1;i<m_ulWidth-1;i++,k++) m_pulBuffer[k] = RGB(0,(j*255)/m_ulHeight,(i*255)/m_ulWidth);
		m_pulBuffer[k++]=RGB(255,255,255);
	}
	if(TRACE_BORDER_TOP>0) memset(m_pulBuffer,0xff,sizeof(ULONG)*m_ulWidth);
	if(TRACE_BORDER_TOP>1) memset(m_pulBuffer+m_ulWidth,0x00,sizeof(ULONG)*m_ulWidth*(TRACE_BORDER_TOP-1));
	if(TRACE_BORDER_BOTTOM>1) memset(m_pulBuffer+m_ulWidth*(m_ulHeight-TRACE_BORDER_BOTTOM),0x00,sizeof(ULONG)*m_ulWidth*(TRACE_BORDER_BOTTOM-1));
	if(TRACE_BORDER_BOTTOM>0) memset(m_pulBuffer+m_ulWidth*(m_ulHeight-1),0xff,sizeof(ULONG)*m_ulWidth);

	for(k=j=0;j<m_ulSpectrumHeight;j++){
		m_pulSpectrumBuffer[k++]=RGB(255,255,255);
		for(i=1;i<m_ulSpectrumWidth-1;i++,k++) m_pulSpectrumBuffer[k] = RGB((j*255)/m_ulSpectrumHeight,(i*255)/m_ulSpectrumWidth,0);
		m_pulSpectrumBuffer[k++]=RGB(255,255,255);
	}
	if(TRACE_BORDER_TOP>0) memset(m_pulSpectrumBuffer,0xff,sizeof(ULONG)*m_ulSpectrumWidth);
	if(TRACE_BORDER_TOP>1) memset(m_pulSpectrumBuffer+m_ulSpectrumWidth,0x00,sizeof(ULONG)*m_ulSpectrumWidth*(TRACE_BORDER_TOP-1));
	if(TRACE_BORDER_BOTTOM>1) memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*(m_ulSpectrumHeight-TRACE_BORDER_BOTTOM),0x00,sizeof(ULONG)*m_ulSpectrumWidth*(TRACE_BORDER_BOTTOM-1));
	if(TRACE_BORDER_BOTTOM>0) memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*(m_ulSpectrumHeight-1),0xff,sizeof(ULONG)*m_ulSpectrumWidth);

	m_pBitmap = new CBitmap;
	m_pSpectrumBitmap = new CBitmap;
	CDC* pDC = GetDC();

	m_pBitmap->CreateCompatibleBitmap(pDC,m_ulWidth,m_ulHeight);
	m_pBitmap->SetBitmapBits(dwBufferSize,m_pulBuffer);

	m_pSpectrumBitmap->CreateCompatibleBitmap(pDC,m_ulSpectrumWidth,m_ulSpectrumHeight);
	m_pSpectrumBitmap->SetBitmapBits(dwSpectrumBufferSize,m_pulSpectrumBuffer);

	pDC->SelectObject(&m_cFont);
	pDC->SetBkColor(m_crBkColor);
	pDC->SetTextColor(m_crTextColor);

	ReleaseDC(pDC);

	return(TRUE);
}

BOOL CTrace::AddTrace(const char *strTraceTag){
	int i,j;
	int iCurrentTrace;
/*	
	for(i=0;i<m_iNTraces;i++){
		if(!strcmp(strTraceTag,m_pstrTraceTag[m_piTraceMap[i]])){
			PrintMessage(LEVEL_NORMAL,m_pstrTraceTag[m_piTraceMap[i]]);
			PrintMessage(LEVEL_NORMAL,"Trace has been added already");
			return(FALSE);
		}
	}
*/
	if(m_iNTraces!=m_iMaxNTraces){
		if(!(m_ppulTraces[m_iNTraces]=(ULONG*)calloc(m_ulWidth,sizeof(ULONG)))){
			PrintMessage(LEVEL_ERROR,"Cannot allocate for m_ppulTraces[]");
			return(FALSE);
		}
		if(!(m_ppdSpectrumTraces[m_iNTraces]=(double*)calloc(m_ulSpectrumWidth,sizeof(double)))){
			PrintMessage(LEVEL_ERROR,"Cannot allocate for m_ppdSpectrumTraces[]");
			return(FALSE);
		}
		iCurrentTrace=m_iNTraces;

		for(j=0;j<m_iMaxNTraces;j++){
			for(i=0;i<m_iNTraces;i++) if(j==m_piTraceMap[i]) break;
			if(i==m_iNTraces) break;
		}
		if(j==m_iMaxNTraces){
			PrintMessage(LEVEL_ERROR,"CTrace::AddTrace Cannot find empty slot");
			return(FALSE);
		}

		m_piTraceMap[iCurrentTrace]=j;
		m_iNTraces++;
	}
	else{
		iCurrentTrace=m_iTraceCount%m_iMaxNTraces;
		free(m_pstrTraceTag[m_piTraceMap[iCurrentTrace]]);
	}
	char str[128];
	sprintf(str,"CTrace::AddTrace %i %i",iCurrentTrace,m_piTraceMap[iCurrentTrace]);
	PrintMessage(LEVEL_HIGH,str);

	i=m_piTraceMap[iCurrentTrace];
	m_pstrTraceTag[i]=strdup(strTraceTag);

	TRACE_STATS *pTS=&(m_pTraceStats[i]);

	pTS->bNew=TRUE; 
	pTS->ulCount=m_ulWidth; 
	pTS->ulCurrentPos=0;
	pTS->ulMinPos=0;
	pTS->ulMaxPos=0;
	pTS->ulMinPosPrev=0;
	pTS->ulMaxPosPrev=0;

//	m_bUpdateTraces = TRUE;

	m_iTraceCount++;
	return(TRUE);
}

BOOL CTrace::SubstituteTrace(int iTrace,const char *strTraceTag){
	int i;
/*	
	for(i=0;i<m_iNTraces;i++){
		if(!strcmp(strTraceTag,m_pstrTraceTag[m_piTraceMap[i]])){
			PrintMessage(LEVEL_NORMAL,m_pstrTraceTag[m_piTraceMap[i]]);
			PrintMessage(LEVEL_NORMAL,"Trace has been added already");
			return(FALSE);
		}
	}
*/
	if(iTrace>=m_iNTraces) return(FALSE);

	free(m_pstrTraceTag[m_piTraceMap[iTrace]]);

	char str[128];
	sprintf(str,"CTrace::SubstituteTrace %i %i",iTrace,m_piTraceMap[iTrace]);
	PrintMessage(LEVEL_HIGH,str);

	i=m_piTraceMap[iTrace];
	m_pstrTraceTag[i]=strdup(strTraceTag);

	TRACE_STATS *pTS=&(m_pTraceStats[i]);

	pTS->bNew=TRUE; 
	pTS->ulCount=m_ulWidth; 
	pTS->ulCurrentPos=0;
	pTS->ulMinPos=0;
	pTS->ulMaxPos=0;
	pTS->ulMinPosPrev=0;
	pTS->ulMaxPosPrev=0;

//	m_bUpdateTraces = TRUE;

	return(TRUE);
}

BOOL CTrace::RemoveTrace(int iTrace){
	if(iTrace>=m_iNTraces) return(FALSE);
	if(!m_ppulTraces[iTrace]) return(FALSE);
	free(m_ppulTraces[iTrace]);
	m_ppulTraces[iTrace] = NULL;
	free(m_ppdSpectrumTraces[iTrace]);
	m_ppdSpectrumTraces[iTrace] = NULL;
	free(m_pstrTraceTag[m_piTraceMap[iTrace]]);
	m_pstrTraceTag[m_piTraceMap[iTrace]]=NULL;

	for(int i=iTrace+1;i<m_iNTraces;i++){
		m_ppulTraces[i-1]=m_ppulTraces[i];
		m_ppdSpectrumTraces[i-1]=m_ppdSpectrumTraces[i];
		m_piTraceMap[i-1]=m_piTraceMap[i];
	}
	m_ppulTraces[i-1]=NULL;
	m_ppdSpectrumTraces[i-1]=NULL;
	m_iNTraces--;
	m_bUpdateTraces = TRUE;
	return(TRUE);
}

BOOL CTrace::RemoveTrace(const char *strTraceTag){
	if(!m_iNTraces) return(FALSE);
	int i;
	for(i=0;strcmp(strTraceTag,m_pstrTraceTag[m_piTraceMap[i]]) && i<m_iNTraces;i++);
	if(i==m_iNTraces){
		PrintMessage(LEVEL_ERROR,"Cannot find trace tag");
		return(FALSE);
	}
	return(RemoveTrace(i));
}

void CTrace::UpdateTrace(ULONG ulNTraces,ULONG *pulVals,ULONG ulRangeMin,ULONG ulRangeMax){
	ULONG i,j,k;
	ULONG ulViewHeight;
	ULONG ulMin,ulMax;
	ULONG ulMinPos,ulMaxPos;
	ULONG *pul;
	ULONG ulY,ulYPrev,ulYMean,ulShift;
	ULONG ulNT=(int)ulNTraces<m_iMaxNTraces ? ulNTraces : m_iMaxNTraces;
	ULONG ulPos=ulRangeMin%m_ulWidth,ulPosPrev;
	ULONG ulColor,ulTipColor;
	double dScale=0.0;
	TRACE_STATS *pTS;

	if(!ulNT){
		ulViewHeight=m_ulHeight-(TRACE_BORDER_BOTTOM+TRACE_BORDER_TOP);

		memset(m_pulBuffer+m_ulWidth*TRACE_BORDER_TOP,0,sizeof(ULONG)*m_ulWidth*ulViewHeight);
		m_pBitmap->SetBitmapBits(4*m_ulHeight*m_ulWidth,m_pulBuffer);

		m_rectInvalidate.left=0;
		m_rectInvalidate.right=m_ulWidth+TRACE_WIDTH_RIGHT_PANEL;
		InvalidateRect(&m_rectInvalidate,FALSE);

		memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*TRACE_BORDER_TOP,0,sizeof(ULONG)*m_ulSpectrumWidth*ulViewHeight);
		m_pSpectrumBitmap->SetBitmapBits(4*m_ulHeight*m_ulSpectrumWidth,m_pulSpectrumBuffer);

		m_rectInvalidate.left=m_ulWidth;
		m_rectInvalidate.right=m_rectInvalidate.left+m_ulSpectrumWidth+TRACE_WIDTH_RIGHT_PANEL;
		InvalidateRect(&m_rectInvalidate,FALSE);
		return;
	}

	for(i=0,pul=*m_ppulTraces;i<ulNT;i++,pul=m_ppulTraces[i]){
		pTS=&(m_pTraceStats[m_piTraceMap[i]]);

		if(pTS->bNew){
			pTS->bNew=FALSE; 
			j=pulVals[i];
			for(ULONG ul=0;ul<m_ulWidth;ul++) *(pul+ul)=j;
			pTS->dSumOfVals=(double)m_ulWidth*(double)j;
			pTS->dSumOfValsSquared=pTS->dSumOfVals*(double)j;
			pTS->ulMin=j;
			pTS->ulMax=j;
			pTS->ulMinPrev=j;
			pTS->ulMaxPrev=j;
		}

		pTS->ulCurrentPos=ulPos;
		pTS->dSumOfVals+=(dScale=(double)pulVals[i]-(double)*(pul+ulPos));
		pTS->dSumOfValsSquared+=dScale*((double)pulVals[i]+(double)*(pul+ulPos));

		*(pul+ulPos)=pulVals[i];

		if(pTS->ulMinPos == ulPos){
			pTS->ulMinPrev=pTS->ulMin;
			pTS->ulMinPosPrev=pTS->ulMinPos;
			for(j=1,pTS->ulMin=*pul;j<m_ulWidth;j++){
				if(pTS->ulMin>pul[j]){
					pTS->ulMin=pul[j];
					pTS->ulMinPos=j;
				}
			}
		}
		else{
			if(pTS->ulMin > pulVals[i]){
				pTS->ulMinPrev=pTS->ulMin;
				pTS->ulMinPosPrev=pTS->ulMinPos;
				pTS->ulMin=pulVals[i];
				pTS->ulMinPos=ulPos;
			}
		}

		if(pTS->ulMaxPos == ulPos){
			pTS->ulMaxPrev=pTS->ulMax;
			pTS->ulMaxPosPrev=pTS->ulMaxPos;
			for(j=1,pTS->ulMax=*pul;j<m_ulWidth;j++){
				if(pTS->ulMax<pul[j]){
					pTS->ulMax=pul[j];
					pTS->ulMaxPos=j;
				}
			}
		}
		else{
			if(pTS->ulMax < pulVals[i]){
				pTS->ulMaxPrev=pTS->ulMax;
				pTS->ulMaxPosPrev=pTS->ulMaxPos;
				pTS->ulMax=pulVals[i];
				pTS->ulMaxPos=ulPos;
			}
		}
	}

	pTS=&(m_pTraceStats[m_piTraceMap[0]]);
	for(i=1,ulMin=pTS->ulMin,ulMax=pTS->ulMax;i<ulNT;i++){
		pTS=&(m_pTraceStats[m_piTraceMap[i]]);
		if(ulMin>pTS->ulMin){
			ulMin=pTS->ulMin;
			ulMinPos=pTS->ulMinPos;
		}
		if(ulMax<pTS->ulMax){
			ulMax=pTS->ulMax;
			ulMaxPos=pTS->ulMaxPos;
		}
	}

	ulViewHeight=m_ulHeight-(TRACE_BORDER_BOTTOM+TRACE_BORDER_TOP);
	ulShift=TRACE_BORDER_TOP-1;
	if(ulMin!=m_ulMin || ulMax!=m_ulMax){
		m_bUpdateTraces=TRUE;
			m_ulMin=ulMin;
			m_ulMax=ulMax;
	}
	if(m_bUpdateTraces){
		m_bUpdateTraces = FALSE;
		
		if(ulMax!=ulMin) dScale=(double)(ulViewHeight-1)/(double)(m_ulMax-m_ulMin);
		else dScale=0.5*ulMax*(double)ulViewHeight;
		memset(m_pulBuffer+m_ulWidth*TRACE_BORDER_TOP,0,sizeof(ULONG)*m_ulWidth*ulViewHeight);
		for(i=0,pul=*m_ppulTraces;i<ulNT;i++,pul=m_ppulTraces[i]){
			ulColor=m_pulTraceColor[m_piTraceMap[i]];
			ulTipColor=m_pulTipColor[m_piTraceMap[i]];
			for(j=0;j<m_ulWidth;j++){
				ulPosPrev=(j+m_ulWidth-1)%m_ulWidth;

				ulY=(ULONG)floor((double)ulViewHeight-dScale*(pul[j]-ulMin))+ulShift;
				m_pulBuffer[j+m_ulWidth*ulY]=ulTipColor;

				ulYPrev=(ULONG)floor((double)ulViewHeight-dScale*(pul[ulPosPrev]-ulMin))+ulShift;
				ulYMean=(ulY+ulYPrev)/2;
				if(ulY<ulYPrev){
					for(k=ulY+1;k<ulYMean;k++) m_pulBuffer[j+m_ulWidth*k]=ulColor;
					for(k=ulYMean;k<ulYPrev;k++) m_pulBuffer[ulPosPrev+m_ulWidth*k]=ulColor;
				}
				else{
					for(k=ulYPrev+1;k<ulYMean;k++) m_pulBuffer[ulPosPrev+m_ulWidth*k]=ulColor;
					for(k=ulYMean;k<ulY;k++) m_pulBuffer[j+m_ulWidth*k]=ulColor;
				}
			}
		}
		m_rectInvalidate.left=0;
		m_rectInvalidate.right=m_ulWidth+TRACE_WIDTH_RIGHT_PANEL;
	}
	else{
		dScale=(double)(ulViewHeight-1)/(double)(m_ulMax-m_ulMin);

		for(k=TRACE_BORDER_TOP;k<m_ulHeight-TRACE_BORDER_BOTTOM;k++) m_pulBuffer[ulPos+m_ulWidth*k]=m_ulHighlightColor;
		ulPosPrev=(ulPos+m_ulWidth-1)%m_ulWidth;

		for(i=0,pul=*m_ppulTraces;i<ulNT;i++,pul=m_ppulTraces[i]){
			ulColor=m_pulTraceColor[m_piTraceMap[i]];
			ulY=(ULONG)floor((double)ulViewHeight-dScale*(pul[ulPos]-ulMin))+ulShift;
			m_pulBuffer[ulPos+m_ulWidth*ulY]=m_pulTipColor[m_piTraceMap[i]];

			ulYPrev=(ULONG)floor((double)ulViewHeight-dScale*(pul[ulPosPrev]-ulMin))+ulShift;
			ulYMean=(ulY+ulYPrev)/2;
			if(ulY<ulYPrev){
				for(k=ulY+1;k<ulYMean;k++) m_pulBuffer[ulPos+m_ulWidth*k]=ulColor;
				for(k=ulYMean;k<ulYPrev;k++) m_pulBuffer[ulPosPrev+m_ulWidth*k]=ulColor;
			}
			else{
				for(k=ulYPrev+1;k<ulYMean;k++) m_pulBuffer[ulPosPrev+m_ulWidth*k]=ulColor;
				for(k=ulYMean;k<ulY;k++) m_pulBuffer[ulPos+m_ulWidth*k]=ulColor;
			}
		}
		m_rectInvalidate.left=ulPosPrev;
		m_rectInvalidate.right=ulPos+1;
	}
	m_pBitmap->SetBitmapBits(4*m_ulHeight*m_ulWidth,m_pulBuffer);
	InvalidateRect(&m_rectInvalidate,FALSE);

	if(!((++m_ulSpectrumUpdateCount)%TRACE_SPECTRUM_UPDATE)){
		for(i=0,pul=*m_ppulTraces;i<ulNT;i++,pul=m_ppulTraces[i]){
			pTS=&(m_pTraceStats[m_piTraceMap[i]]);
			SlowPowerSpectrum(m_ulWidth,pul,m_ppdSpectrumTraces[i]+1,pTS->dSpectrumMin,pTS->dSpectrumMax);
			if(TRACE_SPECTRUM_SET_FIXED_LOWER_LIMIT){
				pTS->dSpectrumMin=pTS->dSpectrumMin>TRACE_SPECTRUM_LOWER_LIMIT_VALUE ? pTS->dSpectrumMin : TRACE_SPECTRUM_LOWER_LIMIT_VALUE;
			}
		}
		double dMin,dMax,*pd,dDum;
		int iMin,iMax;
		pTS=&(m_pTraceStats[m_piTraceMap[0]]);
		dMin=pTS->dSpectrumMin;
		dMax=pTS->dSpectrumMax;
		for(i=1;i<ulNT;i++){
			pTS=&(m_pTraceStats[m_piTraceMap[i]]);
			if(dMin>pTS->dSpectrumMin) dMin=pTS->dSpectrumMin;
			if(dMax<pTS->dSpectrumMax) dMax=pTS->dSpectrumMax;
		}
		iMin=(int)ceil(dMin);
		iMax=(int)floor(dMax);

		if(dMax!=dMin) dScale=(double)(ulViewHeight-1)/(double)(dMax-dMin);
		else dScale=0.5*dMax*(double)ulViewHeight;
		memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*TRACE_BORDER_TOP,0,sizeof(ULONG)*m_ulSpectrumWidth*ulViewHeight);
		for(int ii=iMin;ii<=iMax;ii++){
			ulY=(ULONG)floor((double)ulViewHeight-dScale*(ii-dMin))+ulShift;
			if(ii==0) memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*ulY,0xff,sizeof(ULONG)*m_ulSpectrumWidth);
			else memset(m_pulSpectrumBuffer+m_ulSpectrumWidth*ulY,0x80,sizeof(ULONG)*m_ulSpectrumWidth);
		}

		for(i=0,pd=*m_ppdSpectrumTraces;i<ulNT;i++,pd=m_ppdSpectrumTraces[i]){
			ulColor=m_pulTraceColor[m_piTraceMap[i]];
			ulTipColor=m_pulTipColor[m_piTraceMap[i]];
			for(j=2;j<m_ulSpectrumWidth-1;j++){

				dDum=pd[j]>TRACE_SPECTRUM_LOWER_LIMIT_VALUE ? pd[j] : TRACE_SPECTRUM_LOWER_LIMIT_VALUE;
				ulY=(ULONG)floor((double)ulViewHeight-dScale*(dDum-dMin))+ulShift;
				m_pulSpectrumBuffer[j+m_ulSpectrumWidth*ulY]=ulTipColor;

				dDum=pd[j-1]>TRACE_SPECTRUM_LOWER_LIMIT_VALUE ? pd[j-1] : TRACE_SPECTRUM_LOWER_LIMIT_VALUE;
				ulYPrev=(ULONG)floor((double)ulViewHeight-dScale*(dDum-dMin))+ulShift;
				ulYMean=(ulY+ulYPrev)/2;
				if(ulY<ulYPrev){
					for(k=ulY+1;k<ulYMean;k++) m_pulSpectrumBuffer[j+m_ulSpectrumWidth*k]=ulColor;
					for(k=ulYMean;k<ulYPrev;k++) m_pulSpectrumBuffer[j-1+m_ulSpectrumWidth*k]=ulColor;
				}
				else{
					for(k=ulYPrev+1;k<ulYMean;k++) m_pulSpectrumBuffer[j-1+m_ulSpectrumWidth*k]=ulColor;
					for(k=ulYMean;k<ulY;k++) m_pulSpectrumBuffer[j+m_ulSpectrumWidth*k]=ulColor;
				}
			}
		}
		m_pSpectrumBitmap->SetBitmapBits(4*m_ulHeight*m_ulSpectrumWidth,m_pulSpectrumBuffer);
		m_rectInvalidate.left=m_ulWidth;
		m_rectInvalidate.right=m_rectInvalidate.left+m_ulSpectrumWidth+TRACE_WIDTH_RIGHT_PANEL;
		InvalidateRect(&m_rectInvalidate,FALSE);
	}
}

void CTrace::OnLButtonDown(UINT nFlags, CPoint point){
	int iX;
	iX=point.x-(m_ulWidth+TRACE_WIDTH_RIGHT_PANEL);
	if(iX>0 && iX<(int)m_ulSpectrumWidth){
		m_dFrequencyHz=1.0e+6*(double)iX/(m_ulWidth*(double)m_ulInterFrameTimeUsec);
	}
	CMiniFrameWnd::OnLButtonDown(nFlags, point);
}

void CTrace::OnDestroy(){
	CMiniFrameWnd::OnDestroy();
	
	PrintMessage("CTrace::OnDestroy");
	::SendMessage(m_hMsgWnd,UWM_ON_TRACE_DESTROY,0,0);
	
}

void CTrace::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	// TODO: Add your message handler code here and/or call default
	
	CMiniFrameWnd::OnGetMinMaxInfo(lpMMI);
}

void CTrace::OnClose(){
	PrintMessage("CTrace::OnClose");
	
	CMiniFrameWnd::OnClose();
}

