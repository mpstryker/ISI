// Synchronization.h: interface for the CSynchronization class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNCHRONIZATION_H__D0E406A0_F564_4326_94AB_0C95F7DE6436__INCLUDED_)
#define AFX_SYNCHRONIZATION_H__D0E406A0_F564_4326_94AB_0C95F7DE6436__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "SynchDIO.h"
#include "SynchUDP.h"

//SR:  Not used
/*
typedef struct SYNCH_IN{
	int iNumChannels;
	int (**ppfunSynchIn)(ULONG&);
	ULONG volatile **ppulValueIn;  

	ULONG *pulMaxValueIn;
	double **ppdTimeInUsec;
} SYNCH_IN;

//SR: Not used
typedef struct SYNCH_OUT{
	int iNumChannels;
	int (**ppfunSynchOut)(ULONG);
	ULONG volatile **ppulValueOut;
	ULONG *pulMaxValueOut;
	double **ppdTimeOutUsec;
} SYNCH_OUT;
*/

//SR: This what we actually use
typedef struct SYNCH_IN_OUT{
  // input channels
	int iNumChannelsIn;            //SR:  N of input channels

  //SR:  The channel can use either a function or a value pointer to get the data 
  //SR: if ppulValueIn[iChannel] == NULL, a function is used, otherwise the value is read from the pointer
	int (**ppfunSynchIn)(ULONG&);  //SR:  array of functions which are called to get a value
	ULONG volatile **ppulValueIn;  //SR:  array of pointers to values read from channels
                                 //SR:  if NULL, call the function pointer

	ULONG *pulMaxValueIn;          //SR:  array of max values for all channels
	double **ppdTimeInUsec;        //SR:  array of pointers to times in mks when the value was read

  // output channels
  int iNumChannelsOut;           //SR:  N of output channels
	int (**ppfunSynchOut)(ULONG);  //SR:  array of functions which are called to output a value
	ULONG volatile **ppulValueOut; //SR:  array of pointers used to output values (unused)
	ULONG *pulMaxValueOut;         //SR:  array of max values for all channels (unused)
	double **ppdTimeOutUsec;       //SR:  array of pointers to times in mks (unused)
} SYNCH_IN_OUT;


class CSynchronization{

public:
	CSynchronization();
	virtual ~CSynchronization();

	CSynchDIO *m_pSynchDIO;
	CSynchUDP *m_pSynchUDP;


//SR  SYNCH_IN m_SynchIn;         //SR: not used 
//SR	SYNCH_OUT m_SynchOut;       //SR: not used
	SYNCH_IN_OUT m_SynchInOut;  //SR: This one we actually use

};

#endif // !defined(AFX_SYNCHRONIZATION_H__D0E406A0_F564_4326_94AB_0C95F7DE6436__INCLUDED_)
