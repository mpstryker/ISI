#if !defined(AFX_FINDDLG_H__CABFD726_7E13_472F_BF4E_EB9EA81CAF2B__INCLUDED_)
#define AFX_FINDDLG_H__CABFD726_7E13_472F_BF4E_EB9EA81CAF2B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FindDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog

class CFindDlg : public CFindReplaceDialog{
// Construction
public:
	CFindDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFindDlg)
	enum { IDD = IDD_FIND_DIALOG };
	CStatic	m_staticFindBitmap;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CBitmap m_hFindBitmaps[3];
	int m_bFindStatus;
	BOOL m_bFindTextOld;
	BOOL m_bFindDown;

public:
	void OnTextFound();
	void OnTextNotFound();
	void ResetState(int iState = 0);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDDLG_H__CABFD726_7E13_472F_BF4E_EB9EA81CAF2B__INCLUDED_)
