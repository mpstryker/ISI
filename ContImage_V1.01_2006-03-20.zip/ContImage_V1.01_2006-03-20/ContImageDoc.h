// ContImageDoc.h : interface of the CContImageDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTIMAGEDOC_H__F2C0087B_FFED_48BB_ADDA_CCBF62765519__INCLUDED_)
#define AFX_CONTIMAGEDOC_H__F2C0087B_FFED_48BB_ADDA_CCBF62765519__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CContImageDoc : public CDocument
{
protected: // create from serialization only
	CContImageDoc();
	DECLARE_DYNCREATE(CContImageDoc)

// Attributes
public:
	int		m_iDocIndex;
	int		m_iDocNumber;
	CRect	*m_prectROI;
	CSize	m_sizeROI;
	int		*m_piSpatialBinningX;
	int		*m_piSpatialBinningY;
	int		*m_piTemporalBinning;	

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContImageDoc)
	public:
	virtual BOOL OnNewDocument(int iDocIndex = 0);
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CContImageDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CContImageDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG


	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTIMAGEDOC_H__F2C0087B_FFED_48BB_ADDA_CCBF62765519__INCLUDED_)
