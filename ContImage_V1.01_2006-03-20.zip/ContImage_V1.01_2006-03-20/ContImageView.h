// ContImageView.h : interface of the CContImageView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTIMAGEVIEW_H__C1F1E7BF_7131_4551_A440_CCA745ADBE07__INCLUDED_)
#define AFX_CONTIMAGEVIEW_H__C1F1E7BF_7131_4551_A440_CCA745ADBE07__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CContImageView;

#include "ContImageDoc.h"

#define DEFAULT_ZOOM 0.5
#define DEFAULT_ROI_RECT_COLOR 0x000000ff
#define DEFAULT_DRAG_DRAW_RECT_SPACING 5
#define DEFAULT_DRAG_DRAW_RECT_COLOR 0x000000ff

#define TRACE_MAX_NTRACES	4

typedef enum {
	zoom0125, 
	zoom025, 
	zoom05, 
	zoom1, 
	zoom2,
	zoom4,
	zoom8
}ZOOM;

class CContImageView : public CScrollView
{
protected: // create from serialization only
	CContImageView();
	DECLARE_DYNCREATE(CContImageView)

	virtual ~CContImageView();

// Attributes
public:
	CContImageDoc* GetDocument();

// Operations
	void DrawSelect();

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContImageView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL


// Implementation
public:

	int*	m_piViewIndex;
	int*	m_piViewNumber;
	BOOL	m_bMainView;
	CRect*	m_prectROI;
	CRect	m_rectROIBinning;
	CSize*	m_psizeROIMain;
	CSize	m_sizeROI;
	CSize	m_sizeROIBinned;
	CSize	m_sizeROIBinnedCorecoCrap;
	CSize	m_sizeROIView;
	int*	m_piSpatialBinningX;
	int*	m_piSpatialBinningY;
	int*	m_piTemporalBinning;

	ZOOM	m_zoomROIView;
	float	m_fZoomX;
	float	m_fZoomY;
	float	m_fRawZoomX;
	float	m_fRawZoomY;

	CPoint	m_pointCursorPos;
	BOOL	m_bSelect;
	CRect	m_rectSelect;
	CRect	m_rectSelectLast;
	DWORD	m_dwStyle[2];
    LOGBRUSH m_lb;
	COLORREF m_crROIRectColor;
	COLORREF m_crDragDrawRectColor;
	DWORD	m_dwDragDrawRectSpacing;
	CPen*	m_ppenSelectSimple;
	CPen*	m_ppenSelect;
	CPen*	m_ppenSelectTransparent;
	CPen*	m_ppenROI;
	CFont	m_fontROI;
	CBrush*	m_pbrushROIFill;
	CRect	m_rectROIFill;
	HDC		m_hOverlayDC;
	CDC*	m_pOverlayCDC;

	GRAB_HANDLE			m_hGrabID;
	IMAGE_SOURCE*		m_hImageSource;
	IMAGE_DESTINATION*	m_hImageDestinationTemplate;
	IMAGE_DESTINATION*	m_hImageDestination;
	IMAGE_CONNECTION*	m_hImageConnection;
	IMAGE_OVERLAY*		m_hImageOverlay;

	void*	m_pLocalSaveBuffer;
	DWORD	m_dwLocalSaveBufferSize;
	BYTE*	m_pbLocalImageBuffer;
	DWORD	m_dwLocalImageBufferSize;

	BYTE*	m_pbLocalDisplayBuffer;
	DWORD	m_dwLocalDisplayBufferSize;
	ULONG*	m_pulLocalStorageBuffer;
	DWORD	m_dwLocalStorageBufferSize;

	BOOL	m_bRunningFocus;
	BOOL	m_bRunningExperiment;
	DWORD	m_dwServerDynamicMode;
	DWORD	m_dwApplicationMode;

	ULONG	m_ulFileHeaderSize;
	void	*m_pFileHeader;
	ULONG	m_ulFileSizeOffset;
	ULONG	m_ulDataSizeOffset;

	FILE	*m_fpExperimentFile;
	FILE	*m_fpNextExperimentFile;
	int		m_iMaxNExperimentFiles;
	int		m_iNExperimentFiles;
	char	*m_strExperimentFileNames;
	char	m_strExperimentFileNameTemplate[FILENAME_SIZE];
	ULONG	m_ulMaxNFramesInFile;
	ULONG	m_ulNFramesInFile;

	CHistogram		*m_wndHistogram;
	BOOL volatile 	m_bHistogram;
	ULONG			m_ulNBins;
	ULONG			*m_pulHistogram;

	CTrace			*m_wndTrace;
	BOOL volatile 	m_bTrace;
	BOOL volatile 	m_bTraceAverage;
	ULONG			m_ulNTraces;
	ULONG			m_pulPixelVal[TRACE_MAX_NTRACES];
	long			m_plPixelCord[TRACE_MAX_NTRACES];
	int				m_iLastPixel;

	BOOL volatile 	m_bFocusThreadShutdown;
	int volatile 	*m_piExperimentThreadShutdown;
	HANDLE			m_hFocusThread;
	HANDLE			m_hExperimentThread;
	DWORD			m_dwFocusThreadID;
	DWORD			m_dwExperimentThreadID;

	FOCUS_THREAD_PARAMS			m_structFocusThreadParams;
	EXPERIMENT_THREAD_PARAMS	m_structExperimentThreadParams;
	
	
	friend DWORD WINAPI FocusThread(LPVOID);
	friend DWORD WINAPI ExperimentThread(LPVOID);

	void	ResizeROIView();
	LRESULT ResizeClientArea(int iWidth, int iHeight);
	BOOL	ReopenDevices(BOOL bReopen);
	BOOL	AllocateLocalBuffers();
	BOOL	OpenDevices();
	BOOL	CloseDevices();
	void	OnZoomChange();
	void	RecreateObjects();
	BYTE	FixEndPoints(int b,long xi,long yi,long xout,long yout,long *xf,long *yf);
	void	RescaleRect(CRect* r,float x,float y);
	void	AugmentRect(CRect* r);
	void	OverlayRect(BYTE *pBuffer,ULONG cx,ULONG cy,int iBytes,CRect rect);

	void	RemoveAllTraces();

	BOOL CheckModeConsistency(char*);

	int SmartWrite(void *pBuffer,ULONG ulBufferSize);
	int GenerateFileName(char *pcFileName);
	int CloseExperimentFile(BOOL bLastFile);
	int RemoveExperiemntFiles();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CContImageView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnAcquireMiscCoordinates();
	afx_msg void OnDestroy();
	afx_msg void OnFileSave();
	afx_msg void OnAcquireDestinationProperties();
	afx_msg void OnAcquireSourceProperties();
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnAcquireConnectionProperties();
	afx_msg void OnToolHistogram();
	afx_msg void OnUpdateToolHistogram(CCmdUI* pCmdUI);
	afx_msg void OnToolTrace();
	afx_msg void OnUpdateToolTrace(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG

	afx_msg void OnUpdateIndicatorCursorPosition(CCmdUI* pCmdUI);
	afx_msg void OnZoom(UINT nID);
	afx_msg void OnUpdateZoom(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSaveGreen(CCmdUI* pCmdUI);
	afx_msg LRESULT OnROIChange(WPARAM = 0, LPARAM = NULL);
	afx_msg LRESULT OnSpatialBinningChange(WPARAM wp, LPARAM lp);	
	afx_msg LRESULT OnTemporalBinningChange(WPARAM wp, LPARAM lp);	
	afx_msg LRESULT OnStartGrabbing(WPARAM = 0, LPARAM = NULL);
	afx_msg LRESULT OnStopGrabbing(WPARAM = THREAD_SHUTDOWN_STOP, LPARAM = 0);
	afx_msg LRESULT OnRemovedSubROI(WPARAM = 0, LPARAM = NULL);
	afx_msg LRESULT OnSwitchFocusMode(WPARAM, LPARAM = NULL);
	afx_msg LRESULT OnSaveGreen(WPARAM = 0, LPARAM = NULL);
	afx_msg LRESULT OnFillStorgeBuffer(WPARAM, LPARAM);
	afx_msg LRESULT OnSaveImageFile(WPARAM = 0, LPARAM = 0);
	afx_msg LRESULT OnChangeModes(WPARAM , LPARAM );
	afx_msg LRESULT OnHistogramDestroy(WPARAM = 0,LPARAM = 0);
	afx_msg LRESULT OnUpdateHistogram(WPARAM = 0,LPARAM = 0);

	afx_msg LRESULT OnTraceDestroy(WPARAM = 0,LPARAM = 0);
	afx_msg LRESULT OnUpdateTrace(WPARAM = 0,LPARAM = 0);

	afx_msg void OnAddTrace();
	void OnAddTrace(long lPixel);
	afx_msg void OnAddAvarageTrace();
	afx_msg void OnRemoveTrace(UINT nID);
	afx_msg void OnSubstituteTrace(UINT nID);
	afx_msg void OnShowPixel(UINT nID);

	afx_msg LRESULT OnFocusThreadFinished(WPARAM, LPARAM = 0);
	afx_msg LRESULT OnExperimentThreadFinished(WPARAM, LPARAM = 0);

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ContImageView.cpp
inline CContImageDoc* CContImageView::GetDocument()
   { return (CContImageDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTIMAGEVIEW_H__C1F1E7BF_7131_4551_A440_CCA745ADBE07__INCLUDED_)
