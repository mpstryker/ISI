// CanvasWnd.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "CanvasWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_ON_HISTOGRAM_DESTROY = ::RegisterWindowMessage(_T("UWM_ON_HISTOGRAM_DESTROY"));

/////////////////////////////////////////////////////////////////////////////
// CCanvasWnd

IMPLEMENT_DYNAMIC(CCanvasWnd, CWnd);

CCanvasWnd::CCanvasWnd(){
	m_pulBuffer=NULL;
	m_hMsgWnd=NULL;
	m_strWindowName=NULL;
	m_pBitmap = NULL;
}

CCanvasWnd::~CCanvasWnd(){
	if(m_strWindowName) free(m_strWindowName);
//	if(m_pulBuffer) free(m_pulBuffer);
}


BEGIN_MESSAGE_MAP(CCanvasWnd, CWnd)
	//{{AFX_MSG_MAP(CCanvasWnd)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCanvasWnd message handlers

BOOL CCanvasWnd::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext){
	m_hMsgWnd=pParentWnd->m_hWnd;
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

BOOL CCanvasWnd::Create(int iNumber, int x,int y, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName){
	char str[256];
	m_hMsgWnd=hwndParent;
	m_strWindowName=(char*)malloc(strlen(strWindowName)+1);
	memcpy(m_strWindowName,strWindowName,strlen(strWindowName)+1);
	sprintf(str,"%s %c",m_strWindowName,iNumber);
	return CWnd::CreateEx( 0,lpszClassName,_T(str),WS_POPUPWINDOW | WS_OVERLAPPEDWINDOW,x,y,200,200,hwndParent, NULL,NULL);
}

BOOL CCanvasWnd::Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName){
	char str[256];
	m_hMsgWnd=hwndParent;
	m_strWindowName=(char*)malloc(strlen(strWindowName)+1);
	memcpy(m_strWindowName,strWindowName,strlen(strWindowName)+1);
	sprintf(str,"%s %c",m_strWindowName,iNumber);
	return CWnd::CreateEx( 0,lpszClassName,_T(str),WS_POPUPWINDOW | WS_OVERLAPPEDWINDOW,x,y,
		iWidth+2*GetSystemMetrics(SM_CXSIZEFRAME),iHeight+2*GetSystemMetrics(SM_CYSIZEFRAME)+GetSystemMetrics(SM_CYCAPTION),
		hwndParent, NULL,NULL);
}

BOOL CCanvasWnd::Create(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hwndParent, HMENU nIDorHMenu, LPVOID lpParam){	
	m_hMsgWnd=hwndParent;
	return CWnd::CreateEx(dwExStyle,lpszClassName,lpszWindowName,dwStyle,x,y,nWidth,nHeight,hwndParent,nIDorHMenu,lpParam);
}


BOOL CCanvasWnd::PreCreateWindow(CREATESTRUCT& cs){
	PrintMessage("CCanvasWnd::PreCreateWindow");
	PrintMessage((char*)(cs.lpszName));
	PrintMessage((char*)(cs.lpszClass));
	return CWnd::PreCreateWindow(cs);
}

void CCanvasWnd::OnPaint(){
	CPaintDC dc(this); // device context for painting
	char str[16];
	if(m_pBitmap){

		CDC DCMem;
		DCMem.CreateCompatibleDC(NULL);
		CBitmap* pOldBitmap = DCMem.SelectObject(m_pBitmap);
		BITMAP bm;
		m_pBitmap->GetObject(sizeof(bm), &bm) ;
		dc.BitBlt(0,0,bm.bmWidth,bm.bmHeight,&DCMem,0,0,SRCCOPY);
		sprintf(str,"%i",m_ulMax);
		dc.TextOut(m_ulWidth,m_ulHeight,str,strlen(str));
		sprintf(str,"%i",m_ulMaxC);
		dc.TextOut(m_ulWidth,m_ulMaxC,str,strlen(str));

		DCMem.SelectObject(pOldBitmap);
		DCMem.DeleteDC();
	}
}

void CCanvasWnd::CreateCanvasBitmap(){
	char str[128];
	RECT r;
	GetClientRect(&r);
	int iWidth=r.right-r.left;
	int iHeight=r.bottom-r.top;
	DWORD dwCount=4*iWidth*iHeight;

	m_pulBuffer=(ULONG*)calloc(dwCount,1);
	int i,j,k;
	for(k=j=0;j<iHeight;j++)
		for(i=0;i<iWidth;i++,k++){
			if(i==0 || i==iWidth-1 || j==0 || j==iHeight-1) m_pulBuffer[k]=RGB(255,255,255);
			else m_pulBuffer[k] = 0xffffff;//RGB(0,(i*255)/iHeight,(j*255)/iWidth);
		}

	m_pBitmap = new CBitmap;
	CDC* pDC = GetDC();

	m_pBitmap->CreateCompatibleBitmap(pDC,iWidth,iHeight);
	m_pBitmap->SetBitmapBits(dwCount,m_pulBuffer);

	BITMAP bm;
	m_pBitmap->GetObject(sizeof(bm), &bm) ;
	m_ulWidth=bm.bmWidth;
	m_ulHeight=bm.bmHeight;

	sprintf(str,"Type %i X %i Y %i",bm.bmType,bm.bmWidth,bm.bmHeight);
	PrintMessage(str);
	sprintf(str,"WidthBytes %i Planes %i BitsPixel %i",bm.bmWidthBytes,bm.bmPlanes,bm.bmBitsPixel);
	PrintMessage(str);
	sprintf(str,"Bits %p",bm.bmBits);
	PrintMessage(str);

	ReleaseDC(pDC);
}

void CCanvasWnd::UpdateCanvasBitmap(ULONG ulBins,ULONG *pulVals){
	ULONG i,j,k;
	ULONG ul;
	ULONG *pul;
	for(i=1,m_ulMax=*pulVals,m_ulMaxC=0;i<ulBins;i++){
		if(m_ulMax<pulVals[i]){
			m_ulMax=pulVals[i];
			m_ulMaxC=i;
		}
	}

	for(k=j=0,pul=m_pulBuffer;j<m_ulHeight && j<ulBins;j++,pul+=m_ulWidth){
		ul=(pulVals[j]*m_ulWidth)/m_ulMax;
		if(ul<m_ulWidth){
			memset(pul,0,ul*sizeof(ULONG));
			memset(pul+ul,0xff,(m_ulWidth-ul)*sizeof(ULONG));
		}
		else{
			memset(pul,0,m_ulWidth*sizeof(ULONG));
		}
	}
/*	
	for(k=j=0;j<m_ulHeight && j<ulBins;j++){
		ul=(pulVals[j]*m_ulWidth)/ulMax;
		for(i=0;i<m_ulWidth;i++,k++){
			if(i<ul) m_pulBuffer[k] = 0xffff00;
			else m_pulBuffer[k] = 0x0000ff;
		}
	}
*/	
	m_pBitmap->SetBitmapBits(4*m_ulHeight*m_ulWidth,m_pulBuffer);
	Invalidate(FALSE);
	PostMessage(WM_PAINT);
}

void CCanvasWnd::OnDestroy(){
	CWnd::OnDestroy();
	::SendMessage(m_hMsgWnd,UWM_ON_HISTOGRAM_DESTROY,0,0);
}
