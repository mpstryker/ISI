// Synchronization.cpp: implementation of the CSynchronization class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "contimage.h"
#include "Synchronization.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSynchronization::CSynchronization(){
	m_pSynchDIO = new CSynchDIO;
	m_pSynchUDP = new CSynchUDP;

/*  SR: commented out unused part to make sure it is not necessary
	m_SynchIn.iNumChannels=1;
	m_SynchIn.ppfunSynchIn=(int (**)(ULONG&))calloc(m_SynchIn.iNumChannels,sizeof(int (*)(ULONG&)));
	m_SynchIn.ppulValueIn=(ULONG volatile **)calloc(m_SynchIn.iNumChannels,sizeof(ULONG*));
	m_SynchIn.pulMaxValueIn=(ULONG*)calloc(m_SynchIn.iNumChannels,sizeof(ULONG));
	m_SynchIn.ppdTimeInUsec=(double**)calloc(m_SynchIn.iNumChannels,sizeof(double*));

	m_SynchIn.ppfunSynchIn[0]=m_pSynchDIO->m_PhysicalPorts[1].pfunRead;
	m_SynchIn.ppulValueIn[0]=NULL;
	m_SynchIn.pulMaxValueIn[0]=(1UL)<<m_pSynchDIO->m_PhysicalPorts[1].usBitCount;
	m_SynchIn.ppdTimeInUsec[0]=NULL;

	m_SynchOut.iNumChannels=1;
	m_SynchOut.ppfunSynchOut=(int (**)(ULONG))calloc(m_SynchOut.iNumChannels,sizeof(int (*)(ULONG)));
	m_SynchOut.ppulValueOut=(ULONG volatile**)calloc(m_SynchOut.iNumChannels,sizeof(ULONG*));
	m_SynchOut.pulMaxValueOut=(ULONG*)calloc(m_SynchOut.iNumChannels,sizeof(ULONG));
	m_SynchOut.ppdTimeOutUsec=(double**)calloc(m_SynchOut.iNumChannels,sizeof(double*));

	m_SynchOut.ppfunSynchOut[0]=m_pSynchDIO->m_PhysicalPorts[0].pfunWrite;
	m_SynchOut.ppulValueOut[0]=NULL;
	m_SynchOut.pulMaxValueOut[0]=(1UL)<<m_pSynchDIO->m_PhysicalPorts[0].usBitCount;
	m_SynchOut.ppdTimeOutUsec[0]=NULL;
*/

	// Val 11-21-2002: Added UDP Synch channel, should make SynchDialog box
	// Channel 0 is mapped onto DIO Ports 1(in) and 0 (out)
	// Channel 1 is mapped onto UDP channel 0
  // SR: added 2 extra UDP channels 2006/03/20
	m_SynchInOut.iNumChannelsIn=4;

  // Allocate memory 
	m_SynchInOut.ppfunSynchIn=(int (**)(ULONG&))calloc(m_SynchInOut.iNumChannelsIn,sizeof(int (*)(ULONG&)));
	m_SynchInOut.ppulValueIn=(ULONG volatile **)calloc(m_SynchInOut.iNumChannelsIn,sizeof(ULONG*));
	m_SynchInOut.pulMaxValueIn=(ULONG*)calloc(m_SynchInOut.iNumChannelsIn,sizeof(ULONG));
	m_SynchInOut.ppdTimeInUsec=(double**)calloc(m_SynchInOut.iNumChannelsIn,sizeof(double*));

  //SR:  File Channel 0: read from DIO port 1
	m_SynchInOut.ppfunSynchIn[0]=m_pSynchDIO->m_PhysicalPorts[1].pfunRead; // Use function to get a value
	m_SynchInOut.ppulValueIn[0]=NULL;
	m_SynchInOut.pulMaxValueIn[0]=(1UL)<<m_pSynchDIO->m_PhysicalPorts[1].usBitCount;
	m_SynchInOut.ppdTimeInUsec[0]=NULL;
 
  //SR: Input channels are used in COST to write external info to file 
  //SR:  File Channel 1: read from UDP channel 0
	m_SynchInOut.ppfunSynchIn[1]=NULL;  
	m_SynchInOut.ppulValueIn[1]=m_pSynchUDP->m_pUDPChannels[0].pulDataIn; // use this pointer to get a value
	m_SynchInOut.pulMaxValueIn[1]=(1UL)<<m_pSynchUDP->m_pUDPChannels[0].ulBitCount;
	m_SynchInOut.ppdTimeInUsec[1]=&(m_pSynchUDP->m_pUDPChannels[0].dArrivalTimeUsec);

  //SR:  File Channel 2: read from UDP channel 1
	m_SynchInOut.ppfunSynchIn[2]=NULL;
	m_SynchInOut.ppulValueIn[2]=m_pSynchUDP->m_pUDPChannels[1].pulDataIn;  // use this pointer to get a value
	m_SynchInOut.pulMaxValueIn[2]=(1UL)<<m_pSynchUDP->m_pUDPChannels[1].ulBitCount;
	m_SynchInOut.ppdTimeInUsec[2]=&(m_pSynchUDP->m_pUDPChannels[1].dArrivalTimeUsec);

  //SR:  File Channel 3: read from UDP channel 2
	m_SynchInOut.ppfunSynchIn[3]=NULL;
	m_SynchInOut.ppulValueIn[3]=m_pSynchUDP->m_pUDPChannels[2].pulDataIn; // use this pointer to get a value
	m_SynchInOut.pulMaxValueIn[3]=(1UL)<<m_pSynchUDP->m_pUDPChannels[2].ulBitCount;
	m_SynchInOut.ppdTimeInUsec[3]=&(m_pSynchUDP->m_pUDPChannels[2].dArrivalTimeUsec);

  //SR: Changed this part too 
  // Allocate memory 
	m_SynchInOut.iNumChannelsOut=1;
	m_SynchInOut.ppfunSynchOut=(int (**)(ULONG))calloc(m_SynchInOut.iNumChannelsOut,sizeof(int (*)(ULONG)));
	m_SynchInOut.ppulValueOut=(ULONG volatile **)calloc(m_SynchInOut.iNumChannelsOut,sizeof(ULONG*));
	m_SynchInOut.pulMaxValueOut=(ULONG*)calloc(m_SynchInOut.iNumChannelsOut,sizeof(ULONG));
	m_SynchInOut.ppdTimeOutUsec=(double**)calloc(m_SynchInOut.iNumChannelsOut,sizeof(double*));

  //SR: Output channel is used in EPST to control PCV program via DIO
  //SR: Input channels are ignored in EPST
	m_SynchInOut.ppfunSynchOut[0]=m_pSynchDIO->m_PhysicalPorts[0].pfunWrite;
	m_SynchInOut.ppulValueOut[0]=NULL;
	m_SynchInOut.pulMaxValueOut[0]=(1UL)<<m_pSynchDIO->m_PhysicalPorts[0].usBitCount;
	m_SynchInOut.ppdTimeOutUsec[0]=NULL;

}

CSynchronization::~CSynchronization(){
//SR	if(m_SynchIn.ppfunSynchIn) free(m_SynchIn.ppfunSynchIn);
//SR	if(m_SynchIn.pulMaxValueIn) free(m_SynchIn.pulMaxValueIn);

  if(m_SynchInOut.ppfunSynchIn) free(m_SynchInOut.ppfunSynchIn);      //SR
  if(m_SynchInOut.pulMaxValueIn) free(m_SynchInOut.pulMaxValueIn);    //SR
  if(m_SynchInOut.ppfunSynchOut) free(m_SynchInOut.ppfunSynchOut);    //SR
  if(m_SynchInOut.pulMaxValueOut) free(m_SynchInOut.pulMaxValueOut);  //SR

  m_SynchInOut.ppfunSynchIn = NULL;    //SR
  m_SynchInOut.pulMaxValueIn = NULL;   //SR
  m_SynchInOut.ppfunSynchOut = NULL;   //SR
  m_SynchInOut.pulMaxValueOut = NULL;  //SR

	delete m_pSynchUDP;
	delete m_pSynchDIO;
}
