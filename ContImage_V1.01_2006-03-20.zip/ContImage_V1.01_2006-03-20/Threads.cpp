// Val: 11-19-2002 synchronized update of the trace and histogram (FocusThread) with T-binning 
//		fixed frame count bug (unbinned -> binned)
#include "stdafx.h"
#include "ContImage.h"
#include "ContImageView.h"

static const UINT UWM_TRIGGER_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_TRIGGER_THREAD_FINISHED"));
static const UINT UWM_FOCUS_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_FOCUS_THREAD_FINISHED"));
static const UINT UWM_EXPERIMENT_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_EXPERIMENT_THREAD_FINISHED"));
static const UINT UWM_ON_UPDATE_HISTOGRAM = ::RegisterWindowMessage(_T("UWM_ON_UPDATE_HISTOGRAM"));
static const UINT UWM_ON_UPDATE_TRACE = ::RegisterWindowMessage(_T("UWM_ON_UPDATE_TRACE"));

extern double dFrequency,dFrequencyUsec;

// Val: excerpt from Camera.h
//typedef struct {
//	double ArrivalTime; // system time that frame arrived in microseconds
//	DWORD frameSeqNum;  // Sequence Number of this frame since the grab was begun
//	BOOL FrameIsLocked; // TRUE if frame is locked in the grab ring buffer
//	BOOL potentiallyBad;
//} GRAB_EXT_ATTR;
// Val: excerpt from ICapMod.h
//typedef struct {
//	DWORD NumberOfFramesLocked;	 // Number of frames currently locked in the ring buffer
//	DWORD NumberOfFramesLost;	// Number of frames aquired but overwritten or lost due to no unlocked space available
//	DWORD NumberOfFramesMissed; // Number of frames that the grab service missed, i.e., the grab service was unable to read a frame in time
//	DWORD CurrentFrameSeqNum;	// Sequence number of next frame to be received
//	DWORD NumberOfFramesAwaitDelivery; // Number of frames in the ring buffer not yet delivered to user via GrabWaitFrameEx
//} IFC_GRAB_STATS;


DWORD WINAPI FocusThread(LPVOID params){
	FOCUS_THREAD_PARAMS*	pParams = (FOCUS_THREAD_PARAMS*)params;
	CContImageView			*view	= (CContImageView *)(pParams->pView);
	CAMERA					*pCamera= pParams->pCamera;
	GRAB_HANDLE				hGrabID	= pParams->hGrabID;
	DWORD					dwNFramesRingBuffer = pParams->dwNFramesRingBuffer;
	BOOL volatile			*pbShutdown = pParams->pbShutdown;
	double					dInterFrameTimeUsec = (double)(pParams->dwInterFrameTimeUsec);
	BOOL volatile			*pbHistogram = pParams->pbHistogram;
	ULONG					*pulNBins = pParams->pulNBins;
	ULONG					**ppulHistogram = pParams->ppulHistogram;
	BOOL volatile			*pbTrace = pParams->pbTrace;
	BOOL volatile			*pbTraceAverage = pParams->pbTraceAverage;
	BOOL volatile			*pbDisplayFrames = pParams->pbDisplayFrames;

	int iViewNumber;
	DWORD dwSrcOffsetBytes,dwSrcShiftRecords;
	DWORD dwDestShiftRecords;
	DWORD dwDestSizeXRecords,dwDestSizeYRecords,dwDestSizeXBytes,dwDestSizeRecords;
	DWORD dwSrcSizeXRecords,dwMainXRecords;

	int			iRingFrameNum;
	BYTE*		pbFrameAddress;
	int			iWaitForFrameNum=IFC_WAIT_NEWER_FRAME;
	DWORD		dwTimeOutMilliseconds=IFC_WAIT_FOREVER;
	BOOL		bLock=TRUE;
	DWORD*		pdwAcquiredSizeY=NULL;//Val: not used for PCDig
	BOOL*		pbVirtualFrameEnd=NULL;
	FRAME_ATTRIBUTES	structFrameAttributes;
	CAMERA_STATISTICS	structCameraStats;
	
	int iExitCode = 0;

	char	str[256];
	double	initime_external,fintime_external;	//milliseconds
	double	initime_internal,fintime_internal;	//milliseconds
	double	dDelay=0.0,dMaxDelay=0.0,dArrival,dProccesing;
	double	dAverageDelay=0.0,dAverageProccesing=0.0,dAverageDisplay=0.0,dAverageTotal;
	long	iniframe,finframe;
	int		iExpectedRingFrameNum;
	int		iLastFilledFrameSeqNum=-1;
	DWORD	dwInitialTimeOutMilliseconds=2000;
	
	ULONG	ulDelayedFrameCount=0,ulFrameCount=0,ulCurrentFrame,ulFirstSkippedFrame=0;

	BOOL bFast=FALSE,bVeryFast=FALSE,bShift=FALSE;
	BOOL bHistogramWnd=FALSE;

	int s_binningX,s_binningY,t_binning;
	int iTemporalBinningCount;
	ULONG	ulOverflowShift,ulTotalBinning;

	ULONG	*pulStorageBuffer;
	ULONG	*pulAuxBuffer=NULL;
	USHORT	*pusSrcBuffer;
	USHORT	*pusDisplayBuffer;

	iViewNumber = *(view->m_piViewNumber);
	s_binningX = *(view->m_piSpatialBinningX);
	s_binningY = *(view->m_piSpatialBinningY);
	t_binning = *(view->m_piTemporalBinning);

	dwSrcSizeXRecords	= view->m_sizeROIBinned.cx*s_binningX;
	dwDestSizeXRecords	= view->m_sizeROIBinned.cx;
	dwDestSizeYRecords	= view->m_sizeROIBinned.cy; 
	dwDestSizeRecords	= dwDestSizeXRecords*dwDestSizeYRecords; 
	dwMainXRecords		= view->m_psizeROIMain->cx;
	dwSrcShiftRecords	= view->m_psizeROIMain->cx - view->m_sizeROIBinned.cx*s_binningX;
	dwSrcOffsetBytes = (view->m_rectROIBinning.left+view->m_rectROIBinning.top*view->m_psizeROIMain->cx)*sizeof(unsigned short);

	dwDestShiftRecords	= view->m_sizeROIBinnedCorecoCrap.cx - dwDestSizeXRecords;
	dwDestSizeXBytes	= dwDestSizeXRecords*sizeof(unsigned short);

	ulTotalBinning=(ULONG)s_binningX*(ULONG)s_binningY*(ULONG)t_binning;
	for(ulOverflowShift=1;ulTotalBinning>>ulOverflowShift;ulOverflowShift++);
	ulOverflowShift--;
	if(ulTotalBinning == 1UL<<ulOverflowShift){ 
		bShift=TRUE;
	}
	else{
		ulOverflowShift=ulTotalBinning;
	}

	if(s_binningX*s_binningY == 1){
		bFast=TRUE;
		if(t_binning==1){
			bVeryFast=TRUE;
			dwDestShiftRecords = view->m_sizeROIBinnedCorecoCrap.cx;
		}
	}
	else{ 
		bFast=FALSE;
		if(!(pulAuxBuffer=(ULONG*)calloc(dwSrcSizeXRecords,sizeof(ULONG)))){
			PrintThreadMessage("FocusThread: Cannot allocate for pulAuxBuffer");
			return(1);
		}
	}

//	sprintf(str,"SRC Size Records X=%i",dwSrcSizeXRecords);	PrintThreadMessage(str);
//	sprintf(str,"SRC Shift=%i Offset=%i",dwSrcShiftRecords,dwSrcOffsetBytes);	PrintThreadMessage(str);
//	sprintf(str,"DEST Size Records X=%i Y=%i",dwDestSizeXRecords,dwDestSizeYRecords);	PrintThreadMessage(str);
//	sprintf(str,"DEST Shift Records %i",dwDestShiftRecords);	PrintThreadMessage(str);

	pulStorageBuffer	= view->m_pulLocalStorageBuffer;
	pusDisplayBuffer	= (USHORT*)view->m_pbLocalDisplayBuffer;

	iTemporalBinningCount=0;

//	sprintf(str,"Total bin %i shift %i",ulTotalBinning,ulOverflowShift);	PrintThreadMessage(str);

	initime_external=1000.0*HighPrecisionClock();

	if((iExpectedRingFrameNum=pCamera->GrabWaitFrameEx(
			hGrabID, &pbFrameAddress,
			iWaitForFrameNum, dwInitialTimeOutMilliseconds,
			0, pdwAcquiredSizeY,
			pbVirtualFrameEnd,&structFrameAttributes)) <0){
			fintime_external=1000.0*HighPrecisionClock();
			if(fintime_external-initime_external < dwInitialTimeOutMilliseconds/2){
				sprintf(str,"%i Make sure Frame Server is grabbing",iViewNumber);
				PrintThreadMessage(LEVEL_ERROR,"Make sure Frame Server is grabbing");
				iExitCode = -2;
			}
			else{
				sprintf(str,"%i Timed out after %i msec (%i)",iViewNumber,dwInitialTimeOutMilliseconds,iExpectedRingFrameNum);
				PrintThreadMessage(LEVEL_ERROR,str);
				PrintThreadMessage(LEVEL_ERROR,"Make sure camera is on");
				iExitCode = -1;
			}
			goto bailout;
	}
	pCamera->GrabRelease(hGrabID, iExpectedRingFrameNum);

	initime_external=1000.0*HighPrecisionClock();
	initime_internal=0.001*structFrameAttributes.ArrivalTime;
	ulCurrentFrame=iniframe=structFrameAttributes.frameSeqNum;
	iLastFilledFrameSeqNum=pCamera->GrabFrameSeqNum(hGrabID);
//	sprintf(str,"%i First Received %i Filled %i",iViewNumber,ulCurrentFrame,iLastFilledFrameSeqNum);	PrintThreadMessage(str);

	while (!*pbShutdown) {
		if ((iRingFrameNum=pCamera->GrabWaitFrameEx(
			hGrabID, &pbFrameAddress,
			iWaitForFrameNum, dwTimeOutMilliseconds,
			bLock, pdwAcquiredSizeY,
			pbVirtualFrameEnd,&structFrameAttributes)) >= 0) {

			if((dDelay=(dArrival=HighPrecisionClockUsec()) - structFrameAttributes.ArrivalTime) >  dInterFrameTimeUsec){
				ulDelayedFrameCount++;
				dMaxDelay = dMaxDelay > dDelay ? dMaxDelay : dDelay;
			}
			dAverageDelay+=dDelay;
			ulFrameCount++;
/*			if(++ulCurrentFrame != structFrameAttributes.frameSeqNum){
				iLastFilledFrameSeqNum=pCamera->GrabFrameSeqNum(hGrabID);
				sprintf(str,"%i Skip E %i R-E %i F %i Delay %.3f msec %i frames",iViewNumber,ulCurrentFrame,
						structFrameAttributes.frameSeqNum-ulCurrentFrame,iLastFilledFrameSeqNum,
						floor(dDelay)*0.001,(int)(dDelay/dInterFrameTimeUsec));
				PrintThreadMessage(str);
				if(!ulFirstSkippedFrame) ulFirstSkippedFrame=ulCurrentFrame+dwNFramesRingBuffer;
				ulCurrentFrame=structFrameAttributes.frameSeqNum;
			}
			iExpectedRingFrameNum=(++iExpectedRingFrameNum)%dwNFramesRingBuffer;
			if(iExpectedRingFrameNum != iRingFrameNum){
				sprintf(str,"%i Ring %i %i",iViewNumber,iExpectedRingFrameNum,iRingFrameNum);
				PrintThreadMessage(str);
				iExpectedRingFrameNum=iRingFrameNum;			
			}
*/
/*
			sprintf(str,"%i Frame %5i(%02i) Locked=%i Bad=%i",iViewNumber,
				structFrameAttributes.frameSeqNum,iRingFrameNum,
				structFrameAttributes.FrameIsLocked,
				structFrameAttributes.potentiallyBad);
			PrintThreadMessage(str);
*/
			
			pusSrcBuffer = (USHORT*)(pbFrameAddress + dwSrcOffsetBytes);

			if(bFast){
				if(iTemporalBinningCount++){
					AugmentBufferFast(pulStorageBuffer,pusSrcBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords);
				}
				else{
					InitBufferFast(pulStorageBuffer,pusSrcBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords);
				}
			}
			else{
				if(iTemporalBinningCount++){
					AugmentBuffer(pulStorageBuffer,pusSrcBuffer,pulAuxBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
						s_binningX,s_binningY);
				}
				else{
					InitBuffer(pulStorageBuffer,pusSrcBuffer,pulAuxBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
						s_binningX,s_binningY);
//					InitBufferNoAux(pulStorageBuffer,pusSrcBuffer,
//						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
//						s_binningX,s_binningY);
				}
			}
			pCamera->GrabRelease(hGrabID, iRingFrameNum);

//			MinMaxStats(pulStorageBuffer,dwDestSizeRecords,ulMin,ulMax,ulMinC,ulMaxC,ulAverage);
//			sprintf(str,"%i MM %04x %04x %04x",iViewNumber,ulMin>>4,ulMax>>4,ulAverage);
//			PrintThreadMessage(str);


			dAverageProccesing+=(dProccesing=HighPrecisionClockUsec())-dArrival;

			if(iTemporalBinningCount==t_binning){
				iTemporalBinningCount=0;

			if(*pbHistogram){
				memset(*ppulHistogram,0,*pulNBins*sizeof(ULONG));
				HistogramStats(pulStorageBuffer,dwDestSizeRecords,*ppulHistogram,(ulTotalBinning*65536)/(*pulNBins));
				PostMessage(pParams->hMsgWnd,UWM_ON_UPDATE_HISTOGRAM,(WPARAM)0,(LPARAM)0);
			}

			if(*pbTrace){
				if(*pbTraceAverage){
					PostMessage(pParams->hMsgWnd,UWM_ON_UPDATE_TRACE,
						(WPARAM)(structFrameAttributes.frameSeqNum/t_binning),
						(LPARAM)AverageStats(pulStorageBuffer,dwDestSizeRecords));
				}
				else{
					PostMessage(pParams->hMsgWnd,UWM_ON_UPDATE_TRACE,
						(WPARAM)(structFrameAttributes.frameSeqNum/t_binning),(LPARAM)0);
				}
			}

				if(*pbDisplayFrames){
					if(bVeryFast){
						SourceToDisplay(pusDisplayBuffer,pusSrcBuffer,
						dwDestSizeXBytes,dwDestSizeYRecords,dwDestShiftRecords,dwMainXRecords);
					}
					else{
						if(bShift){
							FillDisplayBufferShift(pusDisplayBuffer,pulStorageBuffer,
										  dwDestSizeXRecords,dwDestSizeYRecords,
										  dwDestShiftRecords,ulOverflowShift);
						}
						else{
							FillDisplayBufferDivide(pusDisplayBuffer,pulStorageBuffer,
										  dwDestSizeXRecords,dwDestSizeYRecords,
										  dwDestShiftRecords,ulOverflowShift);
						}
					}
					if(view->m_hImageConnection){
						view->m_hImageConnection->Display();
					}
					else{
						PrintThreadMessage(LEVEL_ERROR,"FocusThread: view->m_hImageConnection=NULL");
						break;
					}
				}
			}
			dAverageDisplay+=HighPrecisionClockUsec()-dProccesing;
		}
		else{
			sprintf(str,"%i Buffer overflow %i",iViewNumber,iRingFrameNum);
			PrintThreadMessage(str);
			iExitCode = 1;
			break;
		}
	}

	fintime_external=1000.0*HighPrecisionClock();
	pCamera->GetGrabStats(hGrabID,&structCameraStats);

	fintime_internal=0.001*structFrameAttributes.ArrivalTime;
	finframe=structFrameAttributes.frameSeqNum;
	dAverageDelay/=ulFrameCount;
	dAverageProccesing/=ulFrameCount;
	dAverageDisplay/=ulFrameCount;

	iViewNumber = *(view->m_piViewNumber);
	sprintf(str,"%i Acquired %i(%i) Frames in %.3fmsec",
		iViewNumber,ulFrameCount,finframe-iniframe,fintime_external-initime_external);
	PrintThreadMessage(str);
	sprintf(str,"%i Actual Rate %.3fHz",iViewNumber,ulFrameCount*1000.0/(fintime_external-initime_external));
	PrintThreadMessage(str);
	sprintf(str,"%i Expected Rate %.3fHz (%.3fmsec)",iViewNumber,
		(finframe-iniframe)*1000.0/(fintime_internal-initime_internal),floor(dInterFrameTimeUsec)*0.001);
	PrintThreadMessage(str);
	sprintf(str,"%i Average Proccesing Time %.3f msec",iViewNumber,floor(dAverageProccesing)*0.001);
	PrintThreadMessage(str);
	sprintf(str,"%i Average Display Time %.3f msec",iViewNumber,floor(dAverageDisplay)*0.001);
	PrintThreadMessage(str);
	dAverageTotal = dAverageProccesing+dAverageDisplay;
	sprintf(str,"%i Average Total Time %.3f msec",iViewNumber,floor(dAverageTotal)*0.001);
	PrintThreadMessage(str);

	sprintf(str,"%i Frames: Locked %i Lost %i Missed %i",iViewNumber,
		structCameraStats.NumberOfFramesLocked,structCameraStats.NumberOfFramesLost,structCameraStats.NumberOfFramesMissed);
	PrintThreadMessage(LEVEL_HIGH,str);
	sprintf(str,"%i Frames: Next %i Await %i",iViewNumber,
		structCameraStats.CurrentFrameSeqNum,structCameraStats.NumberOfFramesAwaitDelivery);
	PrintThreadMessage(LEVEL_HIGH,str);

	if(ulDelayedFrameCount){
		sprintf(str,"%i Thread has been late %u times",iViewNumber,ulDelayedFrameCount);
		PrintThreadMessage(LEVEL_WARNING,str);
		sprintf(str,"%i Delay Max %.3f msec Average %.3f msec",iViewNumber,floor(dMaxDelay)*0.001,floor(dAverageDelay)*0.001);
		PrintThreadMessage(LEVEL_WARNING,str);
		double dTransferTime=dAverageTotal-dInterFrameTimeUsec/(1.0-(double)dwNFramesRingBuffer/(double)ulFirstSkippedFrame);		sprintf(str,"%i Transfer Time %.3f msec",iViewNumber,floor(dTransferTime)*0.001);
		PrintThreadMessage(LEVEL_WARNING,str);
	}
	else{
		sprintf(str,"%i Average delay %.3f msec",iViewNumber,floor(dAverageDelay)*0.001);
		PrintThreadMessage(str);
	}

bailout:

	if(pulAuxBuffer) free(pulAuxBuffer);
	if(iExitCode) 
		PostMessage(pParams->hMsgWnd,UWM_FOCUS_THREAD_FINISHED,(WPARAM)iExitCode,(LPARAM)iViewNumber);
	sprintf(str,"FocusThread %i on exit",iViewNumber);
	PrintThreadMessage(LEVEL_NORMAL,str);
	ExitThread(iExitCode);
	return(iExitCode);
}


DWORD WINAPI ExperimentThread(LPVOID params){
	EXPERIMENT_THREAD_PARAMS*	pParams = (EXPERIMENT_THREAD_PARAMS*)params;
	CContImageView*		view				= (CContImageView *)(pParams->pView);
	int					iThreadSeqNum		= pParams->iThreadSeqNum;
	BOOL volatile		*piShutdown			= pParams->piShutdown;
	HANDLE volatile		*phEvent			= pParams->phEvent;
	ULONG volatile		*pulFrameLockState	= pParams->pulFrameLockState;
	DWORD				dwNFramesRingBuffer = pParams->dwNFramesRingBuffer;
	BYTE**				ppbFrameBufferEntry = pParams->ppbFrameBufferEntry;
	BYTE**				ppbFrameHeaderBufferEntry = pParams->ppbFrameHeaderBufferEntry;
	BOOL volatile		*pbDisplayFrames	= pParams->pbDisplayFrames;
	ULONG				ulFrameHeaderSize	= pParams->ulFrameHeaderSize;

	ULONG	ulFrameLockMask = (1<<iThreadSeqNum);
	ULONG	ulFrameUnlockMask = ~ulFrameLockMask;

	int		iViewNumber = *(view->m_piViewNumber);
	int		s_binningX = *(view->m_piSpatialBinningX);
	int		s_binningY = *(view->m_piSpatialBinningY);
	int		t_binning = *(view->m_piTemporalBinning);

	DWORD	dwSrcOffsetBytes;
	DWORD	dwSrcShiftRecords;
	DWORD	dwDestShiftRecords;
	DWORD	dwDestSizeXRecords;
	DWORD	dwDestSizeYRecords;
	DWORD	dwDestSizeRecords;
	DWORD	dwSrcSizeXRecords;

	BOOL	bFast=FALSE,bShift=FALSE;

	int		iExitCode = 0;
	int		iWaitState;
	int		iLastFilledFrameSeqNum=-1;
	int		iTemporalBinningCount;

	double	dIniTimeUsec,dFinTimeUsec;
	double	dDelay=0.0,dMaxDelay=0.0,dArrival,dProccesing,dSaving;
	double	dAverageDelay=0.0,dAverageProccesing=0.0,dAverageSaving=0.0,dAverageDisplay=0.0,dAverageTotal;

	DWORD	dwInitialTimeOutMilliseconds=2000;
	DWORD	dwTimeOutMilliseconds=1500;
	
	ULONG	ulRingFrameNum=0;
	ULONG	ulFrameCount=0;
	ULONG	ulExpectedRingFrameNum=0;
	ULONG	ulDelayedFrameCount=0;
	ULONG	ulFirstSkippedFrame=0;
	ULONG	ulDisplayFrameCount=0;

	ULONG	ulOverflowShift,ulSaveShift=0,ulTotalBinning;

	void	(*pfunStorageToSave)(void*,ULONG*,ULONG,ULONG);
	ULONG	*pulStorageBuffer;
	ULONG	*pulAuxBuffer=NULL;
	USHORT	*pusSrcBuffer;
	USHORT	*pusDisplayBuffer;
	void	*pImageBuffer;
	void	*pSaveBuffer;
	ULONG	ulSaveBufferSize;
	ULONG	ulImageBufferSize;

	ULONG	ulFrameSizeEntry;

	char	str[256];
	int		iQueUnload=0;
	int		iWriteError;


	dwSrcSizeXRecords	= view->m_sizeROIBinned.cx*s_binningX;
	dwDestSizeXRecords	= view->m_sizeROIBinned.cx;
	dwDestSizeYRecords	= view->m_sizeROIBinned.cy; 
	dwDestSizeRecords	= dwDestSizeXRecords*dwDestSizeYRecords;
	dwSrcShiftRecords	= view->m_psizeROIMain->cx - view->m_sizeROIBinned.cx*s_binningX;
	dwSrcOffsetBytes	= (view->m_rectROIBinning.left+view->m_rectROIBinning.top*view->m_psizeROIMain->cx)*sizeof(USHORT);

	dwDestShiftRecords	= view->m_sizeROIBinnedCorecoCrap.cx - dwDestSizeXRecords;

	if(s_binningX*s_binningY == 1){
		bFast=TRUE;
	}
	else{ 
		bFast=FALSE;
		if(!(pulAuxBuffer=(ULONG*)calloc(dwSrcSizeXRecords,sizeof(ULONG)))){
			PrintThreadMessage("FocusThread: Cannot allocate for pulAuxBuffer");
			return(1);
		}
	}

	sprintf(str,"SRC Size Records X=%i",dwSrcSizeXRecords);
	PrintThreadMessage(str);
	sprintf(str,"SRC Shift=%i Offset=%i",dwSrcShiftRecords,dwSrcOffsetBytes);
	PrintThreadMessage(str);
	sprintf(str,"DEST Size Records X=%i Y=%i",dwDestSizeXRecords,dwDestSizeYRecords);
	PrintThreadMessage(str);
	sprintf(str,"DEST Shift Records %i",dwDestShiftRecords);
	PrintThreadMessage(str);

	pulStorageBuffer	= view->m_pulLocalStorageBuffer;
	pusDisplayBuffer	= (USHORT*)view->m_pbLocalDisplayBuffer;
	pSaveBuffer			= view->m_pLocalSaveBuffer;
	ulSaveBufferSize	= view->m_dwLocalSaveBufferSize;
	pImageBuffer		= (BYTE*)pSaveBuffer + ulFrameHeaderSize;
	ulImageBufferSize	= view->m_dwLocalImageBufferSize;

	ulFrameSizeEntry	= sizeof(FRAM_CHUNK)+4;

	iTemporalBinningCount=0;
	ulTotalBinning=(ULONG)s_binningX*(ULONG)s_binningY*(ULONG)t_binning;
	for(ulOverflowShift=1;ulTotalBinning>>ulOverflowShift;ulOverflowShift++);
	ulOverflowShift--;

	switch(pParams->iDataType){
	case DATATYPE_UCHAR:
		if(ulTotalBinning == 1UL<<ulOverflowShift){ 
			ulSaveShift = 8+ulOverflowShift;
			pfunStorageToSave = StorageToSaveUCHARFast;
		}
		else{
			ulSaveShift=ulTotalBinning*256;
			pfunStorageToSave = StorageToSaveUCHAR;
		}
		break;
	case DATATYPE_USHORT:
		if(ulTotalBinning == 1UL<<ulOverflowShift || ulTotalBinning <= 16){ 
			ulSaveShift = ulOverflowShift > 4 ? ulOverflowShift : 4;
			pfunStorageToSave = StorageToSaveUSHORTFast;
		}
		else{
			ulSaveShift = ulTotalBinning;
			pfunStorageToSave = StorageToSaveUSHORT;
		}
		break;
	case DATATYPE_ULONG:
		pfunStorageToSave = StorageToSaveULONG;
		break;
	case DATATYPE_FLOAT:
		pfunStorageToSave = StorageToSaveFLOAT;
		break;
	default:
		sprintf(str,"ExperimentThread: Unknown data type %i",pParams->iDataType);
		PrintThreadMessage(LEVEL_ERROR,str);
		goto bailout;
	}

	if(ulTotalBinning == 1UL<<ulOverflowShift){ 
		bShift=TRUE;
	}
	else{
		ulOverflowShift=ulTotalBinning;
	}

	sprintf(str,"Total bin %i shift %i %i",ulTotalBinning,ulOverflowShift,ulSaveShift);
	PrintThreadMessage(str);


	// Wait for first frame
	if((iWaitState=WaitForSingleObject(*phEvent,dwInitialTimeOutMilliseconds)) != WAIT_OBJECT_0){
		if(iWaitState == WAIT_TIMEOUT){
			sprintf(str,"ET %i Initial Timeout(%i)",iViewNumber,dwInitialTimeOutMilliseconds);
			PrintThreadMessage(LEVEL_WARNING,str);
			iExitCode = -1;
			goto bailout;
		}
		if(iWaitState == WAIT_FAILED){
			sprintf(str,"ET %i WAIT_FAILED GetLastError=%i",iViewNumber,GetLastError());
			PrintThreadMessage(LEVEL_ERROR,str);
			iExitCode = -11;
			goto bailout;
		}
	}
	dIniTimeUsec=HighPrecisionClockUsec();

	// Spin till the first locked frame found 
	for(ulRingFrameNum=0;
		!(pulFrameLockState[ulRingFrameNum]&ulFrameLockMask);
		ulRingFrameNum=(++ulRingFrameNum)%dwNFramesRingBuffer);

	if(ulRingFrameNum){
		sprintf(str,"%i First %i ",iViewNumber,ulRingFrameNum);
		PrintThreadMessage(LEVEL_HIGH,str);
	}

	// Unlock frame, reset event, increment counter, go to the loop
	pulFrameLockState[ulRingFrameNum] &= ulFrameUnlockMask;
	ResetEvent(*phEvent);
	ulExpectedRingFrameNum=ulRingFrameNum;
	ulRingFrameNum=(++ulRingFrameNum)%dwNFramesRingBuffer;
	ulFrameCount = 0;

	while (1) {
		if((iWaitState=WaitForSingleObject(*phEvent,dwTimeOutMilliseconds)) != WAIT_OBJECT_0){
			if(iWaitState == WAIT_TIMEOUT){
				sprintf(str,"ET %i Timeout(%imsec)",iViewNumber,dwTimeOutMilliseconds);
				PrintThreadMessage(LEVEL_WARNING,str);
				iExitCode = -1;
				goto printStatsAndExit;
			}
			if(iWaitState == WAIT_FAILED){
				sprintf(str,"ET %i WAIT_FAILED GetLastError=%i",iViewNumber,GetLastError());
				PrintThreadMessage(LEVEL_ERROR,str);
				iExitCode = -11;
				goto printStatsAndExit;
			}
		}


		while((pulFrameLockState[ulRingFrameNum] & ulFrameLockMask) && (*piShutdown != THREAD_SHUTDOWN_ABORT)){
			if(*piShutdown) iQueUnload++;

			dArrival=HighPrecisionClockUsec();
			ulFrameCount++;

			// Consistency check
			ulExpectedRingFrameNum=(++ulExpectedRingFrameNum)%dwNFramesRingBuffer;
			if(ulExpectedRingFrameNum != ulRingFrameNum){
				sprintf(str,"%i Ring E%i R%i",iViewNumber,ulExpectedRingFrameNum,ulRingFrameNum);
				PrintThreadMessage(str);
				ulExpectedRingFrameNum=ulRingFrameNum;			
			}

			
			// Binning routines
			pusSrcBuffer = (USHORT*)(ppbFrameBufferEntry[ulRingFrameNum] + dwSrcOffsetBytes);

			if(bFast){
				if(iTemporalBinningCount++){
					AugmentBufferFast(pulStorageBuffer,pusSrcBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords);
				}
				else{
					InitBufferFast(pulStorageBuffer,pusSrcBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords);
				}
			}
			else{
				if(iTemporalBinningCount++){
					AugmentBuffer(pulStorageBuffer,pusSrcBuffer,pulAuxBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
						s_binningX,s_binningY);
				}
				else{
					InitBuffer(pulStorageBuffer,pusSrcBuffer,pulAuxBuffer,
						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
						s_binningX,s_binningY);
//					InitBufferNoAux(pulStorageBuffer,pusSrcBuffer,
//						dwSrcShiftRecords,dwDestSizeXRecords,dwDestSizeYRecords,
//						s_binningX,s_binningY);
				}
			}

			if(iTemporalBinningCount==t_binning){
				// Copy frame header right after last added frame
				// All time dependent variables saved in the frame header are the ones for
				// the last frame in the T binning sequence
				memcpy(pSaveBuffer,ppbFrameHeaderBufferEntry[ulRingFrameNum],ulFrameHeaderSize);
				*((ULONG*)((BYTE*)pSaveBuffer+ulFrameSizeEntry)) += ulImageBufferSize;
			}

			// Unlock frame
			pulFrameLockState[ulRingFrameNum] &= ulFrameUnlockMask;
			// Augment Ring counter
			ulRingFrameNum = (++ulRingFrameNum)%dwNFramesRingBuffer;

			dAverageProccesing+=(dProccesing=HighPrecisionClockUsec())-dArrival;

			if(iTemporalBinningCount==t_binning){
				iTemporalBinningCount=0;
				// Save routine
				pfunStorageToSave(pImageBuffer,pulStorageBuffer,dwDestSizeRecords,ulSaveShift);

				if((iWriteError=view->SmartWrite(pSaveBuffer,ulSaveBufferSize))){
					sprintf(str,"FocusThread %i: Write error %i",iViewNumber,iWriteError);
					PrintThreadMessage(LEVEL_ERROR,str);
					goto printStatsAndExit;
				}

				dAverageSaving+=(dSaving=HighPrecisionClockUsec())-dProccesing;

				// Display routine
				if(*pbDisplayFrames){
					if(bShift){
						FillDisplayBufferShift(pusDisplayBuffer,pulStorageBuffer,
									  dwDestSizeXRecords,dwDestSizeYRecords,dwDestShiftRecords,ulOverflowShift);
					}
					else{
						FillDisplayBufferDivide(pusDisplayBuffer,pulStorageBuffer,
									  dwDestSizeXRecords,dwDestSizeYRecords,dwDestShiftRecords,ulOverflowShift);
					}
					if(view->m_hImageConnection){
						view->m_hImageConnection->Display();
					}
					else{
						PrintThreadMessage(LEVEL_ERROR,"FocusThread: view->m_hImageConnection=NULL");
						goto bailout;
					}
					ulDisplayFrameCount++;
					dAverageDisplay+=HighPrecisionClockUsec()-dSaving;
				}
			}
		}
		if(*piShutdown) goto printStatsAndExit;
		ResetEvent(*phEvent);
	}

printStatsAndExit:

	dFinTimeUsec=HighPrecisionClockUsec();

	dAverageDelay/=ulFrameCount;
	dAverageProccesing/=ulFrameCount;
	dAverageSaving/=ulFrameCount;
	dAverageTotal = dAverageProccesing+dAverageSaving;

	iViewNumber = *(view->m_piViewNumber);
	sprintf(str,"%i Acquired %i Frames in %.3fmsec(%.3f)",
		iViewNumber,ulFrameCount,0.001*(dProccesing-dIniTimeUsec),1.0e-6*(dFinTimeUsec-dProccesing));
	PrintThreadMessage(str);

	sprintf(str,"%i Frame Rate %.3fHz (%.3fmsec)",iViewNumber,
		ulFrameCount*1.0e+6/(dProccesing-dIniTimeUsec),1.0e-3*(dProccesing-dIniTimeUsec)/ulFrameCount);
	PrintThreadMessage(str);

	sprintf(str,"%i Average Proccesing Time %.3f msec",iViewNumber,floor(dAverageProccesing)*0.001);
	PrintThreadMessage(str);
	sprintf(str,"%i Average Saving Time %.3f msec",iViewNumber,floor(dAverageSaving)*0.001);
	PrintThreadMessage(str);
	if(ulDisplayFrameCount){
		dAverageDisplay/=ulFrameCount;
		dAverageTotal += dAverageDisplay;
		sprintf(str,"%i Average Display Time %.3f msec",iViewNumber,floor(dAverageDisplay)*0.001);
		PrintThreadMessage(str);
		sprintf(str,"%i Average Total Time %.3f msec",iViewNumber,floor(dAverageTotal)*0.001);
		PrintThreadMessage(str);
	}
	else{
		sprintf(str,"%i Average Total Time %.3f msec",iViewNumber,floor(dAverageTotal)*0.001);
		PrintThreadMessage(str);
	}

	if(iQueUnload){
		sprintf(str,"%i Unloaded %i frames",iViewNumber,iQueUnload);
		PrintThreadMessage(LEVEL_NORMAL,str);
	}
	

bailout:

	if(!iExitCode) iExitCode = *piShutdown;
	PostMessage(pParams->hMainWnd,UWM_EXPERIMENT_THREAD_FINISHED,(WPARAM)iExitCode,(LPARAM)iThreadSeqNum);
	PostMessage(pParams->hMsgWnd,UWM_EXPERIMENT_THREAD_FINISHED,(WPARAM)iExitCode,(LPARAM)iThreadSeqNum);
	sprintf(str,"ET Shutdown = %i",*piShutdown);
	PrintThreadMessage(str);
	if(pulAuxBuffer) free(pulAuxBuffer);
	ExitThread(iExitCode);
	return(iExitCode);
}



DWORD WINAPI TriggerThread(LPVOID pparams){
	TRIGGER_THREAD_PARAMS*	pParams = (TRIGGER_THREAD_PARAMS*)pparams;
	CAMERA				*pCamera	= pParams->pCamera;
	GRAB_HANDLE			hGrabID		= pParams->hGrabID;
	DWORD				dwNFramesRingBuffer	= pParams->dwNFramesRingBuffer;
	BOOL volatile		*pbShutdown	= pParams->pbShutdown;
	int volatile		*piShutdownOther	= pParams->piShutdownOther;
	int					iNEvents	= pParams->iNEvents;
	HANDLE volatile		*phEvents	= pParams->phEvents;
	ULONG volatile		*pulFrameLockState	= pParams->pulFrameLockState;
	int volatile		*pulFrameLockMask	= (volatile int*)pParams->pulFrameLockMask;
	BYTE				**ppbFrameHeaderBufferEntry = pParams->ppbFrameHeaderBufferEntry;
	ULONG				(*pfunExperimentCallback)(WPARAM,LPARAM,double) = pParams->pfunExperimentCallback;
	int					iNframes	= pParams->iNframes;
	double				dInterFrameTimeUsec = (double)(pParams->dwInterFrameTimeUsec);
	void				*pExperimentControl= pParams->pExperimentControl;

	BYTE*	pbListOfLockedFrames;

	int			iRingFrameNum;
	BYTE*		pbFrameAddress;
	int			iWaitForFrameNum=IFC_WAIT_NEWER_FRAME;
	DWORD		dwTimeOutMilliseconds=IFC_WAIT_FOREVER;
	BOOL		bLock=TRUE;
	DWORD*		pdwAcquiredSizeY=NULL;//Val: not used for PCDig
	BOOL*		pbVirtualFrameEnd=NULL;
	FRAME_ATTRIBUTES	structFrameAttributes;
	CAMERA_STATISTICS	structCameraStats;
	
	FRAM_CHUNK	*pFrameChunk;

	double	dIniExternalTimeUsec,dFinExternalTimeUsec;	//microseconds
	double	dIniInternalTimeUsec,dFinInternalTimeUsec;	//microseconds
	double	dDifferentialArrival;
	double	dDelay=0.0,dMaxDelay=0.0,dArrival,dProccesing;
	double	dAverageDelay=0.0,dAverageProccesing=0.0;

	long	lIniFrame,lFinFrame;
	int		iExitCode = 0;
	int		iExpectedRingFrameNum;
	int		iLastFilledFrameSeqNum=-1;
	int		iFrameSeq;

	DWORD	dwInitialTimeOutMilliseconds=2000;
	
	ULONG	ulDelayedFrameCount=0,ulFrameCount=0,ulCurrentFrame,ulFirstSkippedFrame=0;
	int		iSkipNFirstFrames = 1;

	int		i;
	ULONG	ul;
	DWORD	dw;
	char	str[256];
	ULONG	ulExperimentMessage;

	if(!(pbListOfLockedFrames=(BYTE*)calloc(dwNFramesRingBuffer,sizeof(BYTE)))){
		PrintThreadMessage("TT Cannot allocate for pbListOfLockedFrames");
		return(1);
	}

	dIniExternalTimeUsec=HighPrecisionClockUsec();
	for(i=0;i<iSkipNFirstFrames;i++){
		if((iExpectedRingFrameNum=pCamera->GrabWaitFrameEx(
				hGrabID, &pbFrameAddress,
				iWaitForFrameNum, dwInitialTimeOutMilliseconds,
				0, pdwAcquiredSizeY,
				pbVirtualFrameEnd,&structFrameAttributes)) <0){

				dFinExternalTimeUsec=HighPrecisionClock()-dIniExternalTimeUsec;
				if(dFinExternalTimeUsec*0.001 < dwInitialTimeOutMilliseconds>>1){
					PrintThreadMessage(LEVEL_ERROR,"Make sure Frame Server is grabbing");
					iExitCode = -2;
				}
				else{
					sprintf(str,"TT (%i) Timed out after %i msec",iExpectedRingFrameNum,dwInitialTimeOutMilliseconds);
					PrintThreadMessage(LEVEL_ERROR,str);
					PrintThreadMessage(LEVEL_ERROR,"Make sure camera is on");
					iExitCode = -1;
				}
				goto bailout;
		}
	}

	sprintf(str,"TT Lock mask %lu",*pulFrameLockMask);
	PrintThreadMessage(str);
	sprintf(str,"TT Frames %i",iNframes);
	PrintThreadMessage(str);

	dIniExternalTimeUsec=HighPrecisionClockUsec();
	pCamera->GrabRelease(hGrabID, iExpectedRingFrameNum);
	dIniInternalTimeUsec=structFrameAttributes.ArrivalTime;

	ulCurrentFrame=lIniFrame=structFrameAttributes.frameSeqNum;
	iLastFilledFrameSeqNum=pCamera->GrabFrameSeqNum(hGrabID);

	pulFrameLockState[iExpectedRingFrameNum] = *pulFrameLockMask;
	for(i=0;i<iNEvents;i++) if(phEvents[i]) SetEvent(phEvents[i]);

	sprintf(str,"TT First Received %i Filled %i",ulCurrentFrame,iLastFilledFrameSeqNum);
	PrintThreadMessage(str);


	ulExperimentMessage=0;

		// The loop
	for(iFrameSeq=0;!*pbShutdown && (iFrameSeq<iNframes || ulExperimentMessage);iFrameSeq++){
		if ((iRingFrameNum=pCamera->GrabWaitFrameEx(
			hGrabID, &pbFrameAddress,
			iWaitForFrameNum, dwTimeOutMilliseconds,
			bLock, pdwAcquiredSizeY,
			pbVirtualFrameEnd,&structFrameAttributes)) >= 0) {

			if((dDelay=(dArrival=HighPrecisionClockUsec()) - structFrameAttributes.ArrivalTime) >  dInterFrameTimeUsec){
				ulDelayedFrameCount++;
				dMaxDelay = dMaxDelay > dDelay ? dMaxDelay : dDelay;
			}
			dAverageDelay+=dDelay;

			ulFrameCount++;

			if(++ulCurrentFrame != structFrameAttributes.frameSeqNum){
				iLastFilledFrameSeqNum=pCamera->GrabFrameSeqNum(hGrabID);
				sprintf(str,"TT Skip E %i R-E %i F %i Delay %.3f msec %i frames",ulCurrentFrame,
						structFrameAttributes.frameSeqNum-ulCurrentFrame,iLastFilledFrameSeqNum,
						floor(dDelay)*0.001,(int)(dDelay/dInterFrameTimeUsec));
				PrintThreadMessage(str);
				if(!ulFirstSkippedFrame) ulFirstSkippedFrame=ulCurrentFrame+dwNFramesRingBuffer;
				ulCurrentFrame=structFrameAttributes.frameSeqNum;
			}
			iExpectedRingFrameNum=(++iExpectedRingFrameNum)%dwNFramesRingBuffer;
			if(iExpectedRingFrameNum != iRingFrameNum){
				sprintf(str,"TT Ring %i %i",iExpectedRingFrameNum,iRingFrameNum);
				PrintThreadMessage(str);
				iExpectedRingFrameNum=iRingFrameNum;			
			}

			pFrameChunk = (FRAM_CHUNK*)(ppbFrameHeaderBufferEntry[iRingFrameNum]);

			ulExperimentMessage = (pFrameChunk->CallbackResult = 
				pfunExperimentCallback((WPARAM)pExperimentControl,(LPARAM)((BYTE*)pFrameChunk+sizeof(FRAM_CHUNK)),
										structFrameAttributes.ArrivalTime)) & EXPERIMENT_MESSAGE_MASK;

			pFrameChunk->FrameSeqNumber=structFrameAttributes.frameSeqNum;
			pFrameChunk->FrameRingNumber=iRingFrameNum;

			if((dDifferentialArrival = structFrameAttributes.ArrivalTime-dIniInternalTimeUsec) >= 4294967296.){
				pFrameChunk->TimeArrivalUsecHi=(ULONG)(dDifferentialArrival/4294967296.);
				pFrameChunk->TimeArrivalUsecLo=(ULONG)(dDifferentialArrival - pFrameChunk->TimeArrivalUsecHi*4294967296.);
			}
			else{
				pFrameChunk->TimeArrivalUsecHi=0UL;
				pFrameChunk->TimeArrivalUsecLo=(ULONG)(dDifferentialArrival);
			}

			pFrameChunk->TimeDelayUsec = (ULONG)dDelay;
			pFrameChunk->PotentiallyBad = structFrameAttributes.potentiallyBad;
			pFrameChunk->Locked = structFrameAttributes.FrameIsLocked;
			pFrameChunk->FrameSeqCount = iFrameSeq;

			if(pulFrameLockState[iRingFrameNum]){
				sprintf(str,"TT Ring %i is locked",iRingFrameNum);
				PrintThreadMessage(LEVEL_ERROR,str);
			}
			pulFrameLockState[iRingFrameNum] = *pulFrameLockMask;
			pbListOfLockedFrames[iRingFrameNum] = 1;

			// Should use a mutex here
			for(i=0;i<iNEvents;i++) if(phEvents[i]) SetEvent(phEvents[i]);

			for(dw=iRingFrameNum+1;dw<dwNFramesRingBuffer+iRingFrameNum;dw++){
				ul=dw%dwNFramesRingBuffer;
				if(!pulFrameLockState[ul] && pbListOfLockedFrames[ul]){
					pbListOfLockedFrames[ul] = 0;
					pCamera->GrabRelease(hGrabID, ul);
//					sprintf(str,"TT Release %i %i",ul,iRingFrameNum);
//					PrintThreadMessage(str);
				}
			}

			
//	sprintf(str,"TT %lu %i %i",*pulFrameLockMask,iRingFrameNum,iRingFrameNum-(iFrameSeq+1)%dwNFramesRingBuffer);
//	PrintThreadMessage(str);
			
//			sprintf(str,"TT Seq %i  Ring %i %i-%i",iFrameSeq,iRingFrameNum,
//				pulFrameLockState[iRingFrameNum],pbListOfLockedFrames[iRingFrameNum]);
//			PrintThreadMessage(str);

/*
			sprintf(str,"TT Frame %5i(%02i) Locked=%i Bad=%i",
				structFrameAttributes.frameSeqNum,iRingFrameNum,
				structFrameAttributes.FrameIsLocked,
				structFrameAttributes.potentiallyBad);
			PrintThreadMessage(str);
*/
			
//			pCamera->GrabRelease(hGrabID, iRingFrameNum);

			dAverageProccesing+=(dProccesing=HighPrecisionClockUsec())-dArrival;
		}
		else{
			sprintf(str,"TT Buffer overflow %i",iRingFrameNum);
			PrintThreadMessage(str);
		}
	}

	dFinExternalTimeUsec=HighPrecisionClockUsec();
	pCamera->GetGrabStats(hGrabID,&structCameraStats);

	dFinInternalTimeUsec=structFrameAttributes.ArrivalTime;
	lFinFrame=structFrameAttributes.frameSeqNum;
	dAverageDelay/=ulFrameCount;
	dAverageProccesing/=ulFrameCount;

	sprintf(str,"TT Acquired %i(%i) Frames in %.3fmsec",
		ulFrameCount,lFinFrame-lIniFrame,0.001*(dFinExternalTimeUsec-dIniExternalTimeUsec));
	PrintThreadMessage(str);
	sprintf(str,"TT Actual Rate %.3fHz",ulFrameCount*1.0e+6/(dFinExternalTimeUsec-dIniExternalTimeUsec));
	PrintThreadMessage(str);
	sprintf(str,"TT Expected Rate %.3fHz (%.3fmsec)",(lFinFrame-lIniFrame)*1.0e+6/(dFinInternalTimeUsec-dIniInternalTimeUsec),
			floor(dInterFrameTimeUsec)*0.001);
	PrintThreadMessage(str);
	sprintf(str,"TT Average Proccesing Time %.3f msec",floor(dAverageProccesing)*0.001);
	PrintThreadMessage(str);

	sprintf(str,"TT Frames: Locked %i Lost %i Missed %i",
		structCameraStats.NumberOfFramesLocked,structCameraStats.NumberOfFramesLost,structCameraStats.NumberOfFramesMissed);
	PrintThreadMessage(LEVEL_HIGH,str);
	sprintf(str,"TT Frames: Next %i Await %i",
		structCameraStats.CurrentFrameSeqNum,structCameraStats.NumberOfFramesAwaitDelivery);
	PrintThreadMessage(LEVEL_HIGH,str);

	if(ulDelayedFrameCount){
		sprintf(str,"TT Thread has been late %u times",ulDelayedFrameCount);
		PrintThreadMessage(LEVEL_WARNING,str);
		sprintf(str,"TT Delay Max %.3f msec Average %.3f msec",floor(dMaxDelay)*0.001,floor(dAverageDelay)*0.001);
		PrintThreadMessage(LEVEL_WARNING,str);
		double dTransferTime=dAverageProccesing-dInterFrameTimeUsec/(1.0-(double)dwNFramesRingBuffer/(double)ulFirstSkippedFrame);
		sprintf(str,"TT Transfer Time %.3f msec",floor(dTransferTime)*0.001);
		PrintThreadMessage(LEVEL_WARNING,str);
	}
	else{
		sprintf(str,"TT Average delay %.3f msec",floor(dAverageDelay)*0.001);
		PrintThreadMessage(str);
	}

bailout:
	int iShutdown = *pbShutdown == 0 ? THREAD_SHUTDOWN_STOP : *pbShutdown;
	sprintf(str,"TT Shutdown = %i",iShutdown);
	PrintThreadMessage(str);
	for(i=0;i<iNEvents;i++){
		piShutdownOther[i] = iShutdown;
		// Should use a mutex here
		if(phEvents[i]) SetEvent(phEvents[i]);
	}

	free(pbListOfLockedFrames);
	PostMessage(pParams->hMsgWnd,UWM_TRIGGER_THREAD_FINISHED,(WPARAM)iExitCode,(LPARAM)0);
	ExitThread(iExitCode);
	return(iExitCode);
}
