// SynchUDP.cpp: implementation of the CSynchUDP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "contimage.h"
#include "SynchUDP.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSynchUDP::CSynchUDP(USHORT usLocalPort,char *pcRemoteHost){

	m_ulSynchDataNBits=16;
	m_pUDPChannels=NULL;
	m_pulSynchChannelsData=NULL;

	m_usSynchPort=usLocalPort;
	if(m_pcRemoteHost) m_pcRemoteHost=strdup(pcRemoteHost);
	else m_pcRemoteHost= NULL;

	InitUDPChannels(N_UDP_CHANNELS);

	m_iSocketFD=-1;

	if(BeginWindowsCrap()){
	}
	else{
		m_iSynchUDPThreadShutdown=0;
		m_hSynchUDPThread=NULL;
		m_dwSynchUDPThreadID=0;
		if(StartUDPSynchThread()){
		}
		else{
		}
	}
}

CSynchUDP::~CSynchUDP(){
	StopUDPSynchThread();
	EndWindowsCrap();
	if(m_pulSynchChannelsData) free((void*)m_pulSynchChannelsData);
	if(m_pUDPChannels) free(m_pUDPChannels);
}

int CSynchUDP::BeginWindowsCrap(){
	WSADATA structWSAData; 
	WORD wVersion; 
	int iReturn = 0;  

	wVersion = (MAKEWORD(2, 2)); 
	iReturn = WSAStartup(wVersion, &structWSAData); 
	if(WSAStartup(wVersion, &structWSAData)){
		iReturn = WSAGetLastError(); 
		if (iReturn == WSANOTINITIALISED){  
			::MessageBox(NULL,"Socket initialization failed","CSynchUDP",MB_OK); 
		}
	}
	return(iReturn);
}

int CSynchUDP::EndWindowsCrap(){
	int iReturn = 0;  
	if(WSACleanup()){
		iReturn = WSAGetLastError(); 
	}
	return(iReturn);
}

int CSynchUDP::InitUDPChannels(int iNC){
	int iError=0;
//	char str[128];

	m_iNUDPChannels=iNC;

	if(!(m_pulSynchChannelsData=(ULONG volatile *)calloc(m_iNUDPChannels,sizeof(ULONG)))){
		iError=1;
		return(iError);
	}

	if(!(m_pUDPChannels=(UDP_CHANNEL *)calloc(m_iNUDPChannels,sizeof(UDP_CHANNEL)))){
		iError=2;
		return(iError);
	}

	for(int i=0;i<m_iNUDPChannels;i++){
		m_pUDPChannels[i].iChannelNum=i;
		m_pUDPChannels[i].pcRemoteHost=m_pcRemoteHost;
		m_pUDPChannels[i].iPort=m_usSynchPort;
		m_pUDPChannels[i].iDirection=UDP_CHANNEL_DIRECTION_IN;
		m_pUDPChannels[i].ulBitCount=m_ulSynchDataNBits;
		m_pUDPChannels[i].ulBitMask=((ULONG)~0)>>(32-m_ulSynchDataNBits);
		m_pUDPChannels[i].pfunWrite=NULL;
		m_pUDPChannels[i].pfunRead=NULL;
		m_pUDPChannels[i].pulDataIn=m_pulSynchChannelsData+i;
		m_pUDPChannels[i].pulDataOut=NULL;
		m_pUDPChannels[i].dArrivalTimeUsec=0;
		m_pulSynchChannelsData[i]=~(0UL);
	}
	return(iError);
}

int CSynchUDP::StartUDPSynchThread(){
	char str[256];
	char ch='1';

/*
	struct hostent *pHostEnt;
	if(!(pHostEnt=gethostbyname(m_pcRemoteHost))){
		sprintf(str,"Cannot get remote host WSAGetLastError=%lu",WSAGetLastError());
		PrintMessage(LEVEL_ERROR,str);
 		::MessageBox(NULL,str,"CSynchUDP",MB_OK); 
	}
*/

	if((m_iSocketFD = socket(AF_INET, SOCK_DGRAM, 0)) == -1){
		sprintf(str,"Cannot create socket WSAGetLastError=%lu",WSAGetLastError());
		PrintMessage(LEVEL_ERROR,str);
 		::MessageBox(NULL,str,"CSynchUDP",MB_OK); 
		return(2);
	}

	if(setsockopt(m_iSocketFD,SOL_SOCKET,SO_REUSEADDR,&ch,sizeof(ch))) {
		sprintf(str,"Cannot set socket option WSAGetLastError=%lu",WSAGetLastError());
		PrintMessage(LEVEL_ERROR,str);
 		::MessageBox(NULL,str,"CSynchUDP",MB_OK); 
		return(3);
	}


	m_LocalAddress.sin_family = AF_INET;
	m_LocalAddress.sin_port = htons(m_usSynchPort);
	m_LocalAddress.sin_addr.s_addr = INADDR_ANY; 
	memset(&(m_LocalAddress.sin_zero), '\0', 8); 

	if (bind(m_iSocketFD, (struct sockaddr *)&m_LocalAddress, sizeof(struct sockaddr)) == -1){
		sprintf(str,"Cannot bind socket WSAGetLastError=%lu",WSAGetLastError());
		PrintMessage(LEVEL_ERROR,str);
 		::MessageBox(NULL,str,"CSynchUDP",MB_OK); 
		return(4);
	}

	m_SynchUDPTreadParams.hMsgWnd = NULL;
	m_SynchUDPTreadParams.piSocketFD = &m_iSocketFD;
	m_SynchUDPTreadParams.piShutdown = &m_iSynchUDPThreadShutdown;
	m_SynchUDPTreadParams.iNUDPChannels = m_iNUDPChannels;
	m_SynchUDPTreadParams.pUDPChannels = m_pUDPChannels;
	m_SynchUDPTreadParams.pLocalAddress = &m_LocalAddress;
	m_SynchUDPTreadParams.pRemoteAddress = &m_RemoteAddress;

	if(!(m_hSynchUDPThread = CreateThread(NULL,(DWORD)0x10000,SynchUDPThread,
							(LPVOID)&m_SynchUDPTreadParams,0x0,&m_dwSynchUDPThreadID ))){
		sprintf(str,"Cannot start SynchUDPThread GetLastError=%lu",GetLastError());
		PrintMessage(LEVEL_ERROR,str);
 		::MessageBox(NULL,str,"CSynchUDP",MB_OK); 
		return(5);
	}

	return(0);
}

int CSynchUDP::StopUDPSynchThread(){
	DWORD dwExitCode=0;
//	char str[128];

	if(!GetExitCodeThread(m_hSynchUDPThread, &dwExitCode)){ 
//		sprintf(str,"StopUDPSynchThread: Cannot get SynchUDPThread Exit Code GetLastError=%lu",GetLastError());
//		PrintMessage(LEVEL_ERROR,str);
		return(1);
	}

	if(dwExitCode == STILL_ACTIVE){
		if(!CloseHandle(m_hSynchUDPThread)){
//			sprintf(str,"Cannot close SynchUDPThread handle GetLastError=%lu",GetLastError());
//			PrintMessage(LEVEL_ERROR,str);
			return(2);
		}
//		sprintf(str,"SynchUDPThread Exit Code %i",(int)dwExitCode);
//		PrintMessage(LEVEL_NORMAL,str);
	}
	else{
//		sprintf(str,"SynchUDPThread already exited with Exit Code %i",(int)dwExitCode);
//		PrintMessage(LEVEL_NORMAL,str);
	}

	m_hSynchUDPThread = NULL;

	if(m_iSocketFD!=-1) close(m_iSocketFD);
	m_iSocketFD=-1;

	return(0);
}

DWORD WINAPI SynchUDPThread(LPVOID params){
	SYNCH_UDP_THREAD_PARAMS*	pParams = (SYNCH_UDP_THREAD_PARAMS*)params;
	int				*piSocketFD = pParams->piSocketFD;
	int volatile	*piShutdown = pParams->piShutdown;
	int				iNUDPChannels = pParams->iNUDPChannels;
	UDP_CHANNEL		*pUDPChannels = pParams->pUDPChannels;
	struct sockaddr_in *pLocalAddress = pParams->pLocalAddress;
	struct sockaddr_in *pRemoteAddress = pParams->pRemoteAddress;

	int iExitCode=0;
	int iAddressLength;
	int iBytesReceived;
	char strBuffer[BUFFER_SIZE];
	char str[256];
	unsigned short usSynchChannel;
	double dReceiveTimeUsec;

	iAddressLength = sizeof(struct sockaddr);
	while(1){
		if((iBytesReceived=recvfrom(*piSocketFD,strBuffer,BUFFER_SIZE-1,0,
												(struct sockaddr*)pRemoteAddress,&iAddressLength))==-1){
			sprintf(str,"recvfrom failed WSAGetLastError=%lu (WSAEMSGSIZE=%i)",WSAGetLastError(),WSAEMSGSIZE);
			PrintThreadMessage(LEVEL_ERROR,str);
			strBuffer[BUFFER_SIZE-1] = '\0';
		}
		else{
			strBuffer[iBytesReceived] = '\0';
		}
		dReceiveTimeUsec=HighPrecisionClockUsec();
//		sprintf(str,"UDP Packet from %s",inet_ntoa(pRemoteAddress->sin_addr));
//		PrintThreadMessage(str);
//		sprintf(str,"UDP Packet = \"%s\" (%i)",strBuffer,iBytesReceived);
//		PrintThreadMessage(str);
		if(*strBuffer=='S' && *(strBuffer+1)=='Y'){
			usSynchChannel=*(unsigned short*)(strBuffer+2);
			if(usSynchChannel<iNUDPChannels){
				*(pUDPChannels[usSynchChannel].pulDataIn)=*(unsigned long*)(strBuffer+4);
				pUDPChannels[usSynchChannel].dArrivalTimeUsec=dReceiveTimeUsec;
//				sprintf(str,"UDP Channel %u Synch %u",usSynchChannel,*(pUDPChannels[usSynchChannel].pulDataIn));
//				PrintThreadMessage(str);
			}
			else{
				sprintf(str,"Incorrect UDP Channel %i",usSynchChannel);
				PrintThreadMessage(str);
			}
		}
	}
	return(iExitCode);
}
