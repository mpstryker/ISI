// SynchUDP.h: interface for the CSynchUDP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNCHUDP_H__A07C6783_B829_48DA_AA17_ABC77DB8D86A__INCLUDED_)
#define AFX_SYNCHUDP_H__A07C6783_B829_48DA_AA17_ABC77DB8D86A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <winsock2.h>

#define BUFFER_SIZE 64
#define DEFAULT_SYNCH_PORT 8936  

#define N_UDP_CHANNELS	4

#define UDP_CHANNEL_DIRECTION_NONE	0
#define UDP_CHANNEL_DIRECTION_IN	1
#define UDP_CHANNEL_DIRECTION_OUT	2

typedef struct UDP_CHANNEL{
	int iChannelNum;
	char *pcRemoteHost;
	int iPort;
	int iDirection; // None, In, Out
	ULONG ulBitCount;
	ULONG ulBitMask;
	int  (*pfunWrite)(ULONG);
	int  (*pfunRead)(ULONG&);
	ULONG volatile *pulDataIn;
	ULONG volatile *pulDataOut;
	double dArrivalTimeUsec;
} UDP_CHANNEL;

typedef struct SYNCH_UDP_THREAD_PARAMS{
	HWND				hMsgWnd;
	int					*piSocketFD;
	int volatile		*piShutdown;
	int					iNUDPChannels;
	UDP_CHANNEL			*pUDPChannels;
	struct sockaddr_in	*pLocalAddress;
	struct sockaddr_in	*pRemoteAddress;
} SYNCH_UDP_THREAD_PARAMS;

class CSynchUDP{

public:
	CSynchUDP(USHORT usLocalPort = DEFAULT_SYNCH_PORT,char *pcRemoteHost = NULL);
	virtual ~CSynchUDP();

	friend DWORD WINAPI SynchUDPThread(LPVOID params);
	friend ReadUDPPort(ULONG& ulData);

	int BeginWindowsCrap();
	int EndWindowsCrap();

	ULONG m_ulSynchDataNBits;

	int			m_iNUDPChannels;
	UDP_CHANNEL *m_pUDPChannels;
	ULONG volatile *m_pulSynchChannelsData;
	double *m_pulSynchChannelsRecTimeUsec;

	int m_iSocketFD;
	USHORT m_usSynchPort;
	char *m_pcRemoteHost;
	struct sockaddr_in m_LocalAddress;
	struct sockaddr_in m_RemoteAddress;

	int volatile 	m_iSynchUDPThreadShutdown;
	HANDLE			m_hSynchUDPThread;
	DWORD			m_dwSynchUDPThreadID;
	SYNCH_UDP_THREAD_PARAMS m_SynchUDPTreadParams;

	int StartUDPSynchThread();
	int StopUDPSynchThread();

	int InitUDPChannels(int iNC);
};

#endif // !defined(AFX_SYNCHUDP_H__A07C6783_B829_48DA_AA17_ABC77DB8D86A__INCLUDED_)
