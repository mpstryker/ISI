#if !defined(AFX_ROI_H__1562E503_4F1F_4FEA_977B_6E3AFC566D46__INCLUDED_)
#define AFX_ROI_H__1562E503_4F1F_4FEA_977B_6E3AFC566D46__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ROI.h : header file
//

#define MAX_NROI 32

typedef struct ROI{
	BOOL	bHidden;
	BOOL	bRealized;
	BOOL	bModified;
	int		iNumber;
	CRect*	pRect;
}ROI;

/////////////////////////////////////////////////////////////////////////////
// CROI window

class CROI : public CList<ROI*,ROI*>
{
// Construction
public:
	CROI(UINT = 1024,UINT = 1024);

// Attributes
public:

	CSize	m_sizeROIMain;
	CRect	m_rectROIMain;
	ROI		m_ROIMain;
	BOOL	m_bKeepOriginalNumbers;
	BOOL	m_bMaximizeNewNumbers;

	void ResetMainROI(UINT,UINT);
	void RescaleAllROI(UINT cx,UINT cy);

	int GetIndex(CRect*);
	int GetSeqIndex(CRect*);
	int GetNumber(CRect*);
	int AddROI(CRect*,int = 0);
	int RemoveROI(CRect*);
	int GetROI(CRect**);
	ROI* FindROI(CRect*);
	ROI* GetHeadROI();
	ROI* GetNextROI(ROI *pROI);

	ROI*	GetUnrealizedROI();
	float	GetTotalArea(ULONG *pulTotalArea = NULL,ULONG *pulMainArea = NULL);

	BOOL EditROI(int iBinningX,int iBinningY);

private:
	int GetAvailableNumber();
	int GetLargestNumber();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CROI)
	//}}AFX_VIRTUAL
// Implementation
public:
	virtual ~CROI();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ROI_H__1562E503_4F1F_4FEA_977B_6E3AFC566D46__INCLUDED_)
