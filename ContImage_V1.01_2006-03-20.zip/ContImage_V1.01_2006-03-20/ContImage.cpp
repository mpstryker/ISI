// ContImage.cpp : Defines the class behaviors for the application.
//
// Val: 11-19-2002 removed falling into default focus after switching from 
// the experiment to the focus mode (new var m_iFocusDynamicMode).




#include "stdafx.h"
#include "ContImage.h"

char * g_szVersion = "ContImage Version 1.01  2006/03/20";

#include "MainFrm.h"
#include "ChildFrm.h"
#include "ContImageDoc.h"
#include "ContImageView.h"

#include <sys/stat.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <afxmt.h>
//create global mutex used for verification that only one instance exists
CMutex mutexGlobalApp(FALSE, "UCSF-Val-ContImageMutex");

/////////////////////////////////////////////////////////////////////////////
// API

static const UINT UWM_ON_ROI_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_ROI_CHANGE"));
static const UINT UWM_ON_SPATIAL_BINNING_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_SPATIAL_BINNING_CHANGE"));
static const UINT UWM_ON_TEMPORAL_BINNING_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_TEMPORAL_BINNING_CHANGE"));
static const UINT UWM_ON_REMOVED_SUB_ROI = ::RegisterWindowMessage(_T("UWM_ON_REMOVED_SUB_ROI"));
static const UINT UWM_ON_START_GRABBING = ::RegisterWindowMessage(_T("UWM_ON_START_GRABBING"));
static const UINT UWM_ON_STOP_GRABBING = ::RegisterWindowMessage(_T("UWM_ON_STOP_GRABBING"));
static const UINT UWM_ON_FILL_STORAGE_BUFFER = ::RegisterWindowMessage(_T("UWM_ON_FILL_STORAGE_BUFFER"));
static const UINT UWM_ON_CHANGE_MODES = ::RegisterWindowMessage(_T("UWM_ON_CHANGE_MODES"));

// Constants

const char strModeTag[MODE_NUMBER+1]={"XGEST"};

const char strApplicationModeTag[APPLICATION_MODE_NUMBER+1]={"NFE"};
const char strFocusModeTag[FOCUS_MODE_NUMBER+1]={"NGE"};
const char strExperimentModeTag[EXPERIMENT_MODE_NUMBER+1]={"NSC"};
const char strExperimentSumModeTag[EXPERIMENT_SUM_MODE_NUMBER+1]={"NS"};
const char strExperimentContinuousModeTag[EXPERIMENT_CONTINUOUS_MODE_NUMBER+1]={"NCE"};

/////////////////////////////////////////////////////////////////////////////
// CContImageApp registry

LPCSTR lpszSettings					= "Settings";
LPCSTR lpszUserName					= "UserName";
LPCSTR lpszSubjectID				= "SubjectID";

LPCSTR lpszDataDirectory			= "DataDirectory";
LPCSTR lpszLogDirectory				= "LogDirectory";
LPCSTR lpszExperimentContinuousMode	= "ExperimentContinuousMode";
LPCSTR lpszTemporalExperimentBinning= "TemporalExperimentBinning";
LPCSTR lpszSpatialExperimentBinningX= "SpatialExperimentBinningX";
LPCSTR lpszSpatialExperimentBinningY= "SpatialExperimentBinningY";
LPCSTR lpszDataType					= "DataType";

LPCSTR lpszOpticsFocalLengthTop		= "OpticsFocalLengthTop";
LPCSTR lpszOpticsFocalLengthBottom	= "OpticsFocalLengthBottom";
LPCSTR lpszFocusWaveLength			= "FocusWaveLength";
LPCSTR lpszFocusFilterWidth			= "FocusFilterWidth";
LPCSTR lpszExperimentWaveLength		= "ExperimentWaveLength";
LPCSTR lpszExperimentFilterWidth	= "ExperimentFilterWidth";

LPCSTR lpszHardwareInterFrameTime	= "HardwareInterFrameTime";
LPCSTR lpszHardwareIntegrationTime	= "HardwareIntegrationTime";
LPCSTR lpszHardwareBinningV			= "HardwareBinningV";
LPCSTR lpszHardwareBinningH			= "HardwareBinningH";
LPCSTR lpszHardwareGain				= "HardwareGain";
LPCSTR lpszHardwareOffset			= "HardwareOffset";

LPCSTR lpszStimulationPeriod		= "StimulationPeriod";
LPCSTR lpszStimulationCycles		= "StimulationCycles";

LPCSTR lpszNFramesStim				= "NFramesStim";
LPCSTR lpszNFramesITI				= "NFramesITI";
LPCSTR lpszNFramesBlank				= "NFramesBlank";
LPCSTR lpszNConditions				= "NConditions";
LPCSTR lpszNRepetitions				= "NRepetitions";
LPCSTR lpszRandomize				= "Randomize";

LPCSTR lpszNFrames					= "NFrames";

/////////////////////////////////////////////////////////////////////////////
// CContImageApp

BEGIN_MESSAGE_MAP(CContImageApp, CWinApp)
	//{{AFX_MSG_MAP(CContImageApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_SETTINGS_EXPERIMENT, OnSettingsExperiment)
	ON_UPDATE_COMMAND_UI(ID_SETTINGS_EXPERIMENT, OnUpdateSettingsExperiment)
	ON_COMMAND(ID_SETTINGS_GET, OnSettingsGet)
	ON_COMMAND(ID_SETTINGS_SAVE, OnSettingsSave)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_ACQUIRE_CAM_ZOOM_CAPS, OnAcquireCamZoomCaps)
	ON_COMMAND(ID_ACQUIRE_CAM_ATTR, OnAcquireCamAttr)
	ON_COMMAND(ID_ACQUIRE_MISC_BRODCAST_MSG, OnAcquireMiscBrodcastMsg)
	ON_COMMAND(ID_FILE_CLOSE, OnFileClose)
	ON_COMMAND(ID_ACQUIRE_MISC_SERIAL_PORT_SETTINGS, OnAcquireMiscSerialPortSettings)
	ON_COMMAND(ID_ACQUIRE_MISC_HARDWARE_SETTINGS, OnAcquireMiscHardwareSettings)
	ON_COMMAND(ID_SETTINGS_HARDWARE, OnSettingsHardware)
	ON_COMMAND(ID_ACQUIRE_CAM_SOFT_RESET, OnAcquireCamSoftReset)
	ON_COMMAND(ID_ACQUIRE_CAM_HARD_RESET, OnAcquireCamHardReset)
	ON_COMMAND(ID_SETTINGS_FOCUS, OnSettingsFocus)
	ON_COMMAND(ID_ACQUIRE_MISC_TEST, OnAcquireMiscTest)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_ACQUIRE_CAM_MISC, OnAcquireCamMisc)
	ON_COMMAND(ID_ACQUIRE_CAM_READ_CAPS, OnAcquireCamReadCaps)
	ON_COMMAND(ID_ACQUIRE_CAM_LUT_CAPS, OnAcquireCamLutCaps)
	ON_COMMAND(ID_ACQUIRE_MISC_MEMORY_STATUS, OnAcquireMiscMemoryStatus)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_ALL, OnUpdateFileSaveAll)
	ON_UPDATE_COMMAND_UI(ID_SETTINGS_FOCUS, OnUpdateSettingsFocus)
	ON_COMMAND(ID_ACQUIRE_DESTINATION_TOTAL_AREA, OnAcquireDestinationTotalArea)
	ON_COMMAND(ID_SETTINGS_ROI, OnSettingsROI)
	ON_UPDATE_COMMAND_UI(ID_SETTINGS_ROI, OnUpdateSettingsROI)
	ON_COMMAND(ID_ACQUIRE_MISC_DIO_TEST, OnAcquireMiscDIOTest)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContImageApp construction

CContImageApp::CContImageApp(){

	m_iApplicationMode				= DEFAULT_APPLICATION_MODE;
	m_iFocusMode					= DEFAULT_FOCUS_MODE;
	m_iExperimentMode				= DEFAULT_EXPERIMENT_MODE;
	m_iExperimentSumMode			= DEFAULT_EXPERIMENT_SUM_MODE;
	m_iExperimentContinuousMode	= DEFAULT_EXPERIMENT_CONTINUOUS_MODE;

	m_iServerDynamicMode = DEFAULT_SERVER_DYNAMIC_MODE;
	m_iFocusDynamicMode = DEFAULT_SERVER_DYNAMIC_MODE;
	m_iFocusFileSaveMode = DEFAULT_FOCUS_FILE_SAVE_MODE;

	m_iSpatialBinningX	= m_iSpatialFocusBinningX = DEFAULT_SPATIAL_FOCUS_BINNING;
	m_iSpatialBinningY	= m_iSpatialFocusBinningY = DEFAULT_SPATIAL_FOCUS_BINNING;
	m_iTemporalBinning	= m_iTemporalFocusBinning = DEFAULT_TEMPORAL_FOCUS_BINNING;

	m_iDocCount		= 0;

	m_pFrameServer	= new CFrameServer();

//	m_pSynchDIO = new CSynchDIO();
	m_pSynch = new CSynchronization();



	m_bMainROIOpened	= FALSE;
	m_bGreenAcquired	= FALSE;
	m_bGreenSaved		= FALSE;
	m_bRunningFocus		= FALSE;
	m_bRunningExperiment= FALSE;
	m_bExperimentPaused	= FALSE;

	m_iFileType=DEFAULT_FILE_TYPE;

	m_iDisplayFrames = 1;

	m_ulFileHeaderSize = 0;
	m_pFileHeaderTemplate = NULL;
	m_ulFrameHeaderSize = 0;
	m_pFrameHeaderTemplate = NULL;
	m_pfunExperimentCallback = NULL;

	m_pExperimentControl = NULL;

	m_piConditionList = NULL;

}

/////////////////////////////////////////////////////////////////////////////
// The one and only CContImageApp object

CContImageApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CContImageApp initialization

BOOL CContImageApp::InitInstance(){
//Make sure that only one instance of this app runs on the system
	if(mutexGlobalApp.Lock(0) == 0) return FALSE;
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	SetRegistryKey(_T("UCSF-Val"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	GetPrivateProfile();

	m_pROI = new CROI(m_pFrameServer->m_dwResolutionX,m_pFrameServer->m_dwResolutionY);
	
//	ROI *r = new ROI;
//	r->iNumber = 1;
//	r->pRect = new CRect(100,100,400,600);
//	m_pROI->AddTail(r);

	pDocTemplate = new CMultiDocTemplate(
		IDR_CONTIMTYPE,
		RUNTIME_CLASS(CContImageDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CContImageView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME)) return FALSE;
	m_pMainWnd = pMainFrame;

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo)) return FALSE;

	// The main window has been initialized, so show and update it.
  pMainFrame->SetTitle( g_szVersion );
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	InitVariables();

	return TRUE;
}

void CContImageApp::InitVariables(){
	struct tm *ptmTime;
	long lTime;

	srand((unsigned)time(&lTime));
	InitSeedRan3(lTime & 0xFFFFF);

	ptmTime = localtime( &lTime ); 
	m_sDay = ptmTime->tm_mday;	
	m_sMonth = ptmTime->tm_mon + 1;	
	m_sYear = ptmTime->tm_year - 100;	

	m_sExperimentNumber=0;
	m_sExperimentRun=0;

	SetApplicationMode();

//	srand((unsigned int)(lTime & 0xFFFF));  // set up random numbers for later use
	SetHighPrecisionClockFrequency();

}

void CContImageApp::GetPrivateProfile(){

	if(m_strUserName.IsEmpty()){
		m_strUserName = GetProfileString(lpszSettings, lpszUserName, DEFAULT_USER);
	}
	m_strSubjectID		= GetProfileString(m_strUserName, lpszSubjectID, "Gato Loco");
	m_strDataDirectory	= GetProfileString(m_strUserName, lpszDataDirectory, DEFAULT_DATA_DIRECTORY);
	m_strLogDirectory	= GetProfileString(m_strUserName, lpszLogDirectory, DEFAULT_LOG_DIRECTORY);

	m_iExperimentContinuousMode = GetProfileInt(m_strUserName, lpszExperimentContinuousMode, DEFAULT_EXPERIMENT_CONTINUOUS_MODE);

	m_iTemporalExperimentBinning= GetProfileInt(m_strUserName, lpszTemporalExperimentBinning, DEFAULT_TEMPORAL_EXPERIMENT_BINNING);
	m_iSpatialExperimentBinningX= GetProfileInt(m_strUserName, lpszSpatialExperimentBinningX, DEFAULT_SPATIAL_EXPERIMENT_BINNING);
	m_iSpatialExperimentBinningY= GetProfileInt(m_strUserName, lpszSpatialExperimentBinningY, DEFAULT_SPATIAL_EXPERIMENT_BINNING);
	m_iDataType			= GetProfileInt(m_strUserName, lpszDataType, DEFAULT_DATATYPE);

	m_nOpticsFocalLengthTop		=GetProfileInt(m_strUserName, lpszOpticsFocalLengthTop, 50);
	m_nOpticsFocalLengthBottom	=GetProfileInt(m_strUserName, lpszOpticsFocalLengthBottom, 50);
	m_nFocusWaveLength			=GetProfileInt(m_strUserName, lpszFocusWaveLength, 510);
	m_nFocusFilterWidth			=GetProfileInt(m_strUserName, lpszFocusFilterWidth, 20);
	m_nExperimentWaveLength		=GetProfileInt(m_strUserName, lpszExperimentWaveLength, 510);
	m_nExperimentFilterWidth	=GetProfileInt(m_strUserName, lpszExperimentFilterWidth, 20);

	m_pFrameServer->m_dwInterFrameTimeUsec=GetProfileInt(m_strUserName, lpszHardwareInterFrameTime, DEFAULT_HARDWARE_INTERFRAME_TIME_USEC);
	m_pFrameServer->m_dwIntegrationTimeUsec=GetProfileInt(m_strUserName, lpszHardwareIntegrationTime, DEFAULT_HARDWARE_INTEGRATION_TIME_USEC);
	m_pFrameServer->m_dwHardwareBinningV=GetProfileInt(m_strUserName, lpszHardwareBinningV, 1);
	m_pFrameServer->m_dwHardwareBinningH=GetProfileInt(m_strUserName, lpszHardwareBinningH, 1);
	m_pFrameServer->m_dwVideoGain=GetProfileInt(m_strUserName, lpszHardwareGain, 1);
	m_pFrameServer->m_lPixelOffset=GetProfileInt(m_strUserName, lpszHardwareOffset, 0);

	m_dStimulationPeriod=atof(GetProfileString(m_strUserName, lpszStimulationPeriod, "60.0"));
	m_dStimulationCycles=atof(GetProfileString(m_strUserName, lpszStimulationCycles, "10.0"));

	m_nNFramesStim		= GetProfileInt(m_strUserName, lpszNFramesStim, 20);
	m_nNFramesITI		= GetProfileInt(m_strUserName, lpszNFramesITI, 0);
	m_nNFramesBlankPre	= m_nNFramesBlankPost = GetProfileInt(m_strUserName, lpszNFramesBlank, 20);
	m_nNConditions		= GetProfileInt(m_strUserName, lpszNConditions, 1);
	m_nNRepetitions		= GetProfileInt(m_strUserName, lpszNRepetitions, 1);
	m_bRandomize		= GetProfileInt(m_strUserName, lpszRandomize, FALSE);

	m_nNFrames		= GetProfileInt(m_strUserName, lpszNFrames, DEFAULT_NFRAMES);
	
	CString msg="Settings retrieved for user "+m_strUserName;	
	PrintMessage(LEVEL_NORMAL, msg, msg.GetLength()+1);	
	m_pFrameServer->ResetHardware();
}

void CContImageApp::SavePrivateProfile(){
	CString strDummy;

	WriteProfileString(lpszSettings, lpszUserName, m_strUserName);

	WriteProfileString(m_strUserName, lpszSubjectID, m_strSubjectID);
	WriteProfileString(m_strUserName, lpszDataDirectory, m_strDataDirectory);
	WriteProfileString(m_strUserName, lpszLogDirectory, m_strLogDirectory);

	WriteProfileInt(m_strUserName, lpszExperimentContinuousMode, m_iExperimentContinuousMode);

	WriteProfileInt(m_strUserName, lpszTemporalExperimentBinning, m_iTemporalExperimentBinning);
	WriteProfileInt(m_strUserName, lpszSpatialExperimentBinningX, m_iSpatialExperimentBinningX);
	WriteProfileInt(m_strUserName, lpszSpatialExperimentBinningY, m_iSpatialExperimentBinningY);
	WriteProfileInt(m_strUserName, lpszDataType, m_iDataType);

	WriteProfileInt(m_strUserName, lpszOpticsFocalLengthTop, m_nOpticsFocalLengthTop);
	WriteProfileInt(m_strUserName, lpszOpticsFocalLengthBottom, m_nOpticsFocalLengthBottom);
	WriteProfileInt(m_strUserName, lpszFocusWaveLength, m_nFocusWaveLength);
	WriteProfileInt(m_strUserName, lpszFocusFilterWidth, m_nFocusFilterWidth);
	WriteProfileInt(m_strUserName, lpszExperimentWaveLength, m_nExperimentWaveLength);
	WriteProfileInt(m_strUserName, lpszExperimentFilterWidth, m_nExperimentFilterWidth);

	WriteProfileInt(m_strUserName, lpszHardwareInterFrameTime, m_pFrameServer->m_dwInterFrameTimeUsec);
	WriteProfileInt(m_strUserName, lpszHardwareIntegrationTime, m_pFrameServer->m_dwIntegrationTimeUsec);
	WriteProfileInt(m_strUserName, lpszHardwareBinningV, m_pFrameServer->m_dwHardwareBinningV);
	WriteProfileInt(m_strUserName, lpszHardwareBinningH, m_pFrameServer->m_dwHardwareBinningH);
	WriteProfileInt(m_strUserName, lpszHardwareGain, m_pFrameServer->m_dwVideoGain);
	WriteProfileInt(m_strUserName, lpszHardwareOffset, m_pFrameServer->m_lPixelOffset);

	strDummy.Format("%f",m_dStimulationPeriod);
	WriteProfileString(m_strUserName, lpszStimulationPeriod, strDummy);
	strDummy.Format("%f",m_dStimulationCycles);
	WriteProfileString(m_strUserName, lpszStimulationCycles, strDummy);

	WriteProfileInt(m_strUserName, lpszNFramesStim, m_nNFramesStim);
	WriteProfileInt(m_strUserName, lpszNFramesITI, m_nNFramesITI);
	WriteProfileInt(m_strUserName, lpszNFramesBlank, m_nNFramesBlankPre>m_nNFramesBlankPost?m_nNFramesBlankPre:m_nNFramesBlankPost);
	WriteProfileInt(m_strUserName, lpszNConditions, m_nNConditions);
	WriteProfileInt(m_strUserName, lpszNRepetitions, m_nNRepetitions);
	WriteProfileInt(m_strUserName, lpszRandomize, m_bRandomize);

	WriteProfileInt(m_strUserName, lpszNFrames, m_nNFrames);

	CString msg="Settings saved for user "+m_strUserName;	
	PrintMessage(LEVEL_NORMAL, msg, msg.GetLength()+1);	
}

void CContImageApp::OnSettingsGet(){
	GetPrivateProfile();
}

void CContImageApp::OnSettingsSave(){
	SavePrivateProfile();
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_lblVersion;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_lblVersion = _T("");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_LBL_VERSION, m_lblVersion);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CContImageApp::OnAppAbout()
{

  CAboutDlg aboutDlg;
  aboutDlg.m_lblVersion = g_szVersion;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CContImageApp commands

void CContImageApp::OnSettingsExperiment(){
	CExperimentDlg dlg;

	dlg.m_strUserName = m_strUserName;

	dlg.m_strSubjectID = m_strSubjectID;

	dlg.m_strDataDirectory = m_strDataDirectory;
	dlg.m_strLogDirectory = m_strLogDirectory;

	dlg.m_sMonth=m_sMonth;
	dlg.m_sDay=m_sDay;
	dlg.m_sYear=m_sYear;

	dlg.m_sExperimentNumber = m_sExperimentNumber;
	dlg.m_sExperimentRun = m_sExperimentRun;

	dlg.m_strFileName=m_strBaseFileName;

	dlg.m_iSpatialExperimentBinning = m_iSpatialExperimentBinningX;
	dlg.m_iTemporalExperimentBinning = m_iTemporalExperimentBinning;
	dlg.m_iTotalExperimentBinning = m_iTemporalExperimentBinning*m_iSpatialExperimentBinningX*m_iSpatialExperimentBinningY;

	dlg.m_iDataType = m_iDataType - DATATYPE_UCHAR;

	dlg.m_nOpticsFocalLengthTop = m_nOpticsFocalLengthTop;
	dlg.m_nOpticsFocalLengthBottom = m_nOpticsFocalLengthBottom;
	dlg.m_nWaveLength = m_nExperimentWaveLength;
	dlg.m_nFilterWidth = m_nExperimentFilterWidth;

	dlg.m_dwInterFrameTimeUsec = m_pFrameServer->m_dwInterFrameTimeUsec;
	dlg.m_fInterFrameTimeMsec = (float)(dlg.m_dwInterFrameTimeUsec/1000.0);

	dlg.m_iExperimentContinuousMode = m_iExperimentContinuousMode - 1;

	dlg.m_dStimulationPeriod = m_dStimulationPeriod;
	dlg.m_dStimulationCycles = m_dStimulationCycles;

	dlg.m_nNBinnedFramesStim = m_nNFramesStim/m_iTemporalExperimentBinning;
	dlg.m_nNBinnedFramesITI = m_nNFramesITI/m_iTemporalExperimentBinning;
	dlg.m_nNBinnedFramesBlank = (m_nNFramesBlankPre>m_nNFramesBlankPost?m_nNFramesBlankPre:m_nNFramesBlankPost)/m_iTemporalExperimentBinning;
	dlg.m_nNConditions = m_nNConditions;
	dlg.m_nNRepetitions = m_nNRepetitions;

	dlg.m_bRandomize = m_bRandomize;

//	dlg.m_nNFrames = m_nNFrames;

	dlg.m_strComments=m_strComments;
	dlg.m_dwMaxCommentCharacters=sizeof(m_MultiChunk.CChunk<HARD_CHUNK>::m_pChunk->Comments)-1;

	dlg.m_bDisableAll = m_bRunningExperiment;

	if(dlg.DoModal()==IDOK){
		m_strUserName = dlg.m_strUserName;
		m_strSubjectID = dlg.m_strSubjectID;

		m_strDataDirectory = dlg.m_strDataDirectory;
		m_strLogDirectory = dlg.m_strLogDirectory;

		m_sMonth=dlg.m_sMonth;
		m_sDay	=dlg.m_sDay;
		m_sYear	=dlg.m_sYear;
		if(m_iSpatialExperimentBinningX  != dlg.m_iSpatialExperimentBinning || 
		   m_iTemporalExperimentBinning != dlg.m_iTemporalExperimentBinning){
			m_iSpatialExperimentBinningX = dlg.m_iSpatialExperimentBinning;
			m_iSpatialExperimentBinningY = dlg.m_iSpatialExperimentBinning;
			m_iTemporalExperimentBinning = dlg.m_iTemporalExperimentBinning;
			if(m_iServerDynamicMode == SERVER_DYNAMIC_MODE_EXPERIMENT){
				m_iSpatialBinningX = m_iSpatialExperimentBinningX;
				m_iSpatialBinningY = m_iSpatialExperimentBinningY;
				m_iTemporalBinning = m_iTemporalExperimentBinning;
				m_pMainWnd->SendMessageToDescendants(UWM_ON_SPATIAL_BINNING_CHANGE,
											(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
			}
		}

		m_sExperimentNumber = dlg.m_sExperimentNumber;
		m_sExperimentRun= dlg.m_sExperimentRun;
	
		m_iDataType = dlg.m_iDataType + DATATYPE_UCHAR;

		m_nOpticsFocalLengthTop = dlg.m_nOpticsFocalLengthTop;
		m_nOpticsFocalLengthBottom = dlg.m_nOpticsFocalLengthBottom;
		m_nExperimentWaveLength = dlg.m_nWaveLength;
		m_nExperimentFilterWidth = dlg.m_nFilterWidth;

		m_iExperimentContinuousMode = dlg.m_iExperimentContinuousMode+1;

		m_dStimulationPeriod = dlg.m_dStimulationPeriod;
		m_dStimulationCycles = dlg.m_dStimulationCycles;
	
		m_nNFramesStim = dlg.m_nNFramesStim;
		m_nNFramesITI = dlg.m_nNFramesITI;
		m_nNFramesBlankPre = m_nNFramesBlankPost = dlg.m_nNFramesBlank;

		m_nNConditions = dlg.m_nNConditions;
		m_nNRepetitions = dlg.m_nNRepetitions;

		m_bRandomize = dlg.m_bRandomize;

		m_nNFrames = dlg.m_nNFrames;

		m_strComments = dlg.m_strComments;

		SetApplicationMode();

		PrintMessage(&dlg.m_strComments);
	}
}

void CContImageApp::OnUpdateSettingsExperiment(CCmdUI* pCmdUI) {
	// TODO: Add your command update UI handler code here
	
}


void CContImageApp::OnSettingsHardware(){
	if(m_pFrameServer->OnSettingsHardware()) UpdateFileHeader();
}


void CContImageApp::OnSettingsFocus(){
	CFocusDlg dlg;
	BOOL bRestart=FALSE;
	dlg.m_bMainROIOnly=(m_pROI->GetCount()==1);
	dlg.m_iFocusDynamicMode=m_iServerDynamicMode;
	dlg.m_iFocusBinningSpatialROI=m_iSpatialFocusBinningX;
	dlg.m_iFocusBinningTemporalROI=m_iTemporalFocusBinning;
	dlg.m_iFocusBinningSpatialExperiment=m_iSpatialExperimentBinningX;
	dlg.m_iFocusBinningTemporalExperiment=m_iTemporalExperimentBinning;
	dlg.m_iFocusSaveMode=m_iFocusFileSaveMode;
	dlg.m_nWaveLength = m_nExperimentWaveLength;
	dlg.m_nFilterWidth = m_nExperimentFilterWidth;
	if(dlg.DoModal()==IDOK){
		m_iFocusFileSaveMode=dlg.m_iFocusSaveMode;
		m_nExperimentWaveLength = dlg.m_nWaveLength;
		m_nExperimentFilterWidth = dlg.m_nFilterWidth;
		if(m_iServerDynamicMode != dlg.m_iFocusDynamicMode){
			switch(dlg.m_iFocusDynamicMode){
			case SERVER_DYNAMIC_MODE_ROI:
				m_iTemporalBinning = m_iTemporalFocusBinning = dlg.m_iFocusBinningTemporalROI;
				m_iSpatialBinningX = m_iSpatialFocusBinningX = dlg.m_iFocusBinningSpatialROI;
				m_iSpatialBinningY = m_iSpatialFocusBinningY = dlg.m_iFocusBinningSpatialROI;
				break;
			case SERVER_DYNAMIC_MODE_FAST:
				m_iTemporalBinning = 1;
				m_iSpatialBinningX = 1;
				m_iSpatialBinningY = 1;
				break;
			case SERVER_DYNAMIC_MODE_EXPERIMENT:
				m_iTemporalBinning = m_iTemporalExperimentBinning;
				m_iSpatialBinningX = m_iSpatialExperimentBinningX;
				m_iSpatialBinningY = m_iSpatialExperimentBinningY;
				break;
			default:
				PrintMessage(LEVEL_ERROR,"CContImageApp::OnSettingsFocus: Unknown Server Dynamic Mode");
				return;
			}
			bRestart=StopGrabbing();
			m_iFocusDynamicMode=m_iServerDynamicMode=dlg.m_iFocusDynamicMode;
			m_pMainWnd->SendMessageToDescendants(UWM_ON_SPATIAL_BINNING_CHANGE,
											(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
			if(bRestart) StartGrabbing();
		}
		else{
			switch(m_iServerDynamicMode){
			case SERVER_DYNAMIC_MODE_ROI:
				if(m_iSpatialFocusBinningX != dlg.m_iFocusBinningSpatialROI || 
				   m_iTemporalFocusBinning != dlg.m_iFocusBinningTemporalROI){
					m_iTemporalBinning = m_iTemporalFocusBinning = dlg.m_iFocusBinningTemporalROI;
					m_iSpatialBinningX = m_iSpatialFocusBinningX = dlg.m_iFocusBinningSpatialROI;
					m_iSpatialBinningY = m_iSpatialFocusBinningY = dlg.m_iFocusBinningSpatialROI;
					m_pMainWnd->SendMessageToDescendants(UWM_ON_SPATIAL_BINNING_CHANGE,
											(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
				}
				break;
			case SERVER_DYNAMIC_MODE_FAST:
				break;
			case SERVER_DYNAMIC_MODE_EXPERIMENT:
				break;
			default:
				PrintMessage(LEVEL_ERROR,"CContImageApp::OnSettingsFocus: Unknown Focus Dynamic Mode");
				return;
			}
		}
		UpdateFileHeader();
	}	
}


void CContImageApp::OnUpdateSettingsFocus(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_iApplicationMode != APPLICATION_MODE_EXPERIMENT);	
}

void CContImageApp::OnSettingsROI(){
	if(m_pROI->EditROI(m_iSpatialBinningX,m_iSpatialBinningY)) 
		m_pMainWnd->SendMessageToDescendants(UWM_ON_REMOVED_SUB_ROI,(WPARAM)(m_pROI->GetCount()));
}

void CContImageApp::OnUpdateSettingsROI(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_iApplicationMode != APPLICATION_MODE_EXPERIMENT);	
}



BOOL CContImageApp::OnFrameServerStart(int iMessage){
	if(m_bRunningFocus) return(FALSE);
	else{
		if(iMessage == FRAME_SERVER_MESSAGE_BINNING_CHANGE){
			m_pROI->RescaleAllROI(m_pFrameServer->m_dwResolutionX,m_pFrameServer->m_dwResolutionY);
			m_pMainWnd->SendMessageToDescendants(UWM_ON_ROI_CHANGE);
		}
		m_bRunningFocus=TRUE;
		m_pMainWnd->SendMessageToDescendants(UWM_ON_START_GRABBING);
		return(TRUE);
	}
}

BOOL CContImageApp::OnFrameServerStop(){
	if(m_bRunningFocus){
		m_pMainWnd->SendMessageToDescendants(UWM_ON_STOP_GRABBING);
		m_bRunningFocus=FALSE;
		return(TRUE);
	}
	else return(FALSE);
}

BOOL CContImageApp::StartGrabbing(){ 
	switch(m_iApplicationMode){
	case APPLICATION_MODE_NONE:
		PrintMessage("CContImageApp::StartGrabbing Application mode is not set");
		return(FALSE);
		break;
	case APPLICATION_MODE_FOCUS:
		if(m_pFrameServer->StartFrameServer(m_iServerDynamicMode,m_iApplicationMode)){
			m_bRunningFocus=TRUE;
			m_pMainWnd->SendMessageToDescendants(UWM_ON_START_GRABBING);
			return(TRUE);
		}
		else{
			PrintMessage(LEVEL_ERROR,"CContImageApp::StartGrabbing Failure to start Focus grab");
			return(FALSE);
		}
		break;
	case APPLICATION_MODE_EXPERIMENT:
		if(m_pFrameServer->StartFrameServer(m_iServerDynamicMode,m_iApplicationMode,m_iDocCount)){
			m_bRunningExperiment=TRUE;
			m_pMainWnd->SendMessageToDescendants(UWM_ON_START_GRABBING);
			return(TRUE);
		}	
		else{
			PrintMessage(LEVEL_ERROR,"CContImageApp::StartGrabbing Failure to start Experiment");
			return(FALSE);
		}
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Application mode");
		return(FALSE);
	}
}

BOOL CContImageApp::StopGrabbing(int iShutdown){
	BOOL bError=FALSE;
	switch(m_iApplicationMode){
	case APPLICATION_MODE_NONE:
		PrintMessage("CContImageApp::StopGrabbing Application mode is not set");
		return(FALSE);
		break;
	case APPLICATION_MODE_FOCUS:
		m_pMainWnd->SendMessageToDescendants(UWM_ON_STOP_GRABBING);
		m_bRunningFocus=FALSE;
		return(m_pFrameServer->StopFrameServer(iShutdown));
		break;
	case APPLICATION_MODE_EXPERIMENT:
//		m_pMainWnd->SendMessageToDescendants(UWM_ON_STOP_GRABBING,(WPARAM)iShutdown);
		if(m_bRunningExperiment){
			m_bRunningExperiment=FALSE;
			m_bExperimentPaused=FALSE;
			bError=m_pFrameServer->StopFrameServer(iShutdown);
			PrepareForNextExperiment();
		}
		return(bError);
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Application mode");
		return(FALSE);
	}
}

void CContImageApp::ResetHardwareBinning(DWORD ulBinning){
	BOOL bRestart=FALSE;	
	if(m_bRunningExperiment){
		PrintMessage(LEVEL_ERROR,"CContImageApp::ResetHardwareBinning: Cannot change hardware binning while running experiment");
		return;
	}

	bRestart=StopGrabbing();

	if(!m_pFrameServer->SetHardwareBinning(ulBinning)) bRestart=FALSE;
	m_pROI->RescaleAllROI(m_pFrameServer->m_dwResolutionX,m_pFrameServer->m_dwResolutionY);
	m_pMainWnd->SendMessageToDescendants(UWM_ON_ROI_CHANGE);

	if(bRestart) StartGrabbing();
}


char *CContImageApp::MakeFileName(int i,char *strFileName){
	if(i<0 || i>MODE_NUMBER){
		char str[64];
		sprintf(str,"MakeFileName: mode=%i out of range (0-%i)\n",i,MODE_NUMBER);
		PrintMessage(LEVEL_ERROR,str,strlen(str)+1);
		return(char*)0;	
	}                                         
	
	sprintf( strFileName, "%01c_%01c%01c%01c.%01c%01c", 
		strModeTag[i],
		NumberToChar(m_sYear%10), NumberToChar(m_sMonth), NumberToChar(m_sDay), 
		NumberToChar(m_sExperimentNumber) , NumberToChar(m_sExperimentRun));
	PrintMessage(strFileName);
	return(strFileName);
}

char *CContImageApp::MakeFileName(){
	return(MakeFileName(m_iMode,m_strBaseFileName));
}
	

void CContImageApp::OnFileNew(){
	char str[128];
	sprintf(str,"CContImageApp::OnFileNew ");
	PrintMessage(str);

	if(m_pROI->m_ROIMain.bRealized){
		PrintMessage(LEVEL_ERROR,"Main ROI has been realized already");
		return;
	}

	m_pROI->m_ROIMain.bHidden=FALSE;

	if(OnROINew()){
		m_bMainROIOpened = TRUE;
		PrintMessage(LEVEL_NORMAL,"Realized Main ROI");
	}
	else{
		m_bMainROIOpened = FALSE;
		PrintMessage(LEVEL_ERROR,"Cannot realize Main ROI");
	}

}

BOOL CContImageApp::OnROINew(){
	char str[128];
	sprintf(str,"CContImageApp::OnROINew ");
	PrintMessage(str);

	if(!m_pROI->GetUnrealizedROI()){
		PrintMessage("Unrealized ROI is not available");
		return(FALSE);
	}

	CContImageDoc *pDoc = (CContImageDoc*) pDocTemplate->CreateNewDocument();
	ASSERT_VALID(pDoc);
	if( pDoc == NULL ) return(FALSE);

	CFrameWnd *pFrameWnd = pDocTemplate->CreateNewFrame( pDoc, NULL );
	ASSERT_VALID(pFrameWnd);
	if( pFrameWnd == NULL ) return(FALSE);

	if(!pDoc->OnNewDocument(m_iDocCount)) return(FALSE);

	m_iDocCount++;

	pDocTemplate->InitialUpdateFrame( pFrameWnd, pDoc);
		
	((CMainFrame*)AfxGetMainWnd())->OnActiveDocuments(m_iDocCount);
	return(TRUE);
}



void CContImageApp::OnFileClose(int iDoc){
	char str[128];
	sprintf(str,"CContImageApp::OnFileClose %i",iDoc);
	PrintMessage(str);	
	if(!iDoc){
		m_bMainROIOpened = FALSE;
		PrintMessage(LEVEL_HIGH,"Closed Main ROI");
	}
	m_iDocCount--;
	if(m_iDocCount) m_pMainWnd->SendMessageToDescendants(UWM_ON_REMOVED_SUB_ROI,(WPARAM)iDoc);
	else{
//		m_pMainWnd->SendMessageToDescendants(UWM_ON_STOP_GRABBING);
		PrintMessage(LEVEL_NORMAL,"CContImageApp::OnFileClose: All windows are dead");
		if(m_bRunningFocus || m_bRunningExperiment){
			m_pFrameServer->StopFrameServer();
			m_bRunningFocus=FALSE;
			m_bRunningExperiment=FALSE;
		}
	}
	((CMainFrame*)AfxGetMainWnd())->OnActiveDocuments(m_iDocCount);
}

void CContImageApp::SetApplicationMode(int iApplicationMode){
	PrintMessage("CContImageApp::SetApplicationMode");
	if(iApplicationMode == -1) iApplicationMode = m_iApplicationMode;
	switch(iApplicationMode){
	case -1:
		break;
	case APPLICATION_MODE_FOCUS:
		if(m_bRunningExperiment){
			PrintMessage(LEVEL_ERROR,"May not change mode to focus while running experiment");
			return;
		}
		if(m_iApplicationMode != iApplicationMode){
			m_iApplicationMode = iApplicationMode;
//			m_iServerDynamicMode=SERVER_DYNAMIC_MODE_ROI;
			m_iServerDynamicMode=m_iFocusDynamicMode;
			if( m_iTemporalBinning != m_iTemporalFocusBinning || 
				m_iSpatialBinningX != m_iSpatialFocusBinningX ||
				m_iSpatialBinningY != m_iSpatialFocusBinningY){
				m_iTemporalBinning = m_iTemporalFocusBinning;
				m_iSpatialBinningX = m_iSpatialFocusBinningX;
				m_iSpatialBinningY = m_iSpatialFocusBinningY;
				m_pMainWnd->SendMessageToDescendants(UWM_ON_SPATIAL_BINNING_CHANGE,
											(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
			}
		}

		m_ulFileHeaderSize = sizeof(FILE_HEADER);
		m_pFileHeaderTemplate = (void*)&(m_MultiChunk.structFileHeader);

		SetFocusMode(m_iFocusMode);
		break;
	case APPLICATION_MODE_EXPERIMENT:
		if(m_bRunningFocus){
			PrintMessage(LEVEL_ERROR,"May not change mode to experiment while running focus");
			return;
		}
		if(m_iApplicationMode != iApplicationMode){
			m_iApplicationMode = iApplicationMode;
			m_iServerDynamicMode=SERVER_DYNAMIC_MODE_EXPERIMENT;
			if( m_iTemporalBinning != m_iTemporalExperimentBinning || 
				m_iSpatialBinningX != m_iSpatialExperimentBinningX ||
				m_iSpatialBinningY != m_iSpatialExperimentBinningY){
				m_iTemporalBinning = m_iTemporalExperimentBinning;
				m_iSpatialBinningX = m_iSpatialExperimentBinningX;
				m_iSpatialBinningY = m_iSpatialExperimentBinningY;
				m_pMainWnd->SendMessageToDescendants(UWM_ON_SPATIAL_BINNING_CHANGE,
											(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
			}
		}
		m_nWaveLength=m_nExperimentWaveLength;
		m_nFilterWidth=m_nExperimentFilterWidth;
		SetExperimentMode(m_iExperimentMode);
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Application Mode");
		m_iApplicationMode = APPLICATION_MODE_NONE;
		m_iServerDynamicMode = SERVER_DYNAMIC_MODE_NONE;
		m_iMode = MODE_NONE;
		return;
	}
	m_pMainWnd->SendMessageToDescendants(UWM_ON_CHANGE_MODES,
										(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
}

void CContImageApp::SetFocusMode(int iFocusMode){
	PrintMessage("  CContImageApp::SetFocusMode");

	if(iFocusMode == -1) iFocusMode = m_iFocusMode;
	switch(iFocusMode){
	case -1:
		break;
	case FOCUS_MODE_GREEN:
		m_iFocusMode = iFocusMode;
		m_iMode = MODE_GREEN;
		m_nWaveLength=m_nFocusWaveLength;
		m_nFilterWidth=m_nFocusFilterWidth;
		break;
	case FOCUS_MODE_EXPOSURE:
		m_iFocusMode = iFocusMode;
		m_iMode = MODE_EXPOSURE;
		m_nWaveLength=m_nExperimentWaveLength;
		m_nFilterWidth=m_nExperimentFilterWidth;
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Focus Mode");
		m_iFocusMode = FOCUS_MODE_NONE;
		m_iMode = MODE_NONE;
		return;
	}
	m_ulFrameHeaderSize = 0;
	m_pFrameHeaderTemplate = NULL;
	m_pfunExperimentCallback = NULL;
	UpdateFileHeader();
}

void CContImageApp::SetExperimentMode(int iExperimentMode){
	PrintMessage("  CContImageApp::SetExperimentMode");

	if(iExperimentMode == -1) iExperimentMode = m_iExperimentMode;
	switch(iExperimentMode){
	case -1:
		break;
	case EXPERIMENT_MODE_SUM:
		m_iExperimentMode = iExperimentMode;
		SetExperimentSumMode(m_iExperimentSumMode);
		break;
	case EXPERIMENT_MODE_CONTINUOUS:
		m_iExperimentMode = iExperimentMode;
		SetExperimentContinuousMode(m_iExperimentContinuousMode);
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Experiment Mode");
		m_iExperimentMode = EXPERIMENT_MODE_NONE;
		m_iMode = MODE_NONE;
		return;
	}
}

void CContImageApp::SetExperimentSumMode(int iExperimentSumMode){
	PrintMessage("    CContImageApp::SetExperimentSumMode");
	if(iExperimentSumMode == -1) iExperimentSumMode = m_iExperimentSumMode;
	switch(iExperimentSumMode){
	case -1:
		break;
	case EXPERIMENT_SUM_MODE_SUM:
		m_iExperimentSumMode = iExperimentSumMode;
		m_iMode = MODE_SUM;

		m_ulFileHeaderSize = 0;
		m_pFileHeaderTemplate = NULL;
		m_ulFrameHeaderSize = 0;
		m_pFrameHeaderTemplate = NULL;
		m_pfunExperimentCallback = NULL;
		m_pExperimentControl = NULL;
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Experiment Sum Mode");
		m_iExperimentSumMode = EXPERIMENT_SUM_MODE_NONE;
		m_iMode = MODE_NONE;

		m_ulFileHeaderSize = 0;
		m_pFileHeaderTemplate = NULL;
		m_ulFrameHeaderSize = 0;
		m_pFrameHeaderTemplate = NULL;
		m_pfunExperimentCallback = NULL;
		m_pExperimentControl = NULL;
		return;
	}
	UpdateFileHeader();
}

void CContImageApp::SetExperimentContinuousMode(int iExperimentContinuousMode){
	UINT i;
	PrintMessage("    CContImageApp::SetExperimentContinuousMode");
	if(iExperimentContinuousMode == -1) iExperimentContinuousMode = m_iExperimentContinuousMode;
	switch(iExperimentContinuousMode){
	case -1:
		break;
	case EXPERIMENT_CONTINUOUS_MODE_CONTINUOUS:
		m_iExperimentContinuousMode = iExperimentContinuousMode;
		m_iMode = MODE_CONTINUOUS;

		m_ulFileHeaderSize = sizeof(FILE_COST_HEADER);
		m_pFileHeaderTemplate = (void*)&(m_MultiChunk.structCOSTFileHeader);
		m_ulFrameHeaderSize = sizeof(FRAM_COST_HEADER);
		m_pFrameHeaderTemplate = (void*)&(m_MultiChunk.structCOSTFrameHeader);
		m_pfunExperimentCallback = COSTExperimentCallback;

		m_EPSTControl.pbPause = &m_bExperimentPaused;
		m_COSTControl.pSynchInOut = (void*)&(m_pSynch->m_SynchInOut);
		m_pExperimentControl = (void*)&(m_COSTControl);

		break;
	case EXPERIMENT_CONTINUOUS_MODE_EPISODIC:
		m_iExperimentContinuousMode = iExperimentContinuousMode;
		m_iMode = MODE_CONTINUOUS;

		m_ulFileHeaderSize = sizeof(FILE_EPST_HEADER);
		m_pFileHeaderTemplate = (void*)&(m_MultiChunk.structEPSTFileHeader);
		m_ulFrameHeaderSize = sizeof(FRAM_EPST_HEADER);
		m_pFrameHeaderTemplate = (void*)&(m_MultiChunk.structEPSTFrameHeader);
		m_pfunExperimentCallback = EPSTExperimentCallback;

		if(!(m_piConditionList=(int*)realloc(m_piConditionList,sizeof(int)*m_nNConditions))){
			PrintMessage(LEVEL_ERROR,"Cannot allocate for m_piConditionList");
			m_pExperimentControl = NULL;
			return;
		}
		for(i=0;i<m_nNConditions;i++) m_piConditionList[i]=i;

		m_EPSTControl.pbPause = &m_bExperimentPaused;
		m_EPSTControl.pSynchInOut = (void*)&(m_pSynch->m_SynchInOut);
		m_EPSTControl.ulNConditions = m_nNConditions;
		m_EPSTControl.ulNRepetitions = m_nNRepetitions;
		m_EPSTControl.ulRandomize = m_bRandomize;
		m_EPSTControl.ulNFramesITI = m_nNFramesITI;
		m_EPSTControl.ulNFramesStim = m_nNFramesStim;
		m_EPSTControl.ulNFramesBlankPre = m_nNFramesBlankPre;
		m_EPSTControl.ulNFramesBlankPost = m_nNFramesBlankPost;
		m_EPSTControl.piConditionList = m_piConditionList;
		m_EPSTControl.ulTemporalBinning = m_iTemporalExperimentBinning;
		m_pExperimentControl = (void*)&(m_EPSTControl);

		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown Experiment Continuous Mode");
		m_iExperimentContinuousMode = EXPERIMENT_CONTINUOUS_MODE_NONE;
		m_iMode = MODE_NONE;

		m_ulFileHeaderSize = 0;
		m_pFileHeaderTemplate = NULL;
		m_ulFrameHeaderSize = 0;
		m_pFrameHeaderTemplate = NULL;
		m_pfunExperimentCallback = NULL;
		m_pExperimentControl = NULL;
		return;
	}
	UpdateFileHeader();
}


void CContImageApp::SetSubModesFromMode(){
	PrintMessage("CContImageApp::SetSubModesFromMode");
	switch(m_iMode){
	case MODE_NONE:
		break;
	case MODE_GREEN:
		m_iApplicationMode=APPLICATION_MODE_FOCUS;
		m_iFocusMode=MODE_GREEN;
		m_iFocusDynamicMode=m_iServerDynamicMode=SERVER_DYNAMIC_MODE_ROI;
		break;
	case MODE_EXPOSURE:
		m_iApplicationMode=APPLICATION_MODE_FOCUS;
		m_iFocusMode=MODE_EXPOSURE;
		m_iFocusDynamicMode=m_iServerDynamicMode=SERVER_DYNAMIC_MODE_ROI;
		break;
	case MODE_SUM:
		m_iApplicationMode=APPLICATION_MODE_EXPERIMENT;
		m_iExperimentMode=EXPERIMENT_MODE_SUM;
		m_iServerDynamicMode=SERVER_DYNAMIC_MODE_EXPERIMENT;
		break;
	case MODE_CONTINUOUS:
		m_iApplicationMode=APPLICATION_MODE_EXPERIMENT;
		m_iExperimentMode=EXPERIMENT_MODE_CONTINUOUS;
		m_iExperimentContinuousMode=EXPERIMENT_CONTINUOUS_MODE_CONTINUOUS;
		m_iServerDynamicMode=SERVER_DYNAMIC_MODE_EXPERIMENT;
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown mode");
	}
	m_pMainWnd->SendMessageToDescendants(UWM_ON_CHANGE_MODES,
										(WPARAM)m_iServerDynamicMode,(LPARAM)m_iApplicationMode);
}

void CContImageApp::UpdateFileHeader(){
	PrintMessage("CContImageApp::UpdateFileHeader");
	int i;
	time_t ltime;
	time(&ltime);

   	MakeFileName();


	// Update HARD Chunk
	HARD_CHUNK	*pHARDChunk = m_MultiChunk.CChunk<HARD_CHUNK>::m_pChunk;

	strncpy(pHARDChunk->Tag,"0000",4);									//01 01
	strncpy(pHARDChunk->CameraName,"SMD 1M30",16);						//02 05 
	pHARDChunk->CameraType = m_pFrameServer->m_bCameraType;				//03 06 
	pHARDChunk->ResolutionX = 1024;										//04 07 Physical X resolution of CCD chip  
	pHARDChunk->ResolutionY = 1024;										//05 08 Physical Y resolution of CCD chip 
	pHARDChunk->PixelSizeX = 12;										//06 09 micrometers
	pHARDChunk->PixelSizeY = 12;										//07 10 micrometers
	pHARDChunk->CCDApertureX = 12300;									//08 11 micrometers
	pHARDChunk->CCDApertureY = 12300;									//09 12 micrometers
	pHARDChunk->IntegrationTime = m_pFrameServer->m_dwIntegrationTimeUsec;//10 13 microseconds
	pHARDChunk->InterFrameTime = m_pFrameServer->m_dwInterFrameTimeUsec;//11 14 microseconds
	pHARDChunk->HardwareBinningV = m_pFrameServer->m_dwHardwareBinningV;//12 15 Vertical   or X binning
	pHARDChunk->HardwareBinningH = m_pFrameServer->m_dwHardwareBinningH;//13 16 Horizontal or Y binning
	pHARDChunk->HardwareGain = m_pFrameServer->m_dwVideoGain;			//14 17
	pHARDChunk->HardwareOffset = m_pFrameServer->m_lPixelOffset;		//15 18
	pHARDChunk->CCDSizeX = m_pFrameServer->m_dwResolutionX;				//16 19 X size after HW binning
	pHARDChunk->CCDSizeY = m_pFrameServer->m_dwResolutionY;				//17 20 Y size after HW binning 
	pHARDChunk->DynamicRange = 3200;									//18 21
	pHARDChunk->OpticsFocalLengthTop = m_nOpticsFocalLengthTop;			//19 22 Top lens focal lenght (the one closer to the camera), millimeters
	pHARDChunk->OpticsFocalLengthBottom = m_nOpticsFocalLengthBottom;	//20 23 Bottom lens focal lenght, millimeters
	strncpy(pHARDChunk->Comments,(LPCTSTR)m_strComments,sizeof(pHARDChunk->Comments));//21 64



	// Update SOFT Chunk
	SOFT_CHUNK	*pSOFTChunk = m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk;

	strncpy(pSOFTChunk->Tag,m_strBaseFileName,4);			//01 01
	strncpy(pSOFTChunk->DateTimeRecorded,ctime(&ltime),24);	//02 07 ASCII UNIX time
	strncpy(pSOFTChunk->UserName,(LPCTSTR)m_strUserName,16);//03 11 ASCII 
	strncpy(pSOFTChunk->SubjectID,(LPCTSTR)m_strSubjectID,16);//04 15 ASCII 
	strncpy(pSOFTChunk->ThisFilename,m_strBaseFileName,16);	//05 19 // Modified by views and writing routines
//	pSOFTChunk->PrevFilename[16];							//06 23 // Set by writing routines
//	pSOFTChunk->NextFilename[16];							//07 27 // Set by writing routines
	pSOFTChunk->DataType = m_iDataType;						//08 28
	pSOFTChunk->FileType = m_iFileType;						//09 29
	pSOFTChunk->SizeOfDataType = DataTypeToSizeOf(m_iDataType);//10 30
//	pSOFTChunk->XSize;										//11 31 X size of stored frames 
//	pSOFTChunk->YSize;										//12 32 Y size of stored frames
//	pSOFTChunk->ROIXPosition;								//13 33 X coordinate of upper-left conner of ROI (before binning)
//	pSOFTChunk->ROIYPosition;								//14 34 Y coordinate of upper-left conner of ROI (before binning)
//	pSOFTChunk->ROIXSize;									//15 35 X size of ROI (before binning) 
//	pSOFTChunk->ROIYSize;									//16 36 Y size of ROI (before binning) 
//	pSOFTChunk->ROIXPositionAdjusted;						//17 37 X coordinate of upper-left conner of adjusted ROI (before binning)
//	pSOFTChunk->ROIYPositionAdjusted;						//18 38 Y coordinate of upper-left conner of adjusted ROI (before binning)
//	pSOFTChunk->ROINumber;									//19 39 Sequential ROI number. Set to 0 for main ROI
	pSOFTChunk->TemporalBinning = m_iTemporalBinning;		//20 40
	pSOFTChunk->SpatialBinningX = m_iSpatialBinningX;		//21 41 X
	pSOFTChunk->SpatialBinningY = m_iSpatialBinningY;		//22 42 Y
	pSOFTChunk->FrameHeaderSize = m_ulFrameHeaderSize;		//23 43 Size of the header for each frame 
	pSOFTChunk->NFramesTotal = m_nNFrames/m_iTemporalBinning;//24 44 Expected number of frames(can be modified by writing routines)
	pSOFTChunk->NFramesThisFile = 1;						//25 45 Number of frames in this file // Set by writing routines
	pSOFTChunk->WaveLength = m_nWaveLength;					//26 46 Wave lenght, nanometers
	pSOFTChunk->FilterWidth = m_nFilterWidth;				//27 47 Filter width, nanometers
	strncpy(pSOFTChunk->Comments,(LPCTSTR)m_strComments,sizeof(pSOFTChunk->Comments));//28 64

	// Update COST Chunk
	COST_CHUNK	*pCOSTChunk = m_MultiChunk.CChunk<COST_CHUNK>::m_pChunk;
	
	strncpy(pCOSTChunk->Tag,"0000",4);		//01 01 Irrelevant for now
	pCOSTChunk->NSynchChannels = m_pSynch->m_SynchInOut.iNumChannelsIn;	//02 02 Up to 4 channels. Add new MAX values bellow if needed or use SYNC_CHUNK

	for(i=0;i<(int)pCOSTChunk->NSynchChannels;i++) pCOSTChunk->SynchChannelMax[i] = m_pSynch->m_SynchInOut.pulMaxValueIn[i];
	for(i=pCOSTChunk->NSynchChannels;i<4;i++) pCOSTChunk->SynchChannelMax[i] = 0;

	pCOSTChunk->NStimulusChanels = 1;		//07 07 Used if no Sync Channels present
	pCOSTChunk->StimulusPeriod[0] = (ULONG)(m_dStimulationPeriod*1000.0);//08 08 milliseconds
	pCOSTChunk->StimulusPeriod[1] = 0;		//09 09 milliseconds
	pCOSTChunk->StimulusPeriod[2] = 0;		//10 10 milliseconds
	pCOSTChunk->StimulusPeriod[3] = 0;		//11 11 milliseconds
//	pCOSTChunk->Comments[20];				//12 16

	// Update EPST Chunk
	EPST_CHUNK	*pEPSTChunk = m_MultiChunk.CChunk<EPST_CHUNK>::m_pChunk;

	strncpy(pEPSTChunk->Tag,"0000",4);								//01 01
	pEPSTChunk->NConditions = m_nNConditions;						//02 02 Number of conditions (for episodic stimuli)
	pEPSTChunk->NRepetitions = m_nNRepetitions;						//03 03 Number of repetitions (for episodic stimuli)
	pEPSTChunk->Randomize = m_bRandomize;							//04 04 (for episodic stimuli)
	pEPSTChunk->NFramesITI = m_nNFramesITI/m_iTemporalBinning;		//05 05 (for episodic stimuli)
	pEPSTChunk->NFramesStim = m_nNFramesStim/m_iTemporalBinning;	//06 06 (for episodic stimuli)
	pEPSTChunk->NFramesBlankPre = m_nNFramesBlankPre/m_iTemporalBinning;	//07 07 Pre-stimulus frames (for episodic stimuli)
	pEPSTChunk->NFramesBlankPost = m_nNFramesBlankPost/m_iTemporalBinning;	//08 08 Post-stimulus frames (for episodic stimuli)
//	pEPSTChunk->Comments[32];										//07 16

	char str[128];
	sprintf(str,"MAIN Cond %lu Rep %lu",pEPSTChunk->NConditions,pEPSTChunk->NRepetitions);
	PrintMessage(str);

	// Update GREE Chunk
	GREE_CHUNK	*pGREEChunk = m_MultiChunk.CChunk<GREE_CHUNK>::m_pChunk;

	strncpy(pGREEChunk->Tag,"0000",4);			//01 01
	pGREEChunk->LoClip = 0;						//02 02
	pGREEChunk->HiClip = 0;						//03 03
	pGREEChunk->LoPass = 0;						//04 04
	pGREEChunk->HiPass = 0;   					//05 05
//	pGREEChunk->Comments[12];					//06 08


	// Update ROIS Chunk
	ROIS_CHUNK	*pROISChunk = m_MultiChunk.CChunk<ROIS_CHUNK>::m_pChunk;

	pROISChunk->RecordSize = sizeof(ROISRecord);
	pROISChunk->RecordCount = m_pROI->GetCount()-1;

	// Update FILE Headers

	memcpy(&(m_MultiChunk.structFileHeader.SOFTChunk),pSOFTChunk,sizeof(SOFT_CHUNK));
	memcpy(&(m_MultiChunk.structFileHeader.HARDChunk),pHARDChunk,sizeof(HARD_CHUNK));

	memcpy(&(m_MultiChunk.structCOSTFileHeader.SOFTChunk),pSOFTChunk,sizeof(SOFT_CHUNK));
	memcpy(&(m_MultiChunk.structCOSTFileHeader.HARDChunk),pHARDChunk,sizeof(HARD_CHUNK));
	memcpy(&(m_MultiChunk.structCOSTFileHeader.COSTChunk),pCOSTChunk,sizeof(COST_CHUNK));

	memcpy(&(m_MultiChunk.structEPSTFileHeader.SOFTChunk),pSOFTChunk,sizeof(SOFT_CHUNK));
	memcpy(&(m_MultiChunk.structEPSTFileHeader.HARDChunk),pHARDChunk,sizeof(HARD_CHUNK));
	memcpy(&(m_MultiChunk.structEPSTFileHeader.EPSTChunk),pEPSTChunk,sizeof(EPST_CHUNK));

}

int CContImageApp::PrepareForNextExperiment(){
	PrintMessage("CContImageApp::PrepareForNextExperiment");
	m_sExperimentRun++;
	if(m_sExperimentRun==FILENAME_SCHEME_MAX){
		m_sExperimentRun=0;
		m_sExperimentNumber++;
		if(m_sExperimentNumber==FILENAME_SCHEME_MAX){
			PrintMessage(LEVEL_ERROR,"PFN: Double naming scheme failure");
			return(1);
		}
	}
	UpdateFileHeader();
	return(0);
}


void CContImageApp::OnAcquireCamZoomCaps(){
#ifndef _DEBUG_NO_CAMERA

	char str[128];
	ZOOMCAP zoomCaps;
	m_pFrameServer->m_pCamera->GetZoomCaps(&zoomCaps);
	PrintMessage("Camera Zoom Caps");
	sprintf(str,"Zoom X: Min=%f Max=%f Step=%f",zoomCaps.minXZoom,zoomCaps.maxXZoom,zoomCaps.stepSizeX);
	PrintMessage(str);
	sprintf(str,"Zoom Y: Min=%f Max=%f Step=%f",zoomCaps.minYZoom,zoomCaps.maxYZoom,zoomCaps.stepSizeY);
	PrintMessage(str);

#endif

}

void CContImageApp::OnAcquireCamAttr(){
#ifndef _DEBUG_NO_CAMERA

	char str[128];
	m_pFrameServer->GetCameraAttributes();
	PrintMessage("Camera Acquisition Parameters");
	sprintf(str,"Pixel Height(X)=%u Width(Y)=%u",m_pFrameServer->m_CameraAttributes.dwWidth,m_pFrameServer->m_CameraAttributes.dwHeight);
	PrintMessage(str);	
	sprintf(str,"Per Pixel: Bytes=%u Bits=%u",m_pFrameServer->m_CameraAttributes.dwBytesPerPixel,m_pFrameServer->m_CameraAttributes.dwBitsPerPixel);
	PrintMessage(str);
	sprintf(str,"IFC_COLOR=%i (IFC_MONO=%i)",m_pFrameServer->m_CameraAttributes.color,IFC_MONO);
	PrintMessage(str);
	sprintf(str,"Zoom: X=%f Y=%f",m_pFrameServer->m_CameraAttributes.xZoom,m_pFrameServer->m_CameraAttributes.yZoom);
	PrintMessage(str);
	sprintf(str,"Camera Name: %s",m_pFrameServer->m_CameraAttributes.camName);
	PrintMessage(str);
#endif
}

void CContImageApp::OnAcquireMiscBrodcastMsg(){
	m_pMainWnd->SendMessageToDescendants(UWM_ON_ROI_CHANGE);
}


void CContImageApp::OnAcquireMiscSerialPortSettings(){
	if(!m_pFrameServer->m_pCOMPort->m_bCOMPortReady){
		PrintMessage(LEVEL_ERROR,"Serial port is not ready");
		PrintMessage(LEVEL_ERROR,"Make sure you connected to right COM port");
		return;
	}
}

void CContImageApp::OnAcquireMiscHardwareSettings(){
	char str[128];
	BYTE b;
	b=m_pFrameServer->GetCameraType();
	if(b == (BYTE)SMD_M30_CAMERA_TYPE){
		sprintf(str,"Connencted to SMD 1M30 CCD Camera %#x",b);
		PrintMessage(LEVEL_NORMAL,str);
	}
	else{
		sprintf(str,"Connencted to unknown device %#x",b);
		PrintMessage(LEVEL_NORMAL,str);
	}
	sprintf(str,"Control Register %#x",m_pFrameServer->GetControlRegister());
	PrintMessage(LEVEL_NORMAL,str);
	sprintf(str,"Firmware Revision %#x",m_pFrameServer->GetFirmwareRevision());
	PrintMessage(LEVEL_NORMAL,str);
	sprintf(str,"Gain %#x",m_pFrameServer->GetUserGain());
	PrintMessage(LEVEL_NORMAL,str);
	sprintf(str,"Offset %#x",m_pFrameServer->GetUserOffset());
	PrintMessage(LEVEL_NORMAL,str);
	sprintf(str,"Frames In Buffer %lu",m_pFrameServer->m_dwNFramesRingBuffer);
	PrintMessage(LEVEL_NORMAL,str);
//	sprintf(str,"Frame Dimensions X %lu Y %lu",m_pFrameServer->m_dwResolutionX,m_pFrameServer->m_dwResolutionY);
//	PrintMessage(LEVEL_NORMAL,str);
}

void CContImageApp::OnAcquireCamSoftReset(){
	m_pFrameServer->ResetADCBoard();
}

void CContImageApp::OnAcquireCamHardReset(){
	m_pFrameServer->ResetCamera();	
}

void CContImageApp::OnAcquireMiscTest(){
	char str[128];
	strncpy(str,m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->DateTimeRecorded,24);
	str[24]='\0';
	PrintMessage(str);
	PrintMessage(m_MultiChunk.CChunk<HARD_CHUNK>::m_pChunk->Comments);

}

void CContImageApp::OnFileOpen(){
	CFileDialog	dlg(TRUE);
	if(dlg.DoModal() != IDOK) return;

	char str[384];
	char strFileName[128];
	char strFullFileName[256];
	FILE *fp;
	struct _stat structFileStat;
	BOOL bCorruptedFile=TRUE;
	ULONG nFileSizeBytes,nSkipBytes,nReadBytes;
	CChunk<ISOI_CHUNK>* pISOIChunk = new CChunk<ISOI_CHUNK>("ISOI");
	CChunk<DATA_CHUNK>* pDATAChunk = new CChunk<DATA_CHUNK>("DATA");
	CChunk<HARD_CHUNK>* pHARDChunk = new CChunk<HARD_CHUNK>("HARD");
	CChunk<SOFT_CHUNK>* pSOFTChunk = new CChunk<SOFT_CHUNK>("SOFT");
	BOOL bFoundSOFT=FALSE;
	char strID[5]={"\0\0\0\0"},strTag[5]={"\0\0\0\0"};
	BYTE *pbTmpBuffer=NULL,*pbTmpConvertedBuffer=NULL;
	ULONG ulTmpBufferSizeBytes=0,ulTmpConvertedBufferSizeBytes=0,ulTmpBufferSizeRecords=0;
	ULONG nTotalBinning,nDivisor;
	ROISRecord structROI;
	
	strncpy(strFileName,(LPCTSTR)(dlg.GetFileName()),128);
	strncpy(strFullFileName,(LPCTSTR)(dlg.GetPathName()),256);
	PrintMessage(strFileName);
	PrintMessage(strFullFileName);
	if(_stat(strFullFileName, &structFileStat)){
		sprintf(str,"Cannot _stat file %s ",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}
	nFileSizeBytes=structFileStat.st_size;

	if(!(fp=fopen(strFullFileName,"rb"))){
		sprintf(str,"Cannot open file %s ",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}

	nReadBytes=0;
	pISOIChunk->ClearChunk();
	if(!pISOIChunk->ReadChunk(fp,nReadBytes)) goto bailout;
	strncpy(strID,pISOIChunk->m_pChunk->ID,4);
	nSkipBytes=pISOIChunk->m_pChunk->Size;
	strncpy(strTag,pISOIChunk->m_pChunk->Tag,4);

	if(pISOIChunk->HasMyName()){
		if(nSkipBytes+8 == nFileSizeBytes) bCorruptedFile=FALSE;
		else PrintMessage(LEVEL_WARNING,"File is Corrupted");
		
		sprintf(str,"File %s is ISOI file",strFullFileName);
		PrintMessage(str);
		sprintf(str,"Tag=%s Size=%u(%ld)",strTag,nSkipBytes+8,nFileSizeBytes);
		PrintMessage(str);
	}
	else{
		sprintf(str,"File %s is not ISOI file",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}

	while((nFileSizeBytes != nReadBytes) && pDATAChunk->ReadChunk(fp,nReadBytes)){
		strncpy(strID,pDATAChunk->m_pChunk->ID,4);

		if(!memcmp("HARD",strID,4)){
			if(!pHARDChunk->ReadRestOfChunk(fp,nReadBytes)) goto bailout;
			pHARDChunk->PrintNameAndTag();
			if(!SetHardwareFromChunk(pHARDChunk->m_pChunk)){
				PrintMessage("CContImageApp::OnFileOpen: Cannot reset hardware");
				goto bailout;
			}
			m_pFrameServer->ResetHardware();
			m_pROI->RescaleAllROI(m_pFrameServer->m_dwResolutionX,m_pFrameServer->m_dwResolutionY);

			continue;
		}

		if(!memcmp("SOFT",strID,4)){
			if(!pSOFTChunk->ReadRestOfChunk(fp,nReadBytes)) goto bailout;
			pSOFTChunk->PrintNameAndTag();
			if(!SetSoftwareFromChunk(pSOFTChunk->m_pChunk)){
				PrintMessage("CContImageApp::OnFileOpen: Cannot reset software");
				goto bailout;
			}
			bFoundSOFT=TRUE;
			continue;
		}

		if(!memcmp("ROIS",strID,4)){
			CChunk<ROIS_CHUNK>* pROISChunk = new CChunk<ROIS_CHUNK>("ROIS");
			if(!pROISChunk->ReadRestOfChunk(fp,nReadBytes)) goto bailout;
			pROISChunk->PrintNameAndTag();
			if(!pDATAChunk->ReadChunk(fp,nReadBytes)) goto bailout;
			if(pDATAChunk->m_pChunk->Size != pROISChunk->m_pChunk->RecordCount*sizeof(ROISRecord)){
				PrintMessage(LEVEL_ERROR,"Invalid ROI DATA Chunk size");
				goto bailout;
			}
			ROISRecord structROISRecord;
			for(ULONG i=0;i<pROISChunk->m_pChunk->RecordCount;i++){
				if(fread(&(structROISRecord),sizeof(ROISRecord),1,fp)!=1){
					PrintMessage(LEVEL_ERROR,"Cannot read ROIS record");
					delete pROISChunk;
					goto bailout;
				}
				nReadBytes+=sizeof(ROISRecord);
				CRect *r = new CRect(structROISRecord.left,structROISRecord.top,
									 structROISRecord.right,structROISRecord.bottom);
				m_pROI->AddROI(r,structROISRecord.iNumber != 0 ? structROISRecord.iNumber : i+1);
				OnROINew();
				PrintMessage(*r);
			}
			delete pROISChunk;
			continue;
		}

		if(!memcmp("DATA",strID,4)){
			PrintMessage(strID);
			if(!bFoundSOFT) continue;
			ulTmpBufferSizeRecords = pSOFTChunk->m_pChunk->XSize*pSOFTChunk->m_pChunk->YSize;
			ulTmpBufferSizeBytes = ulTmpBufferSizeRecords*pSOFTChunk->m_pChunk->SizeOfDataType;

			if(m_iApplicationMode==APPLICATION_MODE_EXPERIMENT){
				if(!((nFileSizeBytes != nReadBytes) && pDATAChunk->ReadChunk(fp,nReadBytes))){
					PrintMessage(LEVEL_ERROR,"Unexpected end of file");
					goto bailout;		
				}

				if(memcmp("FRAM",pDATAChunk->m_pChunk->ID,4)) goto skipchunk;

				CChunk<FRAM_CHUNK>* pFRAMChunk = new CChunk<FRAM_CHUNK>("FRAM");
				if(!pFRAMChunk->ReadRestOfChunk(fp,nReadBytes)){
					delete pFRAMChunk;
					goto bailout;
				}
				pFRAMChunk->PrintNameAndTag();
				delete pFRAMChunk;

				if(!((nFileSizeBytes != nReadBytes) && pDATAChunk->ReadChunk(fp,nReadBytes))){
					PrintMessage(LEVEL_ERROR,"Unexpected end of file");
					goto bailout;		
				}

				if(memcmp("cost",pDATAChunk->m_pChunk->ID,4) && memcmp("epst",pDATAChunk->m_pChunk->ID,4)) goto skipchunk;
				if(!memcmp("cost",pDATAChunk->m_pChunk->ID,4)){
					CChunk<FRAM_COST_CHUNK>* pcostChunk = new CChunk<FRAM_COST_CHUNK>("cost");
					if(!pcostChunk->ReadRestOfChunk(fp,nReadBytes)){
						delete pcostChunk;
						goto bailout;
					}
					pcostChunk->PrintNameAndTag();
					if(pDATAChunk->m_pChunk->Size-(sizeof(FRAM_COST_CHUNK)-8) != ulTmpBufferSizeBytes){
						sprintf(str,"Invalide cost Chunk size: is %lu expected %lu",
												pDATAChunk->m_pChunk->Size,ulTmpBufferSizeBytes+sizeof(FRAM_COST_CHUNK)-8);
						PrintMessage(LEVEL_ERROR,str);
						delete pcostChunk;
						goto bailout;
					}
					delete pcostChunk;
				}
			}
			else{
				if(pDATAChunk->m_pChunk->Size != ulTmpBufferSizeBytes){
					sprintf(str,"Invalide Main DATA Chunk size: is %lu expected %lu",
																pDATAChunk->m_pChunk->Size,ulTmpBufferSizeBytes);
					PrintMessage(LEVEL_ERROR,str);
					goto bailout;
				}
			}

			if(!(pbTmpBuffer=(BYTE*)malloc(ulTmpBufferSizeBytes))){
				PrintMessage(LEVEL_ERROR,"Cannot allocate for Main DATA data");
				goto bailout;		
			}

			ulTmpConvertedBufferSizeBytes = ulTmpBufferSizeRecords*sizeof(ULONG);
			if(!(pbTmpConvertedBuffer=(BYTE*)malloc(ulTmpConvertedBufferSizeBytes))){
				PrintMessage(LEVEL_ERROR,"Cannot allocate for converted Main DATA data");
				goto bailout;		
			}
			if(fread(pbTmpBuffer,ulTmpBufferSizeBytes,1,fp)!=1){
				PrintMessage(LEVEL_ERROR,"Cannot read DATA data");
				goto bailout;
			}
			nReadBytes+=ulTmpBufferSizeBytes;

			nTotalBinning = pSOFTChunk->m_pChunk->TemporalBinning*
							pSOFTChunk->m_pChunk->SpatialBinningX*
							pSOFTChunk->m_pChunk->SpatialBinningY;

			ULONG *pulDest=(ULONG*)pbTmpConvertedBuffer,i;

			switch(pSOFTChunk->m_pChunk->DataType){
			case DATATYPE_UCHAR:
				unsigned char*	pucSrc;
				nDivisor=nTotalBinning*256;
				for(i=0,pucSrc=(unsigned char*)pbTmpBuffer;i<ulTmpBufferSizeRecords;i++,pucSrc++,pulDest++)
					*pulDest=(ULONG)(*pucSrc)*nDivisor;
				break;
			case DATATYPE_USHORT:
				USHORT*	pusSrc;
				nDivisor=nTotalBinning > 16 ? nTotalBinning : 16;
				for(i=0,pusSrc=(USHORT*)pbTmpBuffer;i<ulTmpBufferSizeRecords;i++,pusSrc++,pulDest++)
					*pulDest=(ULONG)(*pusSrc)*nDivisor;
				break;
			case DATATYPE_ULONG:
				ULONG*	pulSrc;
				for(i=0,pulSrc=(ULONG*)pbTmpBuffer;i<ulTmpBufferSizeRecords;i++,pulSrc++,pulDest++)
					*pulDest = (*pulSrc)<<4;
				break;
			case DATATYPE_FLOAT:
				FLOAT*	pfSrc;
				for(i=0,pfSrc=(FLOAT*)pbTmpBuffer;i<ulTmpBufferSizeRecords;i++,pfSrc++,pulDest++)
					*pulDest=(ULONG)((*pfSrc)*16.0);
				break;
			default:
				sprintf(str,"CContImageView::OnSaveGreen: Unknown data type %u",pSOFTChunk->m_pChunk->DataType);
				PrintMessage(LEVEL_ERROR,str);
				goto bailout;
			}
			free(pbTmpBuffer);

/*
			structROI.iNumber=pSOFTChunk->m_pChunk->ROINumber;
			structROI.left=pSOFTChunk->m_pChunk->ROIXPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningX;
			structROI.top=pSOFTChunk->m_pChunk->ROIYPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningY;
			structROI.right=pSOFTChunk->m_pChunk->ROIXPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningX+pSOFTChunk->m_pChunk->XSize-1;
			structROI.bottom=pSOFTChunk->m_pChunk->ROIYPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningY+pSOFTChunk->m_pChunk->YSize-1;

			m_pMainWnd->SendMessageToDescendants(UWM_ON_FILL_STORAGE_BUFFER,(WPARAM)(&structROI), (LPARAM)pbTmpConvertedBuffer);
*/
			continue;
		}

skipchunk:

		PrintMessage(strID);
		nSkipBytes=pDATAChunk->m_pChunk->Size;
		nReadBytes+=nSkipBytes;

		if(fseek(fp, nSkipBytes, SEEK_CUR)){
			sprintf(str,"Fseek failed on %s ",strFullFileName);
			PrintMessage(LEVEL_ERROR,str);
			goto bailout;
		}
	}

//			m_pMainWnd->SendMessageToDescendants(UWM_ON_ROI_CHANGE);

			structROI.iNumber=pSOFTChunk->m_pChunk->ROINumber;
			structROI.left=pSOFTChunk->m_pChunk->ROIXPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningX;
			structROI.top=pSOFTChunk->m_pChunk->ROIYPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningY;
			structROI.right=pSOFTChunk->m_pChunk->ROIXPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningX+pSOFTChunk->m_pChunk->XSize-1;
			structROI.bottom=pSOFTChunk->m_pChunk->ROIYPositionAdjusted/pSOFTChunk->m_pChunk->SpatialBinningY+pSOFTChunk->m_pChunk->YSize-1;

			m_pMainWnd->SendMessageToDescendants(UWM_ON_FILL_STORAGE_BUFFER,(WPARAM)(&structROI), (LPARAM)pbTmpConvertedBuffer);

//			m_pMainWnd->SendMessageToDescendants(WM_PAINT);

bailout:
	if(nFileSizeBytes == nReadBytes){
		sprintf(str,"File size = Bytes read = %i",nFileSizeBytes);
		PrintMessage(LEVEL_NORMAL,str);
	}
	else{
		sprintf(str,"File size %i Read bytes %i",nFileSizeBytes, nReadBytes);
		PrintMessage(LEVEL_ERROR,str);
	}
	if(pbTmpConvertedBuffer) free(pbTmpConvertedBuffer);
	if(fp) fclose(fp);	
	delete pSOFTChunk;
	delete pHARDChunk;
	delete pDATAChunk;
	delete pISOIChunk;
}

BOOL CContImageApp::SetHardwareFromChunk(HARD_CHUNK *pChunk){
	m_pFrameServer->m_bCameraType=(BYTE)pChunk->CameraType;
	m_pFrameServer->m_dwIntegrationTimeUsec=pChunk->IntegrationTime;
	m_pFrameServer->m_dwInterFrameTimeUsec=pChunk->InterFrameTime;
	m_pFrameServer->m_dwHardwareBinningV=pChunk->HardwareBinningV;
	m_pFrameServer->m_dwHardwareBinningH=pChunk->HardwareBinningH;
	m_pFrameServer->m_dwVideoGain=pChunk->HardwareGain;
	m_pFrameServer->m_dwResolutionX=pChunk->CCDSizeX;
	m_pFrameServer->m_lPixelOffset=pChunk->HardwareOffset;
	m_pFrameServer->m_dwResolutionY=pChunk->CCDSizeY;
	m_nOpticsFocalLengthTop=pChunk->OpticsFocalLengthTop;
	m_nOpticsFocalLengthBottom=pChunk->OpticsFocalLengthBottom;
	m_strComments=pChunk->Comments;
	return(TRUE);
}

BOOL CContImageApp::SetSoftwareFromChunk(SOFT_CHUNK *pChunk){
	char str[32];
	char strPrint[256];

//	strncpy(m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->ThisFilename,m_strBaseFileName,16);	//05 19 Encoded in MakeFileName // should be modified in writing routines
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->PrevFilename[16];								//06 23
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->NextFilename[16];								//07 27
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->XSize;											//11 31 X size of stored frames 
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->YSize;											//12 32 Y size of stored frames
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->ROIXPositionAdjusted;							//17 37 X coordinate of upper-left conner of adjusted ROI (before binning)
//	m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk->ROIYPositionAdjusted;							//18 38 Y coordinate of upper-left conner of adjusted ROI (before binning)

	strncpy(str,pChunk->Tag,4);
	str[4]='\0';
	for(int i=0;i<MODE_NUMBER;i++) if(strModeTag[i] == *str) break;
	if(i == MODE_NUMBER){
		sprintf(strPrint,"Unknownn tag %s",str);
		PrintMessage(LEVEL_ERROR,strPrint);
		return(FALSE);
	}
	if(m_iMode!=i){
		m_iMode=i;
		if(m_iMode==MODE_GREEN || m_iMode==MODE_EXPOSURE){
			if(m_pMainWnd){
				m_pMainWnd->SendMessage(UWM_ON_CHANGE_MODES,(WPARAM)m_iServerDynamicMode,(LPARAM)APPLICATION_MODE_FOCUS);
			}
		}
		if(m_iMode==MODE_SUM || m_iMode==MODE_CONTINUOUS){
			if(m_pMainWnd){
				m_pMainWnd->SendMessage(UWM_ON_CHANGE_MODES,(WPARAM)m_iServerDynamicMode,(LPARAM)APPLICATION_MODE_EXPERIMENT);
			}
		}
	}

	strncpy(str,pChunk->DateTimeRecorded,24);
	str[24]='\0';
	sprintf(strPrint,"File was saved on %s",str);
	PrintMessage(LEVEL_NORMAL,strPrint);

	strncpy(str,pChunk->UserName,16);
	str[16]='\0';
	m_strUserName=str;
	sprintf(strPrint,"For user %s",str);

	PrintMessage(LEVEL_NORMAL,strPrint);
	strncpy(str,pChunk->SubjectID,16);
	str[16]='\0';
	m_strSubjectID=str;
	sprintf(strPrint,"Subject ID %s",str);
	PrintMessage(LEVEL_NORMAL,strPrint);

	m_iDataType=pChunk->DataType;
	m_iFileType=pChunk->FileType;

	strncpy(str,pChunk->ThisFilename,16);
	str[16]='\0';
	sprintf(strPrint,"This Filename %s",str);
	PrintMessage(LEVEL_NORMAL,strPrint);
	strncpy(str,pChunk->NextFilename,16);
	str[16]='\0';
	sprintf(strPrint,"Next Filename %s",str);
	PrintMessage(LEVEL_NORMAL,strPrint);
	strncpy(str,pChunk->PrevFilename,16);
	str[16]='\0';
	sprintf(strPrint,"Prev Filename %s",str);
	PrintMessage(LEVEL_NORMAL,strPrint);


//	SetSubModesFromMode();
//	TODO Submodes are not set correctly, should change tag encoding and decoding
	switch(m_iMode){
	case MODE_NONE:
		break;
	case MODE_GREEN:
		m_iApplicationMode=APPLICATION_MODE_FOCUS;
		m_iFocusMode=MODE_GREEN;
		m_iServerDynamicMode=m_iFocusDynamicMode=SERVER_DYNAMIC_MODE_ROI;

		m_nWaveLength=m_nFocusWaveLength = pChunk->WaveLength;
		m_nFilterWidth=m_nFocusFilterWidth = pChunk->FilterWidth;
		m_iTemporalBinning = m_iTemporalFocusBinning = pChunk->TemporalBinning;
		m_iSpatialBinningX = m_iSpatialFocusBinningX = pChunk->SpatialBinningX;
		m_iSpatialBinningY = m_iSpatialFocusBinningY = pChunk->SpatialBinningY;

		SetFocusMode(m_iFocusMode);
		break;
	case MODE_EXPOSURE:
		m_iApplicationMode=APPLICATION_MODE_FOCUS;
		m_iFocusMode=MODE_EXPOSURE;
		m_iServerDynamicMode=m_iFocusDynamicMode=SERVER_DYNAMIC_MODE_ROI;

		m_nWaveLength=m_nExperimentWaveLength = pChunk->WaveLength;
		m_nFilterWidth=m_nExperimentFilterWidth = pChunk->FilterWidth;
		m_iTemporalBinning = m_iTemporalFocusBinning = pChunk->TemporalBinning;
		m_iSpatialBinningX = m_iSpatialFocusBinningX = pChunk->SpatialBinningX;
		m_iSpatialBinningY = m_iSpatialFocusBinningY = pChunk->SpatialBinningY;

		SetFocusMode(m_iFocusMode);
		break;
	case MODE_SUM:
		m_iApplicationMode=APPLICATION_MODE_EXPERIMENT;
		m_iExperimentMode=EXPERIMENT_MODE_SUM;
		m_iExperimentSumMode=EXPERIMENT_SUM_MODE_SUM;
		m_iServerDynamicMode=SERVER_DYNAMIC_MODE_EXPERIMENT;

		SetExperimentSumMode(m_iExperimentSumMode);
		break;
	case MODE_CONTINUOUS:
		m_iApplicationMode=APPLICATION_MODE_EXPERIMENT;
		m_iExperimentMode=EXPERIMENT_MODE_CONTINUOUS;
		m_iExperimentContinuousMode=EXPERIMENT_CONTINUOUS_MODE_CONTINUOUS;
		m_iServerDynamicMode=SERVER_DYNAMIC_MODE_EXPERIMENT;

		m_nWaveLength=m_nExperimentWaveLength = pChunk->WaveLength;
		m_nFilterWidth=m_nExperimentFilterWidth = pChunk->FilterWidth;
		m_iTemporalBinning = m_iTemporalExperimentBinning = pChunk->TemporalBinning;
		m_iSpatialBinningX = m_iSpatialExperimentBinningX = pChunk->SpatialBinningX;
		m_iSpatialBinningY = m_iSpatialExperimentBinningY = pChunk->SpatialBinningY;

		SetExperimentContinuousMode(m_iExperimentContinuousMode);
		break;
	default:
		PrintMessage(LEVEL_ERROR,"Unknown mode");
		return(FALSE);
	}

	//	m_nNFrames=pChunk->NFramesTotal;

	OnFileNew();
	if(pChunk->ROINumber){
		PrintMessage(LEVEL_NORMAL,"CContImageApp::SetSoftwareFromChunk Sub");
		CRect *r = new CRect(pChunk->ROIXPosition,pChunk->ROIYPosition,
							 pChunk->ROIXPosition+pChunk->ROIXSize-1,pChunk->ROIYPosition+pChunk->ROIYSize-1);
		m_pROI->AddROI(r,pChunk->ROINumber);
		OnROINew();
	}

	return(TRUE);
}

void CContImageApp::OnAcquireCamMisc(){
	/*
	typedef enum {
	P_PIXEL_SIZE=1,			// RANGE 1..32
	P_STROBE_MODE,
	P_STROBE_POLARITY,
	P_STROBE_DELAY,
	P_FRAME_RESET_MODE,
	P_FRAME_RESET_POLARITY,
	P_FRAME_RESET_OFFSET,
	P_FRAME_RESET_SIZE,


	P_TRIGGER_ENABLE,		// IFC_ENABLE_TYPE
	P_TRIGGER_SRC,			// IFC_TRIG_SRC_TYPE
	P_TRIGGER_POLARITY,		// IFC_EDGE_TYPE
	P_TRIGGER_STATE,		// IFC_LEVEL_TYPE
	P_GEN_SW_TRIGGER,		// any value

	P_CONTRAST,				// range 0..100
	P_BRIGHTNESS,			// range 0..100
	P_CUR_ACQ_LINE,


	P_LEN_ENABLE,			// IFC_ENABLE_TYPE
	P_LEN_SYNC,				// IFC_SYNC_TYPE
	P_LEN_POLARITY, 		// IFC_EDGE_TYPE

	P_FEN_ENABLE,			// IFC_ENABLE_TYPE
	P_FEN_POLARITY, 		// IFC_EDGE_TYPE
	P_HORZ_OFF,				// Module peculiar integer range	
	P_WIDTH_PIXELS,			// Module peculiar integer range	
	P_VERT_OFF,				// Module peculiar integer range	
	P_HEIGHT_PIXELS,		// Module peculiar integer range	

	P_FIRST_FIELD_STAT,		// IFC_FIELD_STATUS
	P_FIRST_FIELD_CMD,		// IFC_FIELD_STATUS
	P_SCAN_MODE_STAT,		// IFC_ILACE

	P_HSYNC_FREQ,
	P_HSYNC_WIDTH,
	P_HSYNC_POLARITY,
	P_HSYNC_SRC,
	P_HSYNC_SIGNAL_TYPE,
	P_VSYNC_FREQ,
	P_VSYNC_WIDTH,
	P_VSYNC_POLARITY,
	P_VSYNC_SRC,
	P_VSYNC_SIGNAL_TYPE,
	P_PIXEL_CLK_FREQ,
	P_PIXEL_CLK_POLARITY,
	P_TIMING_SRC,
	P_PIXEL_CLK_SIGNAL_TYPE,
	P_NUM_EQ_PULSES_FPORCH,
	P_NUM_EQ_PULSES_BPORCH,
	P_EQ_PULSE_WIDTH,
	P_SERR_PULSE_WIDTH,
	P_CLAMP_MODE,
	P_CLAMP_SEG,
	P_CLAMP_HSYNC_EDGE,
	P_CLAMP_OFFSET_TIME,
	P_CLAMP_LEVEL,
	P_PEDESTAL,
	P_TIMING_INPUT_CHANNEL,

	// Genral Color Space Option: can affect both CSC matrix and LUTS. If 
	// this parameter is applicable, P_COLOR_SPACE_CONV_COEFFS is
	// ignored.
	P_COLOR_SPACE_CONV,

	// Coefficients for linear color space conversion matrix. For most 
	// hardware modules this is subordinate to P_COLOR_SPACE_CONV. I.e.
	// if P_COLOR_SPACE_CONV is applicable then this is ignored.
	P_COLOR_SPACE_CONV_COEFFS,

	// Identifies the set of parameter groups applicable for a given camera definition
	P_PARAM_GROUPS_APPLICABLE, 

	P_PIXEL_COLOR,
	P_ANALOG_GAIN,
	P_APPLICABLE_CAM_PORT,
	P_STROBE_ENABLE,

	P_INPUT_LUT1_FILE,
	P_INPUT_LUT2_FILE,
	P_INPUT_LUT3_FILE,
	P_INPUT_LUT4_FILE,
	P_FIELD_SRC,
	P_FIELD_SHIFT,
	P_CAM_MODEL_NAME,
	P_COM_PORT_NAME,
	P_COM_PORT_BYTESIZE,
	P_COM_PORT_BAUDRATE,
	P_COM_PORT_PARITY,
	P_COM_PORT_STOPBITS,

    // Add new types above as needed

	GEN_PARAM_END_MARKER,	// Always keep these three last.
    IFC_LAST_SUP_PARAM = -1, 
    PARAM_NOT_SUPPORTED = 0,
	P_ALL_CAM_PARAMS_ID = 0xa0000000
} COMMON_PARAMS_TYPE;
*/
char str[256]={""};
/*	double dValue;
	DWORD nIndex=0;

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_FIELD_SRC,nIndex);
	sprintf(str,"P_FIELD_SRC = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_FIELD_SHIFT,nIndex);
	sprintf(str,"P_FIELD_SHIFT = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_FRAME_RESET_OFFSET,nIndex);
	sprintf(str,"P_FRAME_RESET_OFFSET = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_CONTRAST,nIndex);
	sprintf(str,"P_CONTRAST = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_BRIGHTNESS,nIndex);
	sprintf(str,"P_BRIGHTNESS = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_HORZ_OFF,nIndex);
	sprintf(str,"P_HORZ_OFF = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_WIDTH_PIXELS,nIndex);
	sprintf(str,"P_WIDTH_PIXELS = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_VERT_OFF,nIndex);
	sprintf(str,"P_VERT_OFF = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_HEIGHT_PIXELS,nIndex);
	sprintf(str,"P_HEIGHT_PIXELS = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_CUR_ACQ_LINE,nIndex);
	sprintf(str,"P_CUR_ACQ_LINE = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_PEDESTAL,nIndex);
	sprintf(str,"P_PEDESTAL = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_COLOR_SPACE_CONV,nIndex);
	sprintf(str,"P_COLOR_SPACE_CONV = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_PIXEL_COLOR,nIndex);
	sprintf(str,"P_PIXEL_COLOR = %f",dValue);
	PrintMessage(str);

	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_ANALOG_GAIN,nIndex);
	sprintf(str,"P_ANALOG_GAIN = %f",dValue);
	PrintMessage(str);

//	dValue=m_pFrameServer->m_pCamera->GetAcqParam(P_EXT_SYNC_TIME,nIndex);
//	sprintf(str,"P_EXT_SYNC_TIME = %f",dValue);
//	PrintMessage(str);
*/
//	m_pFrameServer->m_pCamera->SetAcqParam(P_FIELD_SHIFT,2,0);
/*
	BYTE turnOffCmd[] = {2,0xa1,1,0,0xa0,3};
	BYTE turnOnCmd[] =  {2,0xa1,1,1,0xa1,3};
	BYTE strV[]={0xa0,3};
	static BYTE bV=0;
	DWORD dwNumberOfBytes,dwNumber=2;

	strV[1]=bV;

	if(!WriteFile(m_pFrameServer->m_pCOMPort->m_hCOMPort, strV,dwNumber,&dwNumberOfBytes,NULL)){
		PrintMessage(LEVEL_ERROR,"Canot write to SP");
	}
	if(dwNumberOfBytes!=dwNumber){
		PrintMessage(LEVEL_ERROR,"Could not write to SP");
	}
	sprintf(str,"Wrote %u",bV);
	PrintMessage(str);
	bV++;
*/
/*	
	dwNumber=1;
	if(!WriteFile(m_pFrameServer->m_pCOMPort->m_hCOMPort, turnOnCmd+2,dwNumber,&dwNumberOfBytes,NULL)){
		PrintMessage(LEVEL_ERROR,"Cannot write to SP");
	}
	if(dwNumberOfBytes!=dwNumber){
		PrintMessage(LEVEL_ERROR,"Could not write to SP");
	}
	dwNumber=1;
	if(!ReadFile(m_pFrameServer->m_pCOMPort->m_hCOMPort, strRead,dwNumber,&dwNumberOfBytes,NULL)){
		PrintMessage(LEVEL_ERROR,"Cannot read from SP");
	}
	if(dwNumberOfBytes!=dwNumber){
		PrintMessage(LEVEL_ERROR,"Could not read from SP");
	}
	sprintf(str,"Read |%i|",strRead[0]);
	PrintMessage(str);
*/
}

void CContImageApp::OnAcquireCamReadCaps(){
/*typedef struct {
	BOOL sysColorRemap;		// can remap system colors to closest gray value
	DWORD dwAlignXStart;	// Number of bytes which X Start must be multiple of
	DWORD dwAlignXSize;		// Number of bytes which X Size must be multiple of
	DWORD dwAlignDst;		// Number of bytes which destination address must be multiple of
	DWORD dwMinAoiXSize;	// the smallest AOI in X dimension, 0 means AOI-X not supported
	DWORD dwMinAoiYSize;	// the smallest AOI in Y dimension, 0 means AOI-Y not supported
	BOOL bYcrcbPad;			// can perform BM Ycrcb pad on 8-bit mono
} READCAP;*/

#ifndef _DEBUG_NO_CAMERA

  char str[256];
	READCAP structReadCap;
	m_pFrameServer->m_pCamera->GetReadCaps(&structReadCap);
	sprintf(str,"sysColorRemap = %i bYcrcbPad = %i",structReadCap.sysColorRemap,structReadCap.bYcrcbPad);
	PrintMessage(str);
	sprintf(str,"dwAlignXStart = %i dwAlignXSize = %i dwAlignDst= %i",structReadCap.dwAlignXStart,
									structReadCap.dwAlignXSize,structReadCap.dwAlignDst);
	PrintMessage(str);
	sprintf(str,"dwMinAoiXSize = %i dwMinAoiYSize = %i",structReadCap.dwMinAoiXSize,structReadCap.dwMinAoiYSize);
	PrintMessage(str);
#endif  //  #ifndef _DEBUG_NO_CAMERA

}

void CContImageApp::OnAcquireCamLutCaps(){
#ifndef _DEBUG_NO_CAMERA
	char str[256];
	LUTCAP structLUTCap;
	m_pFrameServer->m_pCamera->GetLUTCaps(&structLUTCap);

	sprintf(str,"numInputLUTs = %i numOutputLUTs = %i",structLUTCap.numInputLUTs,structLUTCap.numOutputLUTs);
	PrintMessage(str);
	for(int i=0;i<structLUTCap.numInputLUTs;i++){
		sprintf(str," bitDepth = %i numEntries = %i pageSizeMask = %i",
							structLUTCap.inputLUTs[i].bitDepth,
							structLUTCap.inputLUTs[i].numEntries,
							structLUTCap.inputLUTs[i].pageSizeMask);
		PrintMessage(str);
	}
#endif  //  #ifndef _DEBUG_NO_CAMERA
	
}

void CContImageApp::OnAcquireMiscMemoryStatus(){
	m_pFrameServer->MemoryStatus();
}

void CContImageApp::OnUpdateFileSaveAll(CCmdUI* pCmdUI){
	pCmdUI->Enable(m_iApplicationMode == APPLICATION_MODE_FOCUS && m_iServerDynamicMode != SERVER_DYNAMIC_MODE_FAST);
}


void CContImageApp::OnAcquireDestinationTotalArea(){
	ULONG ulTotalArea;
	ULONG ulMainArea;
	float fRatio;
	char str[128];
	fRatio=m_pROI->GetTotalArea(&ulTotalArea,&ulMainArea);
	sprintf(str,"Total Imaging Area %lu",ulTotalArea);
	PrintMessage(str);
	sprintf(str,"Main Imaging Area %lu",ulMainArea);
	PrintMessage(str);
	sprintf(str,"Ratio %f",fRatio);
	PrintMessage(str);
}

	int iSeqPortNum;
	int iBoardNum;
	int iPort;
	int iDirection; // None, In, Out
	int iBitCount;
	int iBitMask;

void CContImageApp::OnAcquireMiscDIOTest(){
	char str[128];
	PHYSICAL_PORT *pPhysicalPort = m_pSynch->m_pSynchDIO->m_PhysicalPorts;
	for(int i=0;i<N_PHYSICAL_PORTS;i++){
		sprintf(str,"Port %i Board %i Type %i",	pPhysicalPort[i].iSeqPortNum,
												pPhysicalPort[i].iBoardNum,
												pPhysicalPort[i].iPort);
		PrintMessage(str);
		sprintf(str,"Direction %i Bit Count %i Mask %#x",pPhysicalPort[i].iDirection,
														pPhysicalPort[i].usBitCount,
														pPhysicalPort[i].usBitMask);
		PrintMessage(str);
	}
}

int CContImageApp::ExitInstance(){
//:MessageBox(NULL,"ExitInstance","",MB_OK);
	if(m_bRunningFocus || m_bRunningExperiment){
		m_pFrameServer->StopFrameServer();
		m_bRunningFocus=FALSE;
		m_bRunningExperiment=FALSE;
	}

	delete m_pFrameServer;
	delete m_pSynch;
	return CWinApp::ExitInstance();
}
