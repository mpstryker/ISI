// FileHeader.cpp: implementation of the CFileHeader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ContImage.h"
#include "FileHeader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CMultiChunk::CMultiChunk() :	CChunk<ISOI_CHUNK>("ISOI","COIM"),
								CChunk<HEAD_CHUNK>("HEAD","0000"),
								CChunk<HARD_CHUNK>("HARD","0000"),
								CChunk<SOFT_CHUNK>("SOFT","0000"),
								CChunk<COST_CHUNK>("COST","0000"),
								CChunk<EPST_CHUNK>("EPST","0000"),
								CChunk<GREE_CHUNK>("GREE","0000"),
								CChunk<SYNC_CHUNK>("SYNC","0000"),
								CChunk<ROIS_CHUNK>("ROIS","0000"),
								CChunk<DATA_CHUNK>("DATA"),
								CChunk<FRAM_CHUNK>("FRAM","0000"),
								CChunk<FRAM_COST_CHUNK>("cost","0000"),
								CChunk<FRAM_EPST_CHUNK>("epst","0000")
{

	memcpy(&(structFileHeader.ISOIChunk),CChunk<ISOI_CHUNK>::m_pChunk,sizeof(ISOI_CHUNK));
	memcpy(&(structFileHeader.SOFTChunk),CChunk<SOFT_CHUNK>::m_pChunk,sizeof(SOFT_CHUNK));
	memcpy(&(structFileHeader.HARDChunk),CChunk<HARD_CHUNK>::m_pChunk,sizeof(HARD_CHUNK));
	memcpy(&(structFileHeader.DATAChunk),CChunk<DATA_CHUNK>::m_pChunk,sizeof(DATA_CHUNK));
	structFileHeader.ISOIChunk.Size = sizeof(FILE_HEADER)-8;

	memcpy(&(structCOSTFileHeader.ISOIChunk),CChunk<ISOI_CHUNK>::m_pChunk,sizeof(ISOI_CHUNK));
	memcpy(&(structCOSTFileHeader.SOFTChunk),CChunk<SOFT_CHUNK>::m_pChunk,sizeof(SOFT_CHUNK));
	memcpy(&(structCOSTFileHeader.HARDChunk),CChunk<HARD_CHUNK>::m_pChunk,sizeof(HARD_CHUNK));
	memcpy(&(structCOSTFileHeader.COSTChunk),CChunk<COST_CHUNK>::m_pChunk,sizeof(COST_CHUNK));
	memcpy(&(structCOSTFileHeader.DATAChunk),CChunk<DATA_CHUNK>::m_pChunk,sizeof(DATA_CHUNK));
	structCOSTFileHeader.ISOIChunk.Size = sizeof(FILE_COST_HEADER)-8;

	memcpy(&(structEPSTFileHeader.ISOIChunk),CChunk<ISOI_CHUNK>::m_pChunk,sizeof(ISOI_CHUNK));
	memcpy(&(structEPSTFileHeader.SOFTChunk),CChunk<SOFT_CHUNK>::m_pChunk,sizeof(SOFT_CHUNK));
	memcpy(&(structEPSTFileHeader.HARDChunk),CChunk<HARD_CHUNK>::m_pChunk,sizeof(HARD_CHUNK));
	memcpy(&(structEPSTFileHeader.EPSTChunk),CChunk<EPST_CHUNK>::m_pChunk,sizeof(EPST_CHUNK));
	memcpy(&(structEPSTFileHeader.DATAChunk),CChunk<DATA_CHUNK>::m_pChunk,sizeof(DATA_CHUNK));
	structEPSTFileHeader.ISOIChunk.Size = sizeof(FILE_EPST_HEADER)-8;


	CChunk<FRAM_COST_CHUNK>::m_pChunk->HeaderSize = sizeof(FRAM_COST_CHUNK)-16;
	memcpy(&structCOSTFrameHeader,CChunk<FRAM_CHUNK>::m_pChunk,sizeof(FRAM_CHUNK));
	memcpy(&(structCOSTFrameHeader.framCOSTChunk),CChunk<FRAM_COST_CHUNK>::m_pChunk,sizeof(FRAM_COST_CHUNK));

	CChunk<FRAM_EPST_CHUNK>::m_pChunk->HeaderSize = sizeof(FRAM_EPST_CHUNK)-16;
	memcpy(&structEPSTFrameHeader,CChunk<FRAM_CHUNK>::m_pChunk,sizeof(FRAM_CHUNK));
	memcpy(&(structEPSTFrameHeader.framEPSTChunk),CChunk<FRAM_EPST_CHUNK>::m_pChunk,sizeof(FRAM_EPST_CHUNK));
}


CMultiChunk::~CMultiChunk(){
}


CSumFileHeader::CSumFileHeader(){
	memset(&m_SumFileHeader,0,sizeof(SUM_FILE_HEADER));
	m_SumFileHeader.sumHeadersize=sizeof(SUM_FILE_HEADER);
}

CSumFileHeader::CSumFileHeader(SUM_FILE_HEADER* pSUM_FILE_HEADER){
	if(pSUM_FILE_HEADER) memcpy(&m_SumFileHeader,pSUM_FILE_HEADER,sizeof(SUM_FILE_HEADER));
}

CSumFileHeader::~CSumFileHeader(){
}

