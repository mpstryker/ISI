// FrameServer.h: interface for the CFrameServer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRAMESERVER_H__4F32E5EE_269B_4E15_85D8_DBB717650EB8__INCLUDED_)
#define AFX_FRAMESERVER_H__4F32E5EE_269B_4E15_85D8_DBB717650EB8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <math.h>
#include <ifc.h>
#include "SerialPortControl.h"

#define DEFAULT_CAMERA_CONFIGURATION_FILE "SMDCams.txt"
#define DEFAULT_CAMERA_CONFIGURATION_MODE "PCD"

#define DEFAULT_NFRAMES_RING_BUFFER 100
#define DEFAULT_MIN_NFRAMES_RING_BUFFER 2
#define DEFAULT_PHYSICAL_MEMORY_TO_USE_PERCENT 40

#define SMD_M30_CAMERA_TYPE 0x41
#define SMD_M30_MIN_DATA_SHIFT_TIME_USEC 2160

#define CONTROL_REGISTER_INTG_MODE		(BYTE)0x80
#define CONTROL_REGISTER_RST_MICRO		(BYTE)0x40
#define CONTROL_REGISTER_NOT_USED5		(BYTE)0x20
#define CONTROL_REGISTER_NOT_USED4		(BYTE)0x10
#define CONTROL_REGISTER_ET_MODE		(BYTE)0x08
#define CONTROL_REGISTER_NOT_USED2		(BYTE)0x04
#define CONTROL_REGISTER_STOP_UP_CLK	(BYTE)0x02
#define CONTROL_REGISTER_SER_TRIG		(BYTE)0x01

#define FRAME_SERVER_MESSAGE_NULL				0
#define FRAME_SERVER_MESSAGE_BINNING_CHANGE		1
#define FRAME_SERVER_MESSAGE_BUFFER_CHANGE		2

#define THREAD_SHUTDOWN_NOT		0
#define THREAD_SHUTDOWN_STOP	1
#define THREAD_SHUTDOWN_ABORT	2

typedef CICapMod		FRAME_GRABBER;
typedef CICamera		CAMERA;
typedef CAM_ATTR		CAMERA_ATTRIBUTES;
typedef GRAB_EXT_ATTR	FRAME_ATTRIBUTES;
typedef IFC_GRAB_STATS	CAMERA_STATISTICS;
typedef CImgSrc			IMAGE_SOURCE;
typedef CImgSink		IMAGE_DESTINATION;
typedef CImgConn		IMAGE_CONNECTION;
typedef COverlay		IMAGE_OVERLAY;
typedef CImgFile		IMAGE_FILE;
typedef HIFCGRAB		GRAB_HANDLE;


typedef struct FOCUS_THREAD_PARAMS{
	HWND			hMsgWnd;
	LPVOID			pView;
	CAMERA			*pCamera;
	GRAB_HANDLE		hGrabID;
	DWORD			dwNFramesRingBuffer;
	BOOL volatile	*pbShutdown;
	DWORD			dwInterFrameTimeUsec;
	BOOL volatile	*pbHistogram;
	ULONG			*pulNBins;
	ULONG			**ppulHistogram;
	BOOL volatile	*pbTrace;
	BOOL volatile	*pbTraceAverage;
	BOOL volatile	*pbDisplayFrames;
} FOCUS_THREAD_PARAMS;

typedef struct EXPERIMENT_THREAD_PARAMS{
	HWND			hMsgWnd;
	HWND			hMainWnd;
	LPVOID			pView;
	int				iThreadSeqNum;
	int volatile	*piShutdown;
	HANDLE volatile *phEvent;
	ULONG volatile	*pulFrameLockState;
	DWORD			dwNFramesRingBuffer;
	BYTE			**ppbFrameBufferEntry;
	BYTE			**ppbFrameHeaderBufferEntry;
	BOOL volatile	*pbDisplayFrames;
	int				iDataType;
	ULONG			ulFrameHeaderSize;
} EXPERIMENT_THREAD_PARAMS;

typedef struct TRIGGER_THREAD_PARAMS{
	HWND			hMsgWnd;
	CAMERA			*pCamera;
	GRAB_HANDLE		hGrabID;
	DWORD			dwNFramesRingBuffer;
	BOOL volatile	*pbShutdown;
	int volatile	*piShutdownOther;
	int				iNEvents;
	HANDLE volatile	*phEvents;
	ULONG volatile	*pulFrameLockState;
	unsigned long int volatile	*pulFrameLockMask;
	BYTE			**ppbFrameHeaderBufferEntry;
	ULONG			(*pfunExperimentCallback)(WPARAM,LPARAM,double);
	int				iNframes;
	DWORD			dwInterFrameTimeUsec;
	void			*pExperimentControl;
} TRIGGER_THREAD_PARAMS;



//typedef CICapMod*(*ptFun1)(char *,DWORD, char *);
//CICapMod* (*CreateFrameGrabber)(char *,unsigned long,char *);
//CICapMod* (*CreateFrameGrabber)(char *,unsigned long,char *) = (CICapMod* (*) (char *,unsigned long,char *))IfxCreateCaptureModule;


class CFrameServer  
{
public:
	CFrameServer(DWORD = 0);
	virtual ~CFrameServer();

public:
	FRAME_GRABBER*		m_pFrameGrabber;
	CAMERA*				m_pCamera;
	CAMERA_ATTRIBUTES	m_CameraAttributes;
	GRAB_HANDLE			m_hGrabID;

	CSerialPortControl*	m_pCOMPort;

	DWORD	m_dwNFramesRingBuffer;

	BYTE*	m_pbHostFrameBuffer;
	ULONG	m_ulFrameBufferSizeB;
	ULONG	m_ulFrameSizeB;

	BYTE*	m_pbHostFrameHeaderBuffer;
	ULONG	m_ulFrameHeaderSizeB;


	BYTE*	m_pbLastFrame;

//private:
	BYTE	m_bCameraType;
	BYTE	m_bControlRegister;
	DWORD	m_dwInterFrameTimeUsec;
	DWORD	m_dwIntegrationTimeUsec;
	DWORD	m_dwVideoGain;
	long	m_lPixelOffset;
	DWORD	m_dwHardwareBinningV;
	DWORD	m_dwHardwareBinningH;
	DWORD	m_dwResolutionX;
	DWORD	m_dwResolutionY;
	DWORD	m_dwSynchronization;

	BOOL	m_bFrameServerReady;
	BOOL	m_bGrabbing;

	DWORD	n_dwAvailableContiguousMemory;
	UINT	m_nPhysicalMemoryAllowedPercent;
	BOOL	m_bMemoryFixedFrameBuffer;
	BOOL	m_bMemoryAvailablePercent;

	ULONG	m_ulMemoryUsedByFrameServerB;

	int		m_iGrabMode;
	int		m_iApplicationMode;

	DWORD	m_dwPriorityClass;

	BOOL volatile	m_bTriggerThreadShutdown;
	int volatile	*m_piOtherThreadsShutdown;
	HANDLE			m_hTriggerThread;
	DWORD			m_dwTriggerThreadID;
	HANDLE volatile	*m_phEvents;
	int				m_iNEvents;
	ULONG volatile	*m_pulFrameLockState;
	BYTE**			m_ppbFrameBufferEntry;
	BYTE**			m_ppbFrameHeaderBufferEntry;

	ULONG volatile m_ulFrameLockMask;

	TRIGGER_THREAD_PARAMS	m_structTriggerThreadParams;

	friend DWORD WINAPI TriggerThread(LPVOID);

	BOOL	FreeFrameBuffer();
	BOOL	ReallocateFrameBuffer();
	BOOL	TestFrameGrabber();
	void	GetCameraAttributes();

	BOOL	StartFrameServer(int iGrabMode,int iApplicationMode,int iNEvents = 0);
	BOOL	StopFrameServer(int iShutdown = THREAD_SHUTDOWN_STOP);

	BOOL	StartTriggerThread(int iNEvents);
	BOOL	StopTriggerThread(int iShutdown = THREAD_SHUTDOWN_STOP);

	BOOL	ResetADCBoard();
	BOOL	ResetCamera();

	BYTE	GetControlRegister();
	BYTE	GetCameraType();
	BYTE	GetFirmwareRevision();
	DWORD	GetUserGain();
	long	GetUserOffset();

	BOOL	SetControlRegister(BYTE bControlRegister);
	BOOL	SetControlRegisterBit(BYTE bControlRegisterBit);
	BOOL	UnsetControlRegisterBit(BYTE bControlRegisterBit);

	BOOL	SetUserGain(DWORD dwUserGain);
	BOOL	SetUserOffset(long lUserOffset);

	BOOL	SetFrameRate(double dFrameRate);
	BOOL	SetInterFrameTime(DWORD dwInterFrameTimeUsec);
	BOOL	SetIntegrationTime(DWORD dwIntegrationTimeUsec);
	BOOL	SetHardwareBinning(DWORD ulBinningX,DWORD ulBinningY);
	BOOL	SetHardwareBinning(DWORD ulBinning);
	BOOL	ResetHardware();
	ULONG	MemoryStatus(int iPercent = 0);
	ULONG	MemoryStatus(int iPercent,ULONG *pulAvailablePhysicalMB,ULONG *pulTotalPhysicalMB = NULL,ULONG *pulTotalVirtualMB = NULL,int *piLoad = NULL);
	ULONG	MemoryAvailablePhysical(ULONG *pulTotalPhysicalB);
	BOOL	OnSettingsHardware();

	BOOL	DequeThread(int iNumber);
};

#endif // !defined(AFX_FRAMESERVER_H__4F32E5EE_269B_4E15_85D8_DBB717650EB8__INCLUDED_)
