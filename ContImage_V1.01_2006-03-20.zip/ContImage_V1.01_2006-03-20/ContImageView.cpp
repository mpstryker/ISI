// ContImageView.cpp : implementation of the CContImageView class
//
// Val: 11-19-2002 added update of the trace's m_ulInterFrameTimeUsec (T-binning change)

#include "stdafx.h"
#include "ContImage.h"

#include "ContImageDoc.h"
#include "ContImageView.h"

#include <math.h>
//#include <time.h>
//#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "TraceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define FIRST_COLOR_NOT_IGNORED_SW_REMAP	11
#define LAST_COLOR_NOT_IGNORED_SW_REMAP		244
#define FIRST_COLOR_NOT_IGNORED_HW_REMAP	16
#define LAST_COLOR_NOT_IGNORED_HW_REMAP		239

#define REMAP_COLOR_UNDERFLOW	0x00808080
#define REMAP_COLOR_OVERFLOW	0x00000000

#define NUM_EXPOSURE_FUNKY_COLORS 128

COLORREF exposureFunkyColors[NUM_EXPOSURE_FUNKY_COLORS]={
	0x00809080,//1 Val: new
//	0x00ff00bf,//Val: new
	0x00809080,//Val: new
//	0x00ff00b6,//Val: new
	0x00809080,//Val: new
//	0x00ff00ad,//Val: new
	0x00809080,//Val: new
//	0x00ff00a4,//Val: new
	0x00809080,//Val: new
//	0x00ff009b,//Val: new
	0x00809080,//Val: new // First one not ignored by software remap 
	0x00ff0092,//Val: new
	0x00ff008a,//Val: new
	0x00ff0081,//Val: changed red 7c->81 // First one not ignored by remap on primary
	0x00fe0078,//10
	0x00fe006f,
	0x00fe0066,
	0x00fe005d,
	0x00ff004f,
	0x00fe0042,
	0x00fe0039,
	0x00fe0030,
	0x00fe0027,
	0x00fe001e,
	0x00fe0015,//20
	0x00ff0007,
	0x00ff0200,
	0x00ff0b00,
	0x00fe1800,
	0x00fe2100,
	0x00ff2f00,
	0x00ff3800,
	0x00ff4100,
	0x00ff4a00,
	0x00ff5300,//30
	0x00ff5c00,
	0x00fe6900,
	0x00ff7700,
	0x00ff8000,
	0x00ff8900,
	0x00ff9200,
	0x00fe9e00,
	0x00fea700,
	0x00feb000,
	0x00feb900,//40
	0x00fec200,
	0x00fecb00,
	0x00fedd00,
	0x00fee600,
	0x00fef000,
	0x00fef900,
	0x00fafe00,
	0x00f1fe00,
	0x00e5ff00,
	0x00dcff00,//50
	0x00d3ff00,
	0x00c4fe00,
	0x00bbfe00,
	0x00afff00,
	0x00a6ff00,
	0x009dff00,
	0x0094ff00,
	0x008bff00,
	0x0082ff00,
	0x0074fe00,//60
	0x006bfe00,
	0x005eff00,
	0x0055ff00,
	0x004cff00,
	0x003efe00,
	0x0035fe00,
	0x002cfe00,
	0x0023fe00,
	0x001afe00,
	0x0011fe00,//70
	0x0000fe01,
	0x0000fe0d,
	0x0000fe13,
	0x0000fe1c,
	0x0000fe25,
	0x0000ff32,
	0x0000ff3b,
	0x0000ff44,
	0x0000ff4d,
	0x0000ff56,//80
	0x0000fe64,
	0x0000ff71,
	0x0000ff7b,
	0x0000ff84,
	0x0000ff8d,
	0x0000ff96,
	0x0000ff9f,
	0x0000feab,
	0x0000feb4,
	0x0000ffc3,//90
	0x0000ffcc,
	0x0000ffd5,
	0x0000fee1,
	0x0000feea,
	0x0000fef3,
	0x0000fefc,
	0x0000f7fe,
	0x0000eefe,
	0x0000e1ff,
	0x0000d3fe,//100
	0x0000cafe,
	0x0000c1fe,
	0x0000b8fe,
	0x0000abff,
	0x0000a2ff,
	0x000099ff,
	0x000090ff,
	0x000087ff,
	0x00007afe,
	0x00006cff,//110
	0x000063ff,
	0x00005aff,
	0x000051ff,
	0x000048ff,
	0x00003fff,
	0x000032fe,
	0x000029fe,
//	0x000020fe,
	0x00ffffff,
//	0x000012ff,
	0x00ffffff,
//	0x000009ff,//120 //Last one not ignored by remap on primary
	0x00ffffff,//120 //Last one not ignored by remap on primary
	0x00ffffff,
	0x00ffffff,
	0x00000000,//Last one not ignored by software remap 
	0x00000000,
	0x00000000,
	0x00000000,
	0x00000000,
	0x00000000
};

static const UINT UWM_ON_SPATIAL_BINNING_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_SPATIAL_BINNING_CHANGE"));
static const UINT UWM_ON_TEMPORAL_BINNING_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_TEMPORAL_BINNING_CHANGE"));
static const UINT UWM_ON_ROI_CHANGE = ::RegisterWindowMessage(_T("UWM_ON_ROI_CHANGE"));
static const UINT UWM_ON_RESIZE_CLIENT_AREA = ::RegisterWindowMessage(_T("UWM_ON_RESIZE_CLIENT_AREA"));
static const UINT UWM_ON_START_GRABBING = ::RegisterWindowMessage(_T("UWM_ON_START_GRABBING"));
static const UINT UWM_ON_STOP_GRABBING = ::RegisterWindowMessage(_T("UWM_ON_STOP_GRABBING"));
static const UINT UWM_ON_REMOVED_SUB_ROI = ::RegisterWindowMessage(_T("UWM_ON_REMOVED_SUB_ROI"));
static const UINT UWM_SWITCH_FOCUS_MODE = ::RegisterWindowMessage(_T("UWM_SWITCH_FOCUS_MODE"));
static const UINT UWM_ON_SAVE_GREEN = ::RegisterWindowMessage(_T("UWM_ON_SAVE_GREEN"));
static const UINT UWM_ON_FILL_STORAGE_BUFFER = ::RegisterWindowMessage(_T("UWM_ON_FILL_STORAGE_BUFFER"));
static const UINT UWM_ON_SAVE_IMAGE_FILE = ::RegisterWindowMessage(_T("UWM_ON_SAVE_IMAGE_FILE"));
static const UINT UWM_ON_CHANGE_MODES = ::RegisterWindowMessage(_T("UWM_ON_CHANGE_MODES"));

static const UINT UWM_ON_HISTOGRAM_DESTROY = ::RegisterWindowMessage(_T("UWM_ON_HISTOGRAM_DESTROY"));
static const UINT UWM_ON_UPDATE_HISTOGRAM = ::RegisterWindowMessage(_T("UWM_ON_UPDATE_HISTOGRAM"));

static const UINT UWM_ON_TRACE_DESTROY = ::RegisterWindowMessage(_T("UWM_ON_TRACE_DESTROY"));
static const UINT UWM_ON_UPDATE_TRACE = ::RegisterWindowMessage(_T("UWM_ON_UPDATE_TRACE"));

static const UINT UWM_FOCUS_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_FOCUS_THREAD_FINISHED"));
static const UINT UWM_EXPERIMENT_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_EXPERIMENT_THREAD_FINISHED"));

/////////////////////////////////////////////////////////////////////////////
// CContImageView

IMPLEMENT_DYNCREATE(CContImageView, CScrollView)

BEGIN_MESSAGE_MAP(CContImageView, CScrollView)
	//{{AFX_MSG_MAP(CContImageView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_ACQUIRE_MISC_COORDINATES, OnAcquireMiscCoordinates)
	ON_WM_DESTROY()
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_ACQUIRE_DESTINATION_PROPERTIES, OnAcquireDestinationProperties)
	ON_COMMAND(ID_ACQUIRE_SOURCE_PROPERTIES, OnAcquireSourceProperties)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_COMMAND(ID_ACQUIRE_CONNECTION_PROPERTIES, OnAcquireConnectionProperties)
	ON_COMMAND(ID_TOOL_HISTOGRAM, OnToolHistogram)
	ON_UPDATE_COMMAND_UI(ID_TOOL_HISTOGRAM, OnUpdateToolHistogram)
	ON_COMMAND(ID_TOOL_TRACE, OnToolTrace)
	ON_UPDATE_COMMAND_UI(ID_TOOL_TRACE, OnUpdateToolTrace)
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_CURSOR_POSITION, OnUpdateIndicatorCursorPosition)
	ON_COMMAND_RANGE(ID_ZOOM_8, ID_ZOOM_0125, OnZoom)
	ON_UPDATE_COMMAND_UI_RANGE(ID_ZOOM_8, ID_ZOOM_0125, OnUpdateZoom)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_SAVE, OnUpdateSaveGreen)

	ON_REGISTERED_MESSAGE(UWM_ON_ROI_CHANGE, OnROIChange)
	ON_REGISTERED_MESSAGE(UWM_ON_SPATIAL_BINNING_CHANGE, OnSpatialBinningChange)
	ON_REGISTERED_MESSAGE(UWM_ON_TEMPORAL_BINNING_CHANGE, OnTemporalBinningChange)
	ON_REGISTERED_MESSAGE(UWM_ON_START_GRABBING, OnStartGrabbing)
	ON_REGISTERED_MESSAGE(UWM_ON_STOP_GRABBING, OnStopGrabbing)
	ON_REGISTERED_MESSAGE(UWM_ON_REMOVED_SUB_ROI, OnRemovedSubROI)
	ON_REGISTERED_MESSAGE(UWM_SWITCH_FOCUS_MODE, OnSwitchFocusMode)
	ON_REGISTERED_MESSAGE(UWM_ON_SAVE_GREEN, OnSaveGreen)
	ON_REGISTERED_MESSAGE(UWM_ON_FILL_STORAGE_BUFFER, OnFillStorgeBuffer)
	ON_REGISTERED_MESSAGE(UWM_ON_SAVE_IMAGE_FILE, OnSaveImageFile)
	ON_REGISTERED_MESSAGE(UWM_ON_CHANGE_MODES, OnChangeModes)
	ON_REGISTERED_MESSAGE(UWM_ON_HISTOGRAM_DESTROY, OnHistogramDestroy)
	ON_REGISTERED_MESSAGE(UWM_ON_UPDATE_HISTOGRAM, OnUpdateHistogram)

	ON_REGISTERED_MESSAGE(UWM_ON_TRACE_DESTROY, OnTraceDestroy)
	ON_REGISTERED_MESSAGE(UWM_ON_UPDATE_TRACE, OnUpdateTrace)

	ON_COMMAND(ID_TRACE_ADD, OnAddTrace)
	ON_COMMAND(ID_TRACE_ADD_AVERAGE, OnAddAvarageTrace)
	ON_COMMAND_RANGE(ID_TRACE_REMOVE0,ID_TRACE_REMOVE3, OnRemoveTrace)
	ON_COMMAND_RANGE(ID_TRACE_SUBSTITUTE0,ID_TRACE_SUBSTITUTE3, OnSubstituteTrace)
	ON_COMMAND_RANGE(ID_TRACE_SHOW0,ID_TRACE_SHOW3, OnShowPixel)

	ON_REGISTERED_MESSAGE(UWM_FOCUS_THREAD_FINISHED, OnFocusThreadFinished)
	ON_REGISTERED_MESSAGE(UWM_EXPERIMENT_THREAD_FINISHED, OnExperimentThreadFinished)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContImageView construction/destruction

CContImageView::CContImageView(){

	m_ulFileHeaderSize = 0;
	m_pFileHeader = NULL;

	m_fpExperimentFile = NULL;
	m_fpNextExperimentFile = NULL;
	m_iMaxNExperimentFiles = FILENAME_SCHEME_MAX;
	m_iNExperimentFiles = 0;
	m_strExperimentFileNames = (char*)calloc(1,m_iMaxNExperimentFiles*FILENAME_SIZE);

	m_bFocusThreadShutdown = FALSE;
	m_piExperimentThreadShutdown = NULL;
	m_hFocusThread = m_hExperimentThread = NULL;
	m_dwFocusThreadID = m_dwExperimentThreadID = 0;

	m_bHistogram	= FALSE;
	m_wndHistogram	= NULL;
	m_ulNBins		= 256;
	m_pulHistogram	= (ULONG*)calloc(256,sizeof(ULONG));

	m_wndTrace		= NULL;
	m_bTrace		= FALSE;
	m_bTraceAverage	= FALSE;
	m_ulNTraces		= 0;
	m_iLastPixel	= -1;

	m_piViewIndex=m_piViewNumber=NULL;
	m_pointCursorPos=CPoint(0,0);
	m_zoomROIView=	zoom05;
	m_fZoomX	=	DEFAULT_ZOOM;
	m_fZoomY	=	DEFAULT_ZOOM;
	m_fRawZoomX	=	DEFAULT_ZOOM;
	m_fRawZoomY	=	DEFAULT_ZOOM;
	m_bSelect	=	FALSE;
	m_hOverlayDC=NULL;


	m_crROIRectColor = DEFAULT_ROI_RECT_COLOR;
	m_crDragDrawRectColor = DEFAULT_DRAG_DRAW_RECT_COLOR;
	m_dwDragDrawRectSpacing = DEFAULT_DRAG_DRAW_RECT_SPACING;

	m_ppenSelectSimple	= new CPen(PS_DOT,1,m_crDragDrawRectColor);
	m_dwStyle[0]=m_dwStyle[1]=m_dwDragDrawRectSpacing;
    m_lb.lbStyle = BS_SOLID;
    m_lb.lbColor = DEFAULT_DRAG_DRAW_RECT_COLOR;
    m_lb.lbHatch = 0;
    m_ppenSelect = new CPen(PS_USERSTYLE|PS_GEOMETRIC, 2, &m_lb, 2, m_dwStyle);

	m_ppenSelectTransparent	= new CPen(PS_SOLID,2,(COLORREF)0x00000000);
	m_ppenROI = new CPen(PS_SOLID,2,m_crROIRectColor);
	m_pbrushROIFill	= new CBrush((COLORREF)0x00000000);


	m_hImageSource				= NULL;
	m_hImageDestination			= NULL;
	m_hImageConnection			= NULL;	
	m_hImageDestinationTemplate	= NULL;
	m_hImageOverlay				= NULL;

	m_pLocalSaveBuffer			= NULL;
	m_dwLocalSaveBufferSize		= 0;
	m_pbLocalImageBuffer		= NULL;
	m_dwLocalImageBufferSize	= 0;

	m_pbLocalDisplayBuffer		= NULL;
	m_dwLocalDisplayBufferSize	= 0;
	m_pulLocalStorageBuffer		= NULL;
	m_dwLocalStorageBufferSize	= 0;

	m_bRunningFocus				= FALSE;
	m_bRunningExperiment		= FALSE;

	PrintMessage("View created");
}

CContImageView::~CContImageView(){
	if(*m_piViewIndex){
		PrintMessage("SubROI view destroyed");
	}
	else{
		PrintMessage("Main view destroyed");	
	}
	free(m_pulHistogram);
}

BOOL CContImageView::PreCreateWindow(CREATESTRUCT& cs)
{
//	::MessageBox(NULL,"CContImageView::PreCreateWindow","",MB_OK);
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CContImageView drawing

void CContImageView::OnDraw(CDC* pDC){
	CContImageApp *theApp=(CContImageApp*)AfxGetApp();
/*	if(m_bMainView){
		PrintMessage("CContImageView::OnDraw: Main");
	}
	else{
		PrintMessage("CContImageView::OnDraw: Sub");
	}
	*/
	CPoint sp = GetScrollPosition();
	sp.x = (long)(sp.x / m_fZoomX);
	sp.y = (long)(sp.y / m_fZoomY);
	ASSERT(sp.x<=(long)m_sizeROIBinned.cx - 1);
	ASSERT(sp.y<=(long)m_sizeROIBinned.cy - 1);
//	sp.x=min(sp.x, (long)m_sizeROIBinned.cx - 1);
//	sp.y=min(sp.y, (long)m_sizeROIBinned.cy - 1);
	if (m_hImageSource) m_hImageSource->SetAoiPos( (WORD)sp.x, (WORD)sp.y);
//	if(!m_hFocusThread){
		if(m_hImageConnection){
			m_hImageConnection->Display();
		}
//	}
#ifndef _DEBUG_NO_CAMERA

	if(m_hImageOverlay){
		HDC hDC =  m_hImageConnection->GetOverlayDC();
		if(!hDC) return; 
		CDC* pOverlayDC = CDC::FromHandle(hDC);
		char strNumber[2];
		strNumber[1]='\0';

		pOverlayDC->FillRect(&m_rectROIFill,m_pbrushROIFill);
		CBrush* pbrushOld = (CBrush*)pOverlayDC->SelectStockObject(NULL_BRUSH);
		CPen* ppenOld = (CPen*)pOverlayDC->SelectObject(m_ppenROI);

		pOverlayDC->SetBkColor(0x00000000);
		pOverlayDC->SetTextColor(m_crROIRectColor);
		VERIFY(m_fontROI.CreatePointFont(300, _T("Times New Roman Bold"), pOverlayDC));
		CFont* pfontOld = pOverlayDC->SelectObject(&m_fontROI);

    CROI* pCROI = theApp->m_pROI;
		CRect rect;
		for(ROI *pROI = pCROI->GetHeadROI();pROI;pROI=pCROI->GetNextROI(pROI)){
				rect.CopyRect(pROI->pRect);
				RescaleRect(&rect,(float)*m_piSpatialBinningX,(float)*m_piSpatialBinningY);
				AugmentRect(&rect);
				pOverlayDC->Rectangle(rect);
				strNumber[0]=NumberToChar(pCROI->GetNumber(pROI->pRect));
				pOverlayDC->TextOut(rect.left+1,rect.top+1,strNumber,1);
//				pOverlayDC->ExtTextOut(pROI->pRect->left+1,pROI->pRect->top+1, ETO_OPAQUE, NULL, _T(strNumber), NULL);


		}
		pOverlayDC->SelectObject(pbrushOld); 
		pOverlayDC->SelectObject(ppenOld); 
		pOverlayDC->SelectObject(pfontOld);
		m_fontROI.DeleteObject();
		pOverlayDC->DeleteTempMap();
		m_hImageConnection->ReleaseOverlayDC(hDC);
    }
#endif  //  #ifndef _DEBUG_NO_CAMERA
	
}

void CContImageView::OnInitialUpdate(){
	CScrollView::OnInitialUpdate();
	PrintMessage("CContImageView::OnInitialUpdate");
	CContImageApp* theApp=(CContImageApp*)AfxGetApp();

	CContImageDoc* pDoc = GetDocument();

	m_bMainView = !*(m_piViewIndex = &(pDoc->m_iDocIndex));
	m_piViewNumber = &(pDoc->m_iDocNumber);

	m_prectROI			= pDoc->m_prectROI;
	m_piSpatialBinningX	= pDoc->m_piSpatialBinningX;
	m_piSpatialBinningY	= pDoc->m_piSpatialBinningY;
	m_piTemporalBinning	= pDoc->m_piTemporalBinning;

//	char str[128];
//	sprintf(str,"CContImageView::OnInitialUpdate %i %i",m_prectROI->left,m_prectROI->top);
//	::MessageBox(this->m_hWnd,str,NULL,MB_OK);
	PrintMessage(*m_piViewIndex,*m_piViewNumber);

	m_psizeROIMain		= &(theApp->m_pROI->m_sizeROIMain);

//	hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR1);
	SetClassLong(this->m_hWnd, GCL_HCURSOR, (LONG)AfxGetApp()->LoadCursor(IDC_CURSOR1));
//	SetClassLong(this->m_hWnd, GCL_HCURSOR, (LONG)AfxGetApp()->LoadStandardCursor(IDC_ARROW));

	HBRUSH hBkgrBrush = CreateSolidBrush(0x00809080);
	SetClassLong(this->m_hWnd, GCL_HBRBACKGROUND,(LONG)hBkgrBrush);

	m_dwServerDynamicMode = theApp->m_iServerDynamicMode;
	m_dwApplicationMode = theApp->m_iApplicationMode;

	OnROIChange();

	if((m_bRunningFocus = theApp->m_bRunningFocus)) OnStartGrabbing();
}

/////////////////////////////////////////////////////////////////////////////
// CContImageView printing

BOOL CContImageView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CContImageView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CContImageView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CContImageView diagnostics

#ifdef _DEBUG
void CContImageView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CContImageView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CContImageDoc* CContImageView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CContImageDoc)));
	return (CContImageDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContImageView message handlers

LRESULT CContImageView::ResizeClientArea(int iWidth, int iHeight){
	PrintMessage("CContImageView::ResizeClientArea");

    if (GetParentFrame() == NULL) return (LRESULT)FALSE;

	for (int i=0; i<2;i++) {
		// Do the following twice because if border size changes it's necessary to hit steady-state
		RECT SinkClientWindowRect;
		GetClientRect(&SinkClientWindowRect);
		
		RECT ClientWindowRect;
		GetParentFrame()->GetClientRect(&ClientWindowRect);
		long VertAdjust = ClientWindowRect.bottom - SinkClientWindowRect.bottom;
		long HorzAdjust = ClientWindowRect.right - SinkClientWindowRect.right;
		
		RECT WindowRect;
		GetParentFrame()->GetWindowRect(&WindowRect);
		
		long lBorderHorz = (WindowRect.right - WindowRect.left) - ClientWindowRect.right;
		long lBorderTop = (WindowRect.bottom - WindowRect.top) - ClientWindowRect.bottom;
			

		GetParentFrame()->MoveWindow(-WindowRect.left,-WindowRect.top,
			iWidth + lBorderHorz +  HorzAdjust,
			iHeight + lBorderTop + VertAdjust,
			TRUE);
				
		GetParentFrame()->SendMessage(WM_PAINT, 0, 0);
		SendMessage(WM_PAINT, 0, 0);
	}		
		
	if(GetParentFrame() != NULL){
		return (GetParentFrame()->SendMessage(UWM_ON_RESIZE_CLIENT_AREA,(WPARAM)(&iWidth),(LPARAM)(&iHeight)));
	}
	else{
		return (LRESULT)FALSE;
	}
}

void CContImageView::OnLButtonDown(UINT nFlags, CPoint point){
	if(/*m_bMainView &&*/ m_dwServerDynamicMode != SERVER_DYNAMIC_MODE_FAST && !m_bRunningExperiment){
 		m_bSelect=TRUE;
		m_rectSelectLast=m_rectSelect=CRect(point/*+pointSP*/,point/*+pointSP*/);
		SetCapture();
	}
	CScrollView::OnLButtonDown(nFlags, point);
}

void CContImageView::OnMouseMove(UINT nFlags, CPoint point){
	m_pointCursorPos=point;
	if(m_bMainView){
		if (m_bSelect){
			m_rectSelectLast=m_rectSelect;

			m_rectSelect.right	= point.x; 
			m_rectSelect.bottom	= point.y;
			DrawSelect();
/*
			RECT rectClient;
			CPoint pointScroll=CPoint(0,0);
			GetClientRect(&rectClient);
			if(point.x<0) pointScroll.x = min(0,(point.x-m_rectSelectLast.right)/2)-abs(point.y-m_rectSelectLast.bottom);
			ScrollToPosition(GetScrollPosition()+pointScroll);
			PrintMessage(point.x,point.y);
*/
		}
	}
	CScrollView::OnMouseMove(nFlags, point);
}

void CContImageView::OnLButtonUp(UINT nFlags, CPoint point){
	CContImageApp* theApp=(CContImageApp*)AfxGetApp();
	if(m_bSelect){
		m_bSelect=FALSE;
		ReleaseCapture();

		CRect *r = new CRect(m_rectSelect);
		r->OffsetRect(GetScrollPosition());
		r->NormalizeRect();
		RescaleRect(r,m_fRawZoomX,m_fRawZoomY);
		PrintMessage(*r);
		if(r->IsRectEmpty()){
			if(m_wndTrace){
				OnAddTrace((long)(r->left/(*m_piSpatialBinningX)+(r->top/(*m_piSpatialBinningY))*m_sizeROIBinned.cx));
			}
			delete r;
		}
		else{
			if(m_bMainView && r->IntersectRect(m_prectROI,r)){
				char str[128];
				sprintf(str,"Orig: Position X=%i Y=%i\nDimensions Width=%i Height=%i",
					m_rectSelect.left,m_rectSelect.top,m_rectSelect.Width()+1,m_rectSelect.Height()+1);
				PrintMessage(str);
				sprintf(str,"Position LT=(%i %i) RB=(%i %i)\nDimensions Width=%i Height=%i",
				r->left,r->top,r->right,r->bottom,r->Width()+1,r->Height()+1);
				PrintMessage(str);
				if(MessageBox(str,"Selection",MB_OKCANCEL) == IDOK){
					theApp->m_pROI->AddROI(r);
					theApp->OnROINew();
				}
				else{
					delete r;
//					DrawSelect();
				}
			}
			else delete r;
		SendMessage(WM_PAINT,0,0);
		SendMessage(WM_PAINT,0,0);
		}
//		PrintMessage(m_rectSelect);
	}
	CScrollView::OnLButtonUp(nFlags, point);
}

void CContImageView::DrawSelect(){	
	CRect rect=m_rectSelect;
	CRect rectLast=m_rectSelectLast;

	rect.NormalizeRect();
	rectLast.NormalizeRect();

	if(m_bRunningFocus){
		if(m_hImageOverlay){
			if(!(m_hOverlayDC = m_hImageConnection->GetOverlayDC())){
				PrintMessage(LEVEL_ERROR,"CContImageView::OnLButtonDown: m_hOverlayDC is not available");
				return;
			}
			m_pOverlayCDC = CDC::FromHandle(m_hOverlayDC);

			CPoint pointSP = GetScrollPosition();

			rect.OffsetRect(pointSP);
			rectLast.OffsetRect(pointSP);
			RescaleRect(&rect,m_fZoomX,m_fZoomY);
			RescaleRect(&rectLast,m_fZoomX,m_fZoomY);
			AugmentRect(&rect);
			AugmentRect(&rectLast);

			CBrush* oldBrush=(CBrush*)m_pOverlayCDC->SelectStockObject(NULL_BRUSH);

			CPen* oldPen = (CPen*) m_pOverlayCDC->SelectObject(m_ppenSelectTransparent);
			m_pOverlayCDC->Rectangle(rectLast); 

			m_pOverlayCDC->SelectObject(m_ppenSelect);
			m_pOverlayCDC->Rectangle(rect); 

			m_pOverlayCDC->SelectObject(oldBrush); 
			m_pOverlayCDC->SelectObject(oldPen); 

			m_pOverlayCDC->DeleteTempMap();
			m_hImageConnection->ReleaseOverlayDC(m_hOverlayDC);
		}
	}
	else{
		AugmentRect(&rect);
		AugmentRect(&rectLast);
		CClientDC dc(this);
		int oldMode=dc.SetROP2(R2_NOT); 
		CBrush* oldBrush=(CBrush*)dc.SelectStockObject(NULL_BRUSH); 
		CPen* oldPen = (CPen*) dc.SelectObject(m_ppenSelectSimple);
		dc.Rectangle(rectLast); 
		dc.Rectangle(rect); 
		dc.SetROP2(oldMode); 
		dc.SelectObject(oldBrush); 
		dc.SelectObject(oldPen); 
	}
}

void CContImageView::RescaleRect(CRect* r,float x,float y){
	r->left=(long)(r->left/x);
	r->right=(long)(r->right/x);
	r->top=(long)(r->top/y);
	r->bottom=(long)(r->bottom/y);
}

void CContImageView::AugmentRect(CRect* r){
	if(r->right) r->right++;
	if(r->bottom) r->bottom++;
}

void CContImageView::OnUpdateIndicatorCursorPosition(CCmdUI* pCmdUI){
	if(!((CContImageApp*)AfxGetApp())->m_iDisplayFrames) return;
	CString str;
	CPoint sp = GetScrollPosition();
	int x = (int)((m_pointCursorPos.x+sp.x)/m_fZoomX);
	int y = (int)((m_pointCursorPos.y+sp.y)/m_fZoomY);
	x = x<0 ? 0 : x;
	y = y<0 ? 0 : y;
	x = x>=m_sizeROIBinned.cx ? m_sizeROIBinned.cx-1 : x;
	y = y>=m_sizeROIBinned.cy ? m_sizeROIBinned.cy-1 : y;
	if(m_pulLocalStorageBuffer){
		ULONG ulValue = *(m_pulLocalStorageBuffer + x+y*m_sizeROIBinned.cx) >> 4;
		if(m_bMainView) str.Format(_T("% 4d % 4d - %X"), x, y,ulValue);
		else str.Format(_T("% 4d(%d) % 4d (%d) - %X"),	x+m_prectROI->left/(*m_piSpatialBinningX),x, 
												y+m_prectROI->top/(*m_piSpatialBinningY),y,ulValue);
	}
	else{
		if(m_bMainView) str.Format(_T("% 4d % 4d"), x, y);
		else str.Format(_T("% 4d(%d) % 4d (%d)"),	x+m_prectROI->left/(*m_piSpatialBinningX),x, 
												y+m_prectROI->top/(*m_piSpatialBinningY),y);
	}
	pCmdUI->SetText(str);
	pCmdUI->Enable(1);
}

LRESULT CContImageView::OnROIChange(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnROIChange");
	m_sizeROI=CSize(m_prectROI->right-m_prectROI->left+1,m_prectROI->bottom-m_prectROI->top+1);
	m_rectROIFill.CopyRect(m_prectROI);
	AugmentRect(&m_rectROIFill);
	return OnSpatialBinningChange(m_dwServerDynamicMode,m_dwApplicationMode);
}

LRESULT CContImageView::OnSpatialBinningChange(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnSpatialBinningChange");
	BOOL bRestart=FALSE;
	if(m_wndTrace) RemoveAllTraces();
	if(m_bRunningFocus){
		bRestart=TRUE;
		OnStopGrabbing();
	}
	CloseDevices();

	m_dwServerDynamicMode = (DWORD)wp;
	m_dwApplicationMode = (DWORD)lp;

	CRect* prectAll=&(((CContImageApp*)AfxGetApp())->m_pROI->m_rectROIMain);
	FixEndPoints(*m_piSpatialBinningX,
				m_prectROI->left,m_prectROI->right,
				prectAll->left,prectAll->right,
				&(m_rectROIBinning.left),&(m_rectROIBinning.right));
	FixEndPoints(*m_piSpatialBinningY,
				m_prectROI->top,m_prectROI->bottom,
				prectAll->top,prectAll->bottom,
				&(m_rectROIBinning.top),&(m_rectROIBinning.bottom));
	m_sizeROIBinned=CSize((m_rectROIBinning.Width() +1)/(*m_piSpatialBinningX),
						  (m_rectROIBinning.Height()+1)/(*m_piSpatialBinningY));
	m_sizeROIBinnedCorecoCrap.cx =	m_sizeROIBinned.cx%4 ? 
											m_sizeROIBinned.cx+(4-m_sizeROIBinned.cx%4) :
											m_sizeROIBinned.cx;
	m_sizeROIBinnedCorecoCrap.cy=m_sizeROIBinned.cy;
	OnZoomChange();

	if(m_wndTrace) m_wndTrace->UpdateInterFrameTime(*m_piTemporalBinning*(((CContImageApp*)AfxGetApp())->m_pFrameServer->m_dwInterFrameTimeUsec));

	OpenDevices();
	if(bRestart) OnStartGrabbing();

	SendMessage(WM_PAINT,0,0);
	SendMessage(WM_PAINT,0,0);

	return (LRESULT)TRUE;
}

LRESULT CContImageView::OnTemporalBinningChange(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnTemporalBinningChange");

	return (LRESULT)TRUE;
}

// X - bits 0 and 1, Y - bits 2 and 3. First bit - expand, second bit - shrink
BYTE CContImageView::FixEndPoints(int b,long xi,long yi,long xout,long yout,long *xf,long *yf){
	int e=(yi-xi+1)%b;
	int ex,ey;
	BYTE bReturnVal=0;

	*xf=xi;
	*yf=yi;
	if(e){
		if(e > b/2 || !((yi-xi+1)/b)){// Expand;
			e=b-e;
			ex=e/2;
			ey=e-ex;
			if(*xf-xout >= ex) *xf-=ex;
			else{
				ey+=ex-(*xf-xout);
				*xf=xout;
			}
			if(yout-*yf >= ey) *yf+=ey;
			else{
				ex=ey-(yout-*yf);
				*yf=yout;
				if(*xf-xout >= ex) *xf-=ex;
				else{
					PrintMessage("CContImageView::FixEndPoints: Cannot expand interval");
					bReturnVal=0xFF;
				}
			}
		}
		else{// Shrink;
			ex=e/2;
			ey=e-ex;
			*xf+=ex;
			*yf-=ey;
			if(*xf>=*yf){
				PrintMessage("CContImageView::FixEndPoints: Shrunk interval to nothing?");
			}
		}
	}
	if(*xf != xi){
		if(*xf < xi) bReturnVal |= 0x01;
		else bReturnVal |= 0x02;
	}
	if(*yf != yi){
		if(*yf > yi) bReturnVal |= 0x04;
		else bReturnVal |= 0x08;
	}
	return(bReturnVal);
}

void CContImageView::OnZoom(UINT nID){
	PrintMessage("CContImageView::OnZoom");
	switch(nID){
	case ID_ZOOM_8:
		m_zoomROIView=zoom8;
		m_fRawZoomX=m_fRawZoomY=8.0f;
		break;
	case ID_ZOOM_4:
		m_zoomROIView=zoom4;
		m_fRawZoomX=m_fRawZoomY=4.0f;
		break;
	case ID_ZOOM_2:
		m_zoomROIView=zoom2;
		m_fRawZoomX=m_fRawZoomY=2.0f;
		break;
	case ID_ZOOM_1:
		m_zoomROIView=zoom1;
		m_fRawZoomX=m_fRawZoomY=1.0f;
		break;
	case ID_ZOOM_05:
		m_zoomROIView=zoom05;
		m_fRawZoomX=m_fRawZoomY=0.5f;
		break;
	case ID_ZOOM_025:
		m_zoomROIView=zoom025;
		m_fRawZoomX=m_fRawZoomY=0.25f;
		break;
	case ID_ZOOM_0125:
		m_zoomROIView=zoom0125;
		m_fRawZoomX=m_fRawZoomY=0.125f;
		break;
	}
	RecreateObjects();
	OnZoomChange();
}

void CContImageView::OnZoomChange(){
	m_fZoomX=(float)(m_fRawZoomX*(*m_piSpatialBinningX));
	m_fZoomY=(float)(m_fRawZoomY*(*m_piSpatialBinningY));
	if(m_hImageDestination)	m_hImageDestination->SetZoom(m_fZoomX,m_fZoomY);
	
	ResizeROIView();
}

void CContImageView::RecreateObjects(){
	if(m_ppenROI) delete m_ppenROI;
	m_ppenROI = new CPen(PS_SOLID,(int)ceil(1.0/m_fRawZoomX),m_crROIRectColor);
	if(m_ppenSelect) delete m_ppenSelect;
	m_dwStyle[0]=m_dwStyle[1]=m_dwDragDrawRectSpacing*(int)ceil(1.0/m_fRawZoomX);
    m_ppenSelect = new CPen(PS_USERSTYLE|PS_GEOMETRIC, (int)ceil(1.0/m_fRawZoomX), &m_lb, 2, m_dwStyle);
	if(m_ppenSelectTransparent) delete m_ppenSelectTransparent;
	m_ppenSelectTransparent	= new CPen(PS_SOLID,(int)ceil(1.0/m_fRawZoomX),(COLORREF)0x00000000);
}

void CContImageView::ResizeROIView(){
	m_sizeROIView=CSize((int)(m_sizeROIBinned.cx*m_fZoomX),(int)(m_sizeROIBinned.cy*m_fZoomY));
	SetScrollSizes(MM_TEXT, m_sizeROIView);
	ResizeClientArea(m_sizeROIView.cx, m_sizeROIView.cy);
}

void CContImageView::OnUpdateZoom(CCmdUI* pCmdUI){
	switch(pCmdUI->m_nID){
	case ID_ZOOM_8:
		pCmdUI->SetCheck(m_zoomROIView == zoom8);
		break;
	case ID_ZOOM_4:
		pCmdUI->SetCheck(m_zoomROIView == zoom4);
		break;
	case ID_ZOOM_2:
		pCmdUI->SetCheck(m_zoomROIView == zoom2);
		break;
	case ID_ZOOM_1:
		pCmdUI->SetCheck(m_zoomROIView == zoom1);
		break;
	case ID_ZOOM_05:
		pCmdUI->SetCheck(m_zoomROIView == zoom05);
		break;
	case ID_ZOOM_025:
		pCmdUI->SetCheck(m_zoomROIView == zoom025);
		break;
	case ID_ZOOM_0125:
		pCmdUI->SetCheck(m_zoomROIView == zoom0125);
		break;
	}
}


void CContImageView::OnAcquireMiscCoordinates(){
	HWND hParentWnd = ::GetParent(m_hWnd); 

	RECT wr;

	PrintMessage(LEVEL_NORMAL,"CContImageView::OnAcquireMiscCoordinates");
	GetWindowRect(&wr);
	PrintMessage("View Window");
	PrintMessage(wr);		
		
	GetParent()->GetWindowRect(&wr);
	PrintMessage("View Parent Window");
	PrintMessage(wr);

	GetParentFrame()->GetWindowRect(&wr);
	PrintMessage("View Parent Frame Window");
	PrintMessage(wr);
		
	GetParentOwner()->GetWindowRect(&wr);	
	PrintMessage("View Parent Owner Window");
	PrintMessage(wr);

	::GetWindowRect(hParentWnd,&wr);
	PrintMessage("View Big Parent Window");
	PrintMessage(wr);


	PrintMessage(" ");
	
}

LRESULT CContImageView::OnStartGrabbing(WPARAM wp, LPARAM lp){

#ifndef _DEBUG_NO_CAMERA

	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	char str[128];
	int iSeqNum = -1;
	int iDataType = 0;
	SOFT_CHUNK *pSOFTChunk = NULL;
	PrintMessage("CContImageView::OnStartGrabbing");
	CheckModeConsistency("OnStartGrabbing");


	switch(m_dwServerDynamicMode){
	case SERVER_DYNAMIC_MODE_ROI:
	case SERVER_DYNAMIC_MODE_EXPERIMENT:
		if(!(theApp->m_pFrameServer->m_hGrabID)){
			PrintMessage(LEVEL_ERROR,"Grab handle is not ready");
			return((LRESULT)FALSE);
		}

		// Application non-specific initialization
		if(m_dwApplicationMode == APPLICATION_MODE_FOCUS || m_dwApplicationMode == APPLICATION_MODE_EXPERIMENT){
			if(!theApp->m_ulFileHeaderSize ){
				PrintMessage(LEVEL_ERROR,"File header size is not set");
				return((LRESULT)FALSE);
			}
			if(m_ulFileHeaderSize != theApp->m_ulFileHeaderSize){
				m_ulFileHeaderSize = theApp->m_ulFileHeaderSize;
				m_pFileHeader=realloc(m_pFileHeader,m_ulFileHeaderSize);
			}
			if(!theApp->m_pFileHeaderTemplate){
				PrintMessage(LEVEL_ERROR,"File header template is not set");
				return((LRESULT)FALSE);
			}
			memcpy(m_pFileHeader,theApp->m_pFileHeaderTemplate,m_ulFileHeaderSize);
			pSOFTChunk = (SOFT_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"SOFT");
			if(!pSOFTChunk){
				PrintMessage(LEVEL_ERROR,"File header template does not have SOFT chunk");
				return((LRESULT)FALSE);
			}
			pSOFTChunk->ThisFilename[FILENAME_POSITION_ROI] = NumberToChar(*m_piViewNumber); // Will be reset in SmartWrite
			pSOFTChunk->XSize = m_sizeROIBinned.cx;					//11 31 X size of stored frames 
			pSOFTChunk->YSize = m_sizeROIBinned.cy;					//12 32 Y size of stored frames
			pSOFTChunk->ROIXPosition = m_prectROI->left;			//15 35 X coordinate of upper-left conner of ROI (before binning)
			pSOFTChunk->ROIYPosition = m_prectROI->top;				//16 36 Y coordinate of upper-left conner of ROI (before binning)
			pSOFTChunk->ROIXSize = m_sizeROI.cx;					//17 37 X size of ROI (before binning) 
			pSOFTChunk->ROIYSize = m_sizeROI.cy;					//18 38 Y size of ROI (before binning) 
			pSOFTChunk->ROIXPositionAdjusted = m_rectROIBinning.left;//17 37 X coordinate of upper-left conner of adjusted ROI (before binning)
			pSOFTChunk->ROIYPositionAdjusted = m_rectROIBinning.top;//18 38 Y coordinate of upper-left conner of adjusted ROI (before binning)
			pSOFTChunk->ROINumber = *m_piViewNumber;				//19 39 Sequential ROI number. Set to 0 for main ROI

			m_ulFileSizeOffset=((ISOI_CHUNK *)m_pFileHeader)->Size;
			DATA_CHUNK *pDATAChunk = (DATA_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"DATA");
			m_ulDataSizeOffset=pDATAChunk->Size;
		}

		// Application specific initialization
		switch(m_dwApplicationMode){
		case APPLICATION_MODE_FOCUS:

			pSOFTChunk->NFramesTotal = 1;							//24 44 Expected number of frames 
			pSOFTChunk->NFramesThisFile = 1;						//25 45 Number of frames in this file

			m_bFocusThreadShutdown  = FALSE;
			m_dwFocusThreadID = 0;

			m_structFocusThreadParams.hMsgWnd = this->m_hWnd;
			m_structFocusThreadParams.pView = this;
			m_structFocusThreadParams.pCamera = theApp->m_pFrameServer->m_pCamera;
			m_structFocusThreadParams.hGrabID = theApp->m_pFrameServer->m_hGrabID;
			m_structFocusThreadParams.dwNFramesRingBuffer = theApp->m_pFrameServer->m_dwNFramesRingBuffer;
			m_structFocusThreadParams.pbShutdown = &m_bFocusThreadShutdown;
			m_structFocusThreadParams.dwInterFrameTimeUsec = theApp->m_pFrameServer->m_dwInterFrameTimeUsec;
			m_structFocusThreadParams.pbHistogram = &m_bHistogram;
			m_structFocusThreadParams.pulNBins = &m_ulNBins;
			m_structFocusThreadParams.ppulHistogram = &m_pulHistogram;
			m_structFocusThreadParams.pbTrace = &m_bTrace;
			m_structFocusThreadParams.pbTraceAverage = &m_bTraceAverage;
			m_structFocusThreadParams.pbDisplayFrames = &(theApp->m_iDisplayFrames);

			if((m_hFocusThread = CreateThread(NULL,(DWORD)0x10000,FocusThread,
				(LPVOID)&m_structFocusThreadParams,0x0,&m_dwFocusThreadID ))){
				m_bRunningFocus = TRUE;
			}
			else{
				sprintf(str,"Cannot start FocusThread GetLastError=%lu",GetLastError());
				PrintMessage(LEVEL_ERROR,str);
				return((LRESULT)FALSE);
			}
			break;
		case APPLICATION_MODE_EXPERIMENT:

			if(m_pLocalSaveBuffer){
				free(m_pLocalSaveBuffer);
				m_pLocalSaveBuffer=NULL;
			}

			iDataType = theApp->m_iDataType;
			m_dwLocalImageBufferSize = m_sizeROIBinned.cx*m_sizeROIBinned.cy*DataTypeToSizeOf(iDataType);
			m_dwLocalSaveBufferSize = m_dwLocalImageBufferSize+theApp->m_ulFrameHeaderSize;

			if(!(m_pLocalSaveBuffer=calloc(m_dwLocalSaveBufferSize,1))){
				PrintMessage(LEVEL_ERROR,"CContImageView::OnStartGrabbing: Cannot allocate for m_pLocalSaveBuffer");
				return FALSE;
			}
			m_pbLocalImageBuffer = (BYTE*)m_pLocalSaveBuffer + theApp->m_ulFrameHeaderSize;

			memset(m_strExperimentFileNames,0,m_iMaxNExperimentFiles*FILENAME_SIZE);
			memset(m_strExperimentFileNameTemplate,0,FILENAME_SIZE);
			m_iNExperimentFiles = 0;
			
			memcpy(m_strExperimentFileNameTemplate,theApp->m_strBaseFileName,strlen(theApp->m_strBaseFileName));
			m_strExperimentFileNameTemplate[FILENAME_POSITION_ROI]=NumberToChar(*m_piViewNumber);

			m_ulMaxNFramesInFile=(MAX_EXPERIMENT_FILE_SIZE-m_ulFileHeaderSize)/m_dwLocalSaveBufferSize;
			pSOFTChunk->NFramesThisFile = 
				m_ulMaxNFramesInFile < pSOFTChunk->NFramesTotal ? m_ulMaxNFramesInFile : pSOFTChunk->NFramesTotal;

			iSeqNum = theApp->m_pROI->GetSeqIndex(m_prectROI);

			m_piExperimentThreadShutdown = 
				&(theApp->m_pFrameServer->m_piOtherThreadsShutdown[iSeqNum]);

			m_dwExperimentThreadID = 0;

			m_structExperimentThreadParams.hMsgWnd = this->m_hWnd;
			m_structExperimentThreadParams.hMainWnd = AfxGetMainWnd()->m_hWnd;
			m_structExperimentThreadParams.pView = this;
			m_structExperimentThreadParams.iThreadSeqNum = iSeqNum;
			m_structExperimentThreadParams.piShutdown = m_piExperimentThreadShutdown;
			m_structExperimentThreadParams.phEvent = &(theApp->m_pFrameServer->m_phEvents[iSeqNum]);
			m_structExperimentThreadParams.pulFrameLockState = theApp->m_pFrameServer->m_pulFrameLockState;
			m_structExperimentThreadParams.dwNFramesRingBuffer = theApp->m_pFrameServer->m_dwNFramesRingBuffer;
			m_structExperimentThreadParams.ppbFrameBufferEntry = theApp->m_pFrameServer->m_ppbFrameBufferEntry;
			m_structExperimentThreadParams.ppbFrameHeaderBufferEntry = theApp->m_pFrameServer->m_ppbFrameHeaderBufferEntry;
			m_structExperimentThreadParams.pbDisplayFrames = &(theApp->m_iDisplayFrames);
			m_structExperimentThreadParams.iDataType = iDataType;
			m_structExperimentThreadParams.ulFrameHeaderSize = theApp->m_ulFrameHeaderSize;

			if((m_hExperimentThread = CreateThread(NULL,(DWORD)0x10000,ExperimentThread,
				(LPVOID)&m_structExperimentThreadParams,0x0,&m_dwExperimentThreadID ))){
				m_bRunningExperiment = TRUE;
			}
			else{
				sprintf(str,"Cannot start ExperimentThread GetLastError=%lu",GetLastError());
				PrintMessage(LEVEL_ERROR,str);
				return((LRESULT)FALSE);
			}
			break;
		default:
			sprintf(str,"CContImageView::OnStartGrabbing: Unknown Application Mode %i",m_dwApplicationMode);
			PrintMessage(LEVEL_ERROR,str);
			return FALSE;
		}
		break;
	case SERVER_DYNAMIC_MODE_FAST:
		if(m_hImageConnection){
			if (!m_hImageConnection->StartLiveImage(theApp->m_pFrameServer->m_pCamera, ICAP_INTR_VB)){
				PrintMessage(LEVEL_ERROR,"CContImageView::OnStartGrabbing Could not create VB interrupt driven live image");
				return((LRESULT)FALSE);
			}
		}
		else{
			PrintMessage(LEVEL_ERROR,"CContImageView::OnStartGrabbing m_hImageConnection is closed");
			return((LRESULT)FALSE);
		}
		m_bRunningFocus = TRUE;
		break;
	default:
		PrintMessage(LEVEL_ERROR,"CContImageView::OnStartGrabbing: Unknown Server Dynamic Mode");
		return FALSE;
	}


#endif // #ifndef _DEBUG_NO_CAMERA

	return((LRESULT)TRUE);
}

LRESULT CContImageView::OnStopGrabbing(WPARAM wp, LPARAM lp){
	char str[128];
	sprintf(str,"CContImageView::OnStopGrabbing %i",*m_piViewIndex);
	PrintMessage(str);
	CheckModeConsistency("OnStopGrabbing");
	if(!m_bRunningFocus && !m_bRunningExperiment){
		return((LRESULT)FALSE);
	}
	if(m_bRunningFocus && m_bRunningExperiment){
		PrintMessage(LEVEL_ERROR,"Running in both modes: Focus and Experiment");
	}
	if(m_bRunningFocus){
		m_bRunningFocus = FALSE;
		if(m_hFocusThread){ 
			if(!StopGenericThread(&m_hFocusThread,&m_bFocusThreadShutdown,m_dwFocusThreadID,"FocusThread")){
				PrintMessage(LEVEL_ERROR,"Failure to stop FocusThread");
				return((LRESULT)FALSE);
			}
		}
	}
	if(m_bRunningExperiment){
		m_bRunningExperiment = FALSE;
		if(m_hExperimentThread){ 
			if(!StopGenericThread(&m_hExperimentThread,m_piExperimentThreadShutdown,
				m_dwExperimentThreadID,"ExperimentThread",*m_structExperimentThreadParams.phEvent,(int)wp)){
				PrintMessage(LEVEL_ERROR,"Failure to stop ExperimentThread");
				return((LRESULT)FALSE);
			}
			if((int)lp){
				sprintf(str,"CContImageView::OnStopGrabbing CloseExperimentFile %i",(int)wp);
				PrintMessage(LEVEL_NORMAL,str);
				CloseExperimentFile(TRUE);
				if((int)wp == THREAD_SHUTDOWN_ABORT){
					PrintMessage(LEVEL_NORMAL,"CContImageView::OnStopGrabbing RemoveExperiemntFiles");
					RemoveExperiemntFiles();
				}
			}
			m_piExperimentThreadShutdown=NULL;
		}
	}
	return((LRESULT)TRUE);
}

LRESULT CContImageView::OnFocusThreadFinished(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnFocusThreadFinished");
	char str[128];
	sprintf(str,"OnFocusThreadFinished %i finished with Exit Code %i",(int)lp,(int)wp);
	PrintMessage(LEVEL_NORMAL,str);
	if(m_bRunningFocus){ 
		OnStopGrabbing();
	}
	return(LRESULT)TRUE;
}

LRESULT CContImageView::OnExperimentThreadFinished(WPARAM wp, LPARAM lp){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	PrintMessage("CContImageView::OnExperiemntThreadFinished");
	char str[128];
	sprintf(str,"OnExperimentThreadFinished %i finished with Exit Code %i",(int)lp,(int)wp);
	PrintMessage(LEVEL_NORMAL,str);
	if((int)lp == m_structExperimentThreadParams.iThreadSeqNum){ 
		if(m_bRunningExperiment) OnStopGrabbing();
		CloseExperimentFile(TRUE);
		if((int)wp == THREAD_SHUTDOWN_ABORT){
			RemoveExperiemntFiles();
		}
//		PrintMessage("Calling dequeuer");
//		theApp->m_pFrameServer->DequeThread((int)lp);
	}
	else{
		sprintf(str,"OnExperimentThreadFinished Message from %i",(int)lp);
		PrintMessage(LEVEL_NORMAL,str);
	}
	return(LRESULT)TRUE;
}

BOOL CContImageView::OpenDevices(){
	PrintMessage("CContImageView::OpenDevices");
	CheckModeConsistency("OpenDevices");
	return(ReopenDevices(TRUE));
}

BOOL CContImageView::CloseDevices(){
	PrintMessage("CContImageView::CloseDevices");
	return(ReopenDevices(FALSE));
}

BOOL CContImageView::ReopenDevices(BOOL bReopen){
#ifndef _DEBUG_NO_CAMERA

	CContImageApp *theApp = (CContImageApp*)AfxGetApp();

	if(m_pbLocalDisplayBuffer){
		free(m_pbLocalDisplayBuffer);
		m_pbLocalDisplayBuffer=NULL;
	}
	if(m_pulLocalStorageBuffer){
		free(m_pulLocalStorageBuffer);
		m_pulLocalStorageBuffer=NULL;
	}
	m_hImageDestination=NULL;
	if(m_hImageConnection){
		delete m_hImageConnection;
		m_hImageConnection=NULL;
	}

	if(m_bMainView){
		PrintMessage("CContImageView::ReopenDevices: Main buffer");
		if(m_hImageOverlay){
			delete m_hImageOverlay;
			m_hImageOverlay=NULL;
		}
		if(m_hImageDestinationTemplate){
			delete m_hImageDestinationTemplate;
			m_hImageDestinationTemplate=NULL;
		}
		if(m_hImageSource){
			delete m_hImageSource;
			m_hImageSource=NULL;
		}
		if(bReopen){
		if(m_dwServerDynamicMode == SERVER_DYNAMIC_MODE_FAST){
			PrintMessage(LEVEL_NORMAL,"CContImageView::ReopenDevices Creating live source");
			if(!(m_hImageSource = IfxCreateImgSrc(theApp->m_pFrameServer->m_pCamera))){
				PrintMessage(LEVEL_ERROR,"CFrameServer::ReopenDevices Failed to create frame source");
				return FALSE;
			}		
			if(!(m_hImageDestinationTemplate=IfxCreateImgSink(m_hWnd,DIB_SINK, 
				(WORD)0, (WORD)0, (WORD)m_sizeROIBinnedCorecoCrap.cx, (WORD)m_sizeROIBinnedCorecoCrap.cy ))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of destination DIB_SINK template failed");
				return FALSE;
			}
		
			if(!(m_hImageOverlay=IfxCreateOverlay(SW_OVERLAY, 
												(WORD)m_sizeROIBinnedCorecoCrap.cx, 
												(WORD)m_sizeROIBinnedCorecoCrap.cy))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of overlay failed");
				return FALSE;
			}
			
			if(!(m_hImageConnection=IfxCreateImgConn(m_hImageSource, m_hImageDestinationTemplate,m_hImageOverlay))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of connection failed");
				return FALSE;
			}

		}
		else{
			if(!AllocateLocalBuffers()){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices: Cannot allocate for Local Buffers");
				return FALSE;
			}
			if(!(m_hImageSource = IfxCreateImgSrc(m_pbLocalDisplayBuffer, 
												(WORD)m_sizeROIBinnedCorecoCrap.cx, 
												(WORD)m_sizeROIBinnedCorecoCrap.cy,
												(WORD)theApp->m_pFrameServer->m_CameraAttributes.dwBitsPerPixel))){
				PrintMessage(LEVEL_ERROR,"CFrameServer::ReopenDevices Failed to create frame source");
				return FALSE;
			}
			if(!(m_hImageDestinationTemplate=IfxCreateImgSink(m_hWnd,DIB_SINK, 
				(WORD)0, (WORD)0, (WORD)m_sizeROIBinnedCorecoCrap.cx, (WORD)m_sizeROIBinnedCorecoCrap.cy ))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of destination template failed");
				return FALSE;
			}
			if(!(m_hImageOverlay=IfxCreateOverlay(SW_OVERLAY, 
												(WORD)m_sizeROIBinnedCorecoCrap.cx, 
												(WORD)m_sizeROIBinnedCorecoCrap.cy))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of overlay failed");
				return FALSE;
			}		
			if(!(m_hImageConnection=IfxCreateImgConn(m_hImageSource, m_hImageDestinationTemplate,m_hImageOverlay))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of connection failed");
				return FALSE;
			}
			}
		}
	}
	else{
		PrintMessage("CContImageView::ReopenDevices: Sub buffer");
		m_hImageSource=NULL;
		if(bReopen){
		if(m_dwServerDynamicMode == SERVER_DYNAMIC_MODE_FAST){
			PrintMessage(LEVEL_NORMAL,"CContImageView::ReopenDevices Creating live source");
			if(!(m_hImageSource = IfxCreateImgSrc(theApp->m_pFrameServer->m_pCamera,
												  (WORD)m_prectROI->left, (WORD)m_prectROI->top,
												  (WORD)m_sizeROI.cx,(WORD)m_sizeROI.cy))){
				PrintMessage(LEVEL_ERROR,"CFrameServer::ReopenDevices Failed to create frame source");
				return FALSE;
			}			
			if(!(m_hImageDestinationTemplate=IfxCreateImgSink(m_hWnd,DIB_SINK, 
				(WORD)0, (WORD)0, (WORD)m_sizeROIBinnedCorecoCrap.cx, (WORD)m_sizeROIBinnedCorecoCrap.cy ))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of destination DIB_SINK template failed");
				return FALSE;
			}
			if(!(m_hImageConnection=IfxCreateImgConn(m_hImageSource, m_hImageDestinationTemplate))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of connection failed");
				return FALSE;
			}
		}
		else{
			if(!AllocateLocalBuffers()){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices: Cannot allocate for Local Buffers");
				return FALSE;
			}

			if(!(m_hImageConnection=IfxCreateImgConn(m_pbLocalDisplayBuffer, 
													(WORD)m_sizeROIBinnedCorecoCrap.cx, 
													(WORD)m_sizeROIBinnedCorecoCrap.cy,
													(WORD)theApp->m_pFrameServer->m_CameraAttributes.dwBitsPerPixel,
													m_hWnd))){
				PrintMessage(LEVEL_ERROR,"CContImageView::ReopenDevices Creation of connection failed");
				return FALSE;
			}
			m_hImageSource=m_hImageConnection->GetSrc();
			m_hImageSource->SetBufferAddr(m_pbLocalDisplayBuffer);
		}
		}
	}
	if(bReopen){
//		if(m_hImageDestination){
			m_hImageDestination=m_hImageConnection->GetSink();
			OnSwitchFocusMode(theApp->m_iFocusMode);
			m_hImageDestination->SetZoom(m_fZoomX,m_fZoomY);
//			m_hImageDestination->ResizeWindow();
//		}
	}

#endif  //  #ifndef _DEBUG_NO_CAMERA 

  return TRUE;
}

BOOL CContImageView::AllocateLocalBuffers(){
	m_dwLocalStorageBufferSize=m_sizeROIBinned.cx*m_sizeROIBinned.cy*sizeof(ULONG);
	if(!(m_pulLocalStorageBuffer=(ULONG *)calloc(m_dwLocalStorageBufferSize,1))){
		PrintMessage(LEVEL_ERROR,"CContImageView::AllocateLocalBuffers: Cannot allocate for m_pulLocalStorageBuffer");
		return FALSE;
	}
	m_dwLocalDisplayBufferSize=m_sizeROIBinnedCorecoCrap.cx*m_sizeROIBinnedCorecoCrap.cy*sizeof(USHORT);
	if(!(m_pbLocalDisplayBuffer=(BYTE *)calloc(m_dwLocalDisplayBufferSize,1))){
		PrintMessage(LEVEL_ERROR,"CContImageView::AllocateLocalBuffers: Cannot allocate for m_pbLocalDisplayBuffer");
		return FALSE;
	}
	return TRUE;
}

LRESULT CContImageView::OnRemovedSubROI(WPARAM wp, LPARAM){
	char str[64];
	sprintf(str,"CContImageView::OnRemovedSubROI %i",*m_piViewIndex);
	PrintMessage(str);
	if(*m_piViewIndex != (int)wp){
		if(*m_piViewIndex){
			*m_piViewIndex=((CContImageApp*)AfxGetApp())->m_pROI->GetIndex(m_prectROI);
			*m_piViewNumber=((CContImageApp*)AfxGetApp())->m_pROI->GetNumber(m_prectROI);
			sprintf(str,"SubROI %c",NumberToChar(*m_piViewNumber));
			GetDocument()->SetTitle(str);
		}
		else{
			SendMessage(WM_PAINT, 0, 0);
			SendMessage(WM_PAINT, 0, 0);
		}
	}
	return (LRESULT)*m_piViewIndex;
}


void CContImageView::OnDestroy(){
	CScrollView::OnDestroy();

	CloseDevices();

	if(m_wndTrace) m_wndTrace->SendMessage(WM_CLOSE);
	if(m_wndHistogram) delete m_wndHistogram;
	if(m_ppenSelectSimple) delete m_ppenSelectSimple;
	if(m_ppenSelect) delete m_ppenSelect;
	if(m_ppenSelectTransparent) delete m_ppenSelectTransparent;
	if(m_ppenROI) delete m_ppenROI;
	if(m_pbrushROIFill) delete m_pbrushROIFill;
}

BOOL CContImageView::DestroyWindow(){
	PrintMessage("CContImageView::DestroyWindow");
	
	return CScrollView::DestroyWindow();
}

void CContImageView::OnUpdateFileSave(CCmdUI* pCmdUI){
	pCmdUI->Enable((int)m_pbLocalDisplayBuffer);	
}

void CContImageView::OnFileSave(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	char strFileExtention[8];
	char strFileName[FILENAME_LENGHT_MAX];
	char strFullFileName[FILENAME_LENGHT_MAX];
	IMAGE_FILE* imgFile;
	BYTE *pbCorrectedImage,*pb;
	USHORT *pus,*pus1;
	DWORD_BYTE db;
	int iShift,i,j;
	struct _stat structFileStat;

	PrintMessage("CContImageView::OnFileSave");
	switch(theApp->m_iFocusFileSaveMode){
	case FOCUS_FILE_SAVE_MODE_JPG:
		strncpy(strFileExtention,"jpg",3);
		break;
	case FOCUS_FILE_SAVE_MODE_TIF:
		strncpy(strFileExtention,"tif",3);
		break;
	case FOCUS_FILE_SAVE_MODE_BMP:
		strncpy(strFileExtention,"bmp",3);
		break;
	default:
		sprintf(strFileName,"CContImageView::OnFileSave: Unknown focus file save mode %i",theApp->m_iFocusFileSaveMode);
		PrintMessage(LEVEL_ERROR,strFileName);
		return;
	}

	i=0;
	memset(strFileName,0,_MAX_FNAME+1);
	memcpy(strFileName,theApp->m_strBaseFileName,strlen(theApp->m_strBaseFileName));
	strFileName[FILENAME_POSITION_ROI]=NumberToChar(*m_piViewNumber);
	do{
		if(i==FILENAME_SCHEME_MAX){
			PrintMessage(LEVEL_ERROR,"CContImageView::OnFileSave: Cannot auto-save file, naming scheme failure");
			CFileDialog dlg(FALSE);
			dlg.m_ofn.lpstrInitialDir = theApp->m_strDataDirectory;
			dlg.m_ofn.lpstrFile = strFullFileName;
			if(dlg.DoModal() == IDOK) break;
			return;
		}
		strFileName[FILENAME_FOCUS_POSITION_OVERWRITE]=NumberToChar(i++);
		sprintf(strFullFileName,"%s%s.%s",theApp->m_strDataDirectory,strFileName,strFileExtention);
	} while (!(_stat(strFullFileName, &structFileStat)));
	PrintMessage("Saving green in");
	PrintMessage(strFullFileName);

	if(!(imgFile=IfxCreateImgFile(strFullFileName))){
		PrintMessage(LEVEL_ERROR,"Cannot create image file");
	}
	else{
		iShift=m_sizeROIBinnedCorecoCrap.cx-m_sizeROIBinned.cx;
		if(strFileName[0]=='G'){
			if(!(pbCorrectedImage=(BYTE*)malloc(m_sizeROIBinned.cx*m_sizeROIBinned.cy*2))){
				PrintMessage(LEVEL_ERROR,"CContImageView::OnFileSave: Cannot allocate for pbCorrectedImage");
				if(!imgFile->WriteFile(m_pbLocalDisplayBuffer,m_sizeROIBinnedCorecoCrap.cx,m_sizeROIBinnedCorecoCrap.cy,12,IFFCL_GRAY)){
					PrintMessage(LEVEL_ERROR,"Cannot write to file");
				}
			}
			else{
				for(j=0,pus=(USHORT*)m_pbLocalDisplayBuffer,pus1=(USHORT*)pbCorrectedImage;j<m_sizeROIBinned.cy;j++,pus+=iShift){
					for(i=0;i<m_sizeROIBinned.cx;i++,pus1++,pus++){
						*(pus1)=*(pus);
					}
				}

				if(m_bMainView){
					CROI* pCROI = theApp->m_pROI;
					for(ROI *pROI = pCROI->GetHeadROI();pROI;pROI=pCROI->GetNextROI(pROI)){
						OverlayRect(pbCorrectedImage,m_sizeROIBinned.cx,m_sizeROIBinned.cy,2,*(pROI->pRect));
					}
				}

				if(!imgFile->WriteFile(pbCorrectedImage,m_sizeROIBinned.cx,m_sizeROIBinned.cy,12,IFFCL_GRAY)){
					PrintMessage(LEVEL_ERROR,"Cannot write to file");
				}
				free(pbCorrectedImage);
			}
		}
		else{
			if(!(pbCorrectedImage=(BYTE*)malloc(m_sizeROIBinned.cx*m_sizeROIBinned.cy*3))){
				PrintMessage(LEVEL_ERROR,"CContImageView::OnFileSave: Cannot allocate for pbCorrectedImage");
				if(!imgFile->WriteFile(m_pbLocalDisplayBuffer,m_sizeROIBinnedCorecoCrap.cx,m_sizeROIBinnedCorecoCrap.cy,12,IFFCL_GRAY)){
					PrintMessage(LEVEL_ERROR,"Cannot write to file");
				}
			}
			else{
				for(j=0,pus=(USHORT*)m_pbLocalDisplayBuffer,pb=pbCorrectedImage;j<m_sizeROIBinned.cy;j++,pus+=iShift){
					for(i=0;i<m_sizeROIBinned.cx;i++,pb+=3,pus++){
						db.dw=exposureFunkyColors[*(pus)>>9];
						*(pb)	=db.str[2];
						*(pb+1)	=db.str[1];
						*(pb+2)	=db.str[0];
					}
				}

				if(m_bMainView){
					CROI* pCROI = theApp->m_pROI;
					for(ROI *pROI = pCROI->GetHeadROI();pROI;pROI=pCROI->GetNextROI(pROI)){
						OverlayRect(pbCorrectedImage,m_sizeROIBinned.cx,m_sizeROIBinned.cy,3,*(pROI->pRect));
					}
				}

				if(!imgFile->WriteFile(pbCorrectedImage,m_sizeROIBinned.cx,m_sizeROIBinned.cy,24,IFFCL_RGB)){
					PrintMessage(LEVEL_ERROR,"Cannot write to file");
				}
				free(pbCorrectedImage);
			}
		}
		delete imgFile;
	}
}

void CContImageView::OverlayRect(BYTE *pBuffer,ULONG cx,ULONG cy,int iBytes,CRect rect){
	int i;
	USHORT *pus;
	BYTE *pb;
	switch(iBytes){
	case 2:
		for(i=rect.left,pus=((USHORT*)pBuffer)+rect.left+rect.top*cx;i<=rect.right;i++,pus++) *pus=0;
		for(i=rect.left,pus=((USHORT*)pBuffer)+rect.left+rect.bottom*cx;i<=rect.right;i++,pus++) *pus=0;
		for(i=rect.top+1,pus=((USHORT*)pBuffer)+rect.left+(rect.top+1)*cx;i<rect.bottom;i++,pus+=cx) *pus=0;
		for(i=rect.top+1,pus=((USHORT*)pBuffer)+rect.right+(rect.top+1)*cx;i<rect.bottom;i++,pus+=cx) *pus=0;
		break;
	case 3:
		for(i=rect.left,pb=pBuffer+3*(rect.left+rect.top*cx);i<=rect.right;i++){
			*(pb++)^=0xff;*(pb++)^=0xff;*(pb++)^=0xff;
		}
		for(i=rect.left,pb=pBuffer+3*(rect.left+rect.bottom*cx);i<=rect.right;i++){
			*(pb++)^=0xff;*(pb++)^=0xff;*(pb++)^=0xff;
		}
		for(i=rect.top+1,pb=pBuffer+3*(rect.left+(rect.top+1)*cx);i<rect.bottom;i++,pb+=3*cx){
			*(pb)^=0xff;*(pb+1)^=0xff;*(pb+2)^=0xff;
		}
		for(i=rect.top+1,pb=pBuffer+3*(rect.right+(rect.top+1)*cx);i<rect.bottom;i++,pb+=3*cx){
			*(pb)^=0xff;*(pb+1)^=0xff;*(pb+2)^=0xff;
		}
		break;
	}
}

LRESULT CContImageView::OnSaveImageFile(WPARAM, LPARAM){
	OnFileSave();
	return(LRESULT)TRUE;
}

void CContImageView::OnUpdateSaveGreen(CCmdUI* pCmdUI){
	pCmdUI->Enable((int)m_pulLocalStorageBuffer);
}

LRESULT CContImageView::OnSaveGreen(WPARAM, LPARAM){
	PrintMessage("CContImageView::OnSaveGreen");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	char strFileName[FILENAME_LENGHT_MAX];
	char strFullFileName[FILENAME_LENGHT_MAX];
	char str[384];
	CChunk<ISOI_CHUNK>* pISOIChunk = new CChunk<ISOI_CHUNK>("ISOI","COIM");
	CChunk<DATA_CHUNK>* pDATAChunk = new CChunk<DATA_CHUNK>("DATA");
	CChunk<SOFT_CHUNK>* pSOFTChunk = new CChunk<SOFT_CHUNK>("SOFT",theApp->m_MultiChunk.CChunk<SOFT_CHUNK>::m_pChunk);
	CChunk<HARD_CHUNK>* pHARDChunk = new CChunk<HARD_CHUNK>("HARD",theApp->m_MultiChunk.CChunk<HARD_CHUNK>::m_pChunk);
	FILE *fp=NULL;
	ULONG ulBytesWritten=0;
	ULONG*	pulSrc;
	BYTE *pbLocalSaveBuffer=NULL;
	ULONG nLocalSaveBufferRecords=0;
	ULONG nLocalSaveBufferSize=0;
	ULONG nTotalBinning,nDivisor;
	struct _stat structFileStat;
	ULONG i;

	nLocalSaveBufferRecords=m_sizeROIBinned.cx*m_sizeROIBinned.cy;
	nLocalSaveBufferSize=nLocalSaveBufferRecords*pSOFTChunk->m_pChunk->SizeOfDataType;
	if(!(pbLocalSaveBuffer=(BYTE*)malloc(nLocalSaveBufferSize))){
		PrintMessage(LEVEL_ERROR,"CContImageView::OnSaveGreen: Cannot allocate for pbLocalSaveBuffer");
		goto bailout;
	}
	pulSrc=m_pulLocalStorageBuffer;

	nTotalBinning = pSOFTChunk->m_pChunk->TemporalBinning*
					pSOFTChunk->m_pChunk->SpatialBinningX*
					pSOFTChunk->m_pChunk->SpatialBinningY;
	switch(pSOFTChunk->m_pChunk->DataType){
	case DATATYPE_UCHAR:
		unsigned char*	pucDest;
		nDivisor=nTotalBinning*256;
		for(i=0,pucDest=(unsigned char*)pbLocalSaveBuffer;i<nLocalSaveBufferRecords;i++,pulSrc++,pucDest++)
			*pucDest=(unsigned char)((*pulSrc)/nDivisor);
		break;
	case DATATYPE_USHORT:
		USHORT*	pusDest;
		nDivisor=nTotalBinning > 16 ? nTotalBinning : 16;
		for(i=0,pusDest=(USHORT*)pbLocalSaveBuffer;i<nLocalSaveBufferRecords;i++,pulSrc++,pusDest++)
			*pusDest=(USHORT)((*pulSrc)/nDivisor);
		break;
	case DATATYPE_ULONG:
		ULONG*	pulDest;
		for(i=0,pulDest=(ULONG*)pbLocalSaveBuffer;i<nLocalSaveBufferRecords;i++,pulSrc++,pulDest++)
			*pulDest = (*pulSrc)>>4;
		break;
	case DATATYPE_FLOAT:
		FLOAT*	pfDest;
		for(i=0,pfDest=(FLOAT*)pbLocalSaveBuffer;i<nLocalSaveBufferRecords;i++,pulSrc++,pfDest++)
			*pfDest=(FLOAT)((*pulSrc)>>4);
		break;
	default:
		sprintf(str,"CContImageView::OnSaveGreen: Unknown data type %u",pSOFTChunk->m_pChunk->DataType);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}

	i=0;
	memset(strFileName,0,_MAX_FNAME+1);
	memcpy(strFileName,theApp->m_strBaseFileName,strlen(theApp->m_strBaseFileName));
	strFileName[FILENAME_POSITION_ROI]=NumberToChar(*m_piViewNumber);
	do{
		if(i==FILENAME_SCHEME_MAX){
			PrintMessage(LEVEL_ERROR,"CContImageView::OnSaveGreen: Cannot auto-save file, naming scheme failure");
			CFileDialog dlg(FALSE);
			dlg.m_ofn.lpstrInitialDir = theApp->m_strDataDirectory;
			dlg.m_ofn.lpstrFile = strFullFileName;
			if(dlg.DoModal() == IDOK){
				CString strTmpFileName = dlg.GetFileName();
				if(strTmpFileName.GetLength()>16){
					strncpy(strFileName,strTmpFileName.GetBuffer(0),16);
					sprintf(str,"Header file name record will be truncated from %s to %s ",strFileName,strTmpFileName.GetBuffer(0));
					PrintMessage(LEVEL_WARNING,str);
				}
				strncpy(strFileName,strTmpFileName.GetBuffer(0),strTmpFileName.GetLength()+1);
				break;
			}
			goto bailout;
		}
		strFileName[FILENAME_FOCUS_POSITION_OVERWRITE]=NumberToChar(i++);
		sprintf(strFullFileName,"%s%s",theApp->m_strDataDirectory,strFileName);
	} while (!(_stat(strFullFileName, &structFileStat)));
	sprintf(str,"Saving raw image in %s",strFullFileName);
	PrintMessage(LEVEL_NORMAL,str);

	strncpy(pSOFTChunk->m_pChunk->ThisFilename,strFileName,16);
	pSOFTChunk->m_pChunk->XSize = m_sizeROIBinned.cx;					//11 31 X size of stored frames 
	pSOFTChunk->m_pChunk->YSize = m_sizeROIBinned.cy;					//12 32 Y size of stored frames
	pSOFTChunk->m_pChunk->ROIXPosition = m_prectROI->left;				//15 35 X coordinate of upper-left conner of ROI (before binning)
	pSOFTChunk->m_pChunk->ROIYPosition = m_prectROI->top;				//16 36 Y coordinate of upper-left conner of ROI (before binning)
	pSOFTChunk->m_pChunk->ROIXSize = m_sizeROI.cx;						//17 37 X size of ROI (before binning) 
	pSOFTChunk->m_pChunk->ROIYSize = m_sizeROI.cy;						//18 38 Y size of ROI (before binning) 
	pSOFTChunk->m_pChunk->ROIXPositionAdjusted = m_rectROIBinning.left;	//17 37 X coordinate of upper-left conner of adjusted ROI (before binning)
	pSOFTChunk->m_pChunk->ROIYPositionAdjusted = m_rectROIBinning.top;	//18 38 Y coordinate of upper-left conner of adjusted ROI (before binning)
	pSOFTChunk->m_pChunk->ROINumber = *m_piViewNumber;					//19 39 ROI number. Set to 0 for main ROI
	pSOFTChunk->m_pChunk->NFramesTotal = 1;								//24 44 Expected number of frames 
	pSOFTChunk->m_pChunk->NFramesThisFile = 1;							//25 45 Number of frames in this file
	
	if(!(fp=fopen(strFullFileName,"wb"))){
		sprintf(str,"Cannot open file %s ",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}
	
	if(!pISOIChunk->WriteChunk(fp)) goto bailout;
	if(!pSOFTChunk->WriteChunk(fp,ulBytesWritten)) goto bailout;
	if(!pHARDChunk->WriteChunk(fp,ulBytesWritten)) goto bailout;
	pDATAChunk->m_pChunk->Size=nLocalSaveBufferSize;
	if(!pDATAChunk->WriteChunk(fp,ulBytesWritten)) goto bailout;
	if(fwrite(pbLocalSaveBuffer,nLocalSaveBufferSize,1,fp)!=1){
		sprintf(str,"Cannot write raw image to file %s ",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		goto bailout;
	}
	ulBytesWritten+=nLocalSaveBufferSize;

	if(m_bMainView && (theApp->m_pROI->GetCount()-1)){
		CChunk<ROIS_CHUNK>* pROISChunk = new CChunk<ROIS_CHUNK>("ROIS",theApp->m_MultiChunk.CChunk<ROIS_CHUNK>::m_pChunk);
		ROISRecord structROISRecord;

		if(!pROISChunk->WriteChunk(fp,ulBytesWritten)) goto bailout;
		pDATAChunk->m_pChunk->Size=sizeof(ROISRecord)*pROISChunk->m_pChunk->RecordCount;
		if(!pDATAChunk->WriteChunk(fp,ulBytesWritten)) goto bailout;
		CROI* pCROI = theApp->m_pROI;
		for(ROI *pROI = pCROI->GetHeadROI();pROI;pROI=pCROI->GetNextROI(pROI)){
			structROISRecord.iNumber= pROI->iNumber;
			structROISRecord.left	= pROI->pRect->left;
			structROISRecord.top	= pROI->pRect->top;
			structROISRecord.right	= pROI->pRect->right;
			structROISRecord.bottom	= pROI->pRect->bottom;
			if(fwrite(&structROISRecord,sizeof(ROISRecord),1,fp)!=1){
				sprintf(str,"Cannot write ROIS record to file %s ",strFullFileName);
				PrintMessage(LEVEL_ERROR,str);
				goto bailout;
			}
			ulBytesWritten+=sizeof(ROISRecord);
		}

		delete pROISChunk;
	}

	pISOIChunk->m_pChunk->Size+=ulBytesWritten;
	if(fseek(fp, 0L, SEEK_SET)){
		sprintf(str,"Fseek failed on %s ",strFullFileName);
		PrintMessage(LEVEL_ERROR,str);
		PrintMessage(LEVEL_ERROR,"Closing with old ISOI Chunk(not a big deal)");
		goto bailout;
	}
	if(!pISOIChunk->WriteChunk(fp)) goto bailout;
	sprintf(str,"Wrote %u+%u bytes",pISOIChunk->m_pChunk->Size,8);
	PrintMessage(LEVEL_NORMAL,str);

bailout:

	if(pbLocalSaveBuffer) free(pbLocalSaveBuffer);
	if(fp) fclose(fp);	
	delete pHARDChunk;
	delete pSOFTChunk;
	delete pISOIChunk;
	return(LRESULT)TRUE;
}

LRESULT CContImageView::OnSwitchFocusMode(WPARAM wp, LPARAM lp){
	if(m_hImageDestination){
		switch(wp){
		int i;
		case FOCUS_MODE_GREEN:
			for(i=0;i<256;i++) m_hImageDestination->SetRemapColor(i,i,RGB(i,i,i));
			Invalidate(FALSE);
			break;
		case FOCUS_MODE_EXPOSURE:
			for(i=0;i<NUM_EXPOSURE_FUNKY_COLORS;i++) m_hImageDestination->SetRemapColor(2*i,2*i+1,exposureFunkyColors[i]);
			CheckModeConsistency("OnSwitchFocusMode");
			if(m_dwServerDynamicMode == SERVER_DYNAMIC_MODE_FAST){
				m_hImageDestination->SetRemapColor(FIRST_COLOR_NOT_IGNORED_HW_REMAP,FIRST_COLOR_NOT_IGNORED_HW_REMAP,REMAP_COLOR_UNDERFLOW);
				m_hImageDestination->SetRemapColor(LAST_COLOR_NOT_IGNORED_HW_REMAP,LAST_COLOR_NOT_IGNORED_HW_REMAP,REMAP_COLOR_OVERFLOW);
			}
			Invalidate(FALSE);
			break;
		default:
			PrintMessage(LEVEL_ERROR,"CContImageView::OnSwitchFocusMode: Unknown mode");
			return(LRESULT)FALSE;
		}
	}
	return(LRESULT)TRUE;
}

LRESULT CContImageView::OnFillStorgeBuffer(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnFillStorgeBuffer");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	ROISRecord *pROI=(ROISRecord*)wp;
	ULONG *pulSrc=(ULONG*)lp;
	ULONG *pulDest=(ULONG*)m_pulLocalStorageBuffer;
	USHORT *pusDest=(USHORT*)m_pbLocalDisplayBuffer;
	ULONG ulDestShiftRecords,ulTotalBinning,ulSrcLine;
	int i,j;
	char str[128];
	sprintf(str,"Owner %i View %i",pROI->iNumber,theApp->m_pROI->GetNumber(m_prectROI));
	PrintMessage(str);
	if(!pulSrc){
		PrintMessage(LEVEL_WARNING,"Empty buffer");		
		return (LRESULT)FALSE;
	}
	if(*m_piViewNumber  || !pROI->iNumber){
		if(*m_piViewNumber == pROI->iNumber){
			PrintMessage(LEVEL_NORMAL,"Filling itself");
			memcpy(pulDest,pulSrc,m_dwLocalStorageBufferSize);
		}
		else{
			PrintMessage(LEVEL_NORMAL,"Filling other");
			ulSrcLine = pROI->right - pROI->left + 1;
			pulSrc+= m_rectROIBinning.left/(*m_piSpatialBinningX)+
					 (m_rectROIBinning.top/(*m_piSpatialBinningY))*ulSrcLine;
			i=m_sizeROIBinned.cx*sizeof(ULONG);
			for(j=0;j<m_sizeROIBinned.cy;j++,pulDest+=m_sizeROIBinned.cx,pulSrc+=ulSrcLine)	memcpy(pulDest,pulSrc,i);
		}
	
		ulDestShiftRecords = m_sizeROIBinnedCorecoCrap.cx - m_sizeROIBinned.cx;
		ulTotalBinning = *m_piSpatialBinningX* *m_piSpatialBinningY* *m_piTemporalBinning;
		pulSrc=m_pulLocalStorageBuffer;
		for(j=0;j<m_sizeROIBinned.cy;j++,pusDest+=ulDestShiftRecords){
			for(i=0;i<m_sizeROIBinned.cx;i++,pulSrc++,pusDest++){
				*pusDest=(USHORT)((*pulSrc)/ulTotalBinning);
			}
		}
	}
	SendMessage(WM_PAINT);
	SendMessage(WM_PAINT);
	return (LRESULT)TRUE;
}


int CContImageView::SmartWrite(void *pBuffer,ULONG ulBufferSize){
	char strFullFileName[FILENAME_LENGHT_MAX];
	char *pcThisFileName;
	SOFT_CHUNK *pSOFTChunk;
	int iError;
	size_t ulBytesWritten;
	char str[384];

	if(!m_iNExperimentFiles){
		m_ulNFramesInFile=0;
		if((iError=GenerateFileName(strFullFileName))){
			PrintMessage(LEVEL_ERROR,"SW: Cannot generate file name");
			return(iError);
		}

		if((m_fpExperimentFile = fopen(strFullFileName, "wb")) == NULL){
			sprintf(str,"SW: Cannot open file %s",strFullFileName);
			PrintMessage(LEVEL_ERROR,str);
			return(1);
		}

		sprintf(str,"SW: Opened Experiment file %i %s",m_iNExperimentFiles,strFullFileName);
		PrintMessage(LEVEL_NORMAL,str);

		if(!(pSOFTChunk = (SOFT_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"SOFT"))){
			PrintMessage(LEVEL_ERROR,"File header template does not have SOFT chunk");
			return(20);
		}
		pcThisFileName=m_strExperimentFileNames+m_iNExperimentFiles*FILENAME_SIZE;
		memcpy(pSOFTChunk->ThisFilename,pcThisFileName,FILENAME_SIZE); 

		m_iNExperimentFiles++;

		if(fwrite(m_pFileHeader,m_ulFileHeaderSize, 1, m_fpExperimentFile) != 1){ 
			sprintf(str,"SW: Cannot write FileHeader to %s",strFullFileName);
			PrintMessage(LEVEL_ERROR,str);
			fclose(m_fpExperimentFile);
			return(2);
		}							
	}

	if(m_ulNFramesInFile == m_ulMaxNFramesInFile){

		if((iError=GenerateFileName(strFullFileName))){
			PrintMessage(LEVEL_ERROR,"SW: Cannot generate file name");
			return(iError);
		}

		if((m_fpNextExperimentFile = fopen(strFullFileName, "wb")) == NULL){
			sprintf(str,"SW: Cannot open next file %s",strFullFileName);
			PrintMessage(LEVEL_ERROR,str);
			CloseExperimentFile(TRUE);
			return(1);
		}

		sprintf(str,"SW: Opened Next Experiment file %i %s",m_iNExperimentFiles,strFullFileName);
		PrintMessage(LEVEL_NORMAL,str);

		pcThisFileName=m_strExperimentFileNames+m_iNExperimentFiles*FILENAME_SIZE;

		if(CloseExperimentFile(FALSE)){
			PrintMessage(LEVEL_ERROR,"SW: Error closing Experiment File");
		}

		m_ulNFramesInFile=0;
		m_iNExperimentFiles++;

		m_fpExperimentFile=m_fpNextExperimentFile;

		// Fix new fileheader 
		if(!(pSOFTChunk = (SOFT_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"SOFT"))){
			PrintMessage(LEVEL_ERROR,"File header template does not have SOFT chunk");
			return(20);
		}
		memcpy(pSOFTChunk->PrevFilename,pcThisFileName-FILENAME_SIZE,FILENAME_SIZE);
		memcpy(pSOFTChunk->ThisFilename,pcThisFileName,FILENAME_SIZE); 
		memset(pSOFTChunk->NextFilename,0,FILENAME_SIZE);

		if(fwrite(m_pFileHeader, m_ulFileHeaderSize, 1, m_fpExperimentFile) != 1){ 
			sprintf(str,"SW: Cannot write filehead in ",pcThisFileName);
			PrintMessage(LEVEL_ERROR,str);
			return(6);
		}							
	}

    ulBytesWritten=fwrite(pBuffer,1,ulBufferSize,m_fpExperimentFile);
	if(ulBytesWritten!=ulBufferSize || ferror(m_fpExperimentFile)){
		sprintf(str,"SW: Cannot write buffer IO error (%lu/%lu)",ulBytesWritten,ulBufferSize);
		PrintMessage(LEVEL_ERROR,str);
		return(7);
	}

	m_ulNFramesInFile++;

	return(0);
}

int CContImageView::CloseExperimentFile(BOOL bLastFile){
	char *pcThisFileName;
	SOFT_CHUNK *pSOFTChunk;
	DATA_CHUNK *pDATAChunk;
	char str[128];

// TODOVal: Add trailing chunks here

	pcThisFileName=m_strExperimentFileNames+(m_iNExperimentFiles-1)*FILENAME_SIZE;

	if((pSOFTChunk = (SOFT_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"SOFT"))){
		if(!bLastFile) memcpy(pSOFTChunk->NextFilename,pcThisFileName+FILENAME_SIZE,FILENAME_SIZE); 
		pSOFTChunk->NFramesThisFile=m_ulNFramesInFile;
	}
	else{
		PrintMessage(LEVEL_ERROR,"CEF: File header template does not have SOFT chunk");
		PrintMessage(LEVEL_WARNING,"CEF: Closing as is");
	}

	if((pDATAChunk = (DATA_CHUNK *)FindChunk(m_pFileHeader,m_ulFileHeaderSize,"DATA"))){
		pDATAChunk->Size=m_ulDataSizeOffset+m_ulNFramesInFile*m_dwLocalSaveBufferSize;
	}
	else{
		PrintMessage(LEVEL_ERROR,"CEF: File header template does not have DATA chunk");
		PrintMessage(LEVEL_WARNING,"CEF: Closing as is");
	}

	((ISOI_CHUNK *)m_pFileHeader)->Size=m_ulFileSizeOffset+m_ulNFramesInFile*m_dwLocalSaveBufferSize;// TODOVal: Add size of trailing chunks here


	if(fseek(m_fpExperimentFile, 0L, SEEK_SET)){
		sprintf(str,"CEF: fseek failed on %s",pcThisFileName);
		PrintMessage(LEVEL_ERROR,str);
		PrintMessage(LEVEL_WARNING,"CEF: Closing with old fileheader");
	}
	else{
		if(fwrite(m_pFileHeader, m_ulFileHeaderSize, 1, m_fpExperimentFile) != 1){ 
			sprintf(str,"CEF: Cannot rewrite filehead in %s",pcThisFileName);
			PrintMessage(LEVEL_ERROR,str);
			PrintMessage(LEVEL_WARNING,"CEF: Closing with old or/and undefined fileheader");
		}							
	}
	if(fclose(m_fpExperimentFile)){
		sprintf(str,"CEF: Cannot close file %s",pcThisFileName);
		PrintMessage(LEVEL_ERROR,str);
	}
	else{
		sprintf(str,"CEF: Closed %s",pcThisFileName);
		PrintMessage(LEVEL_NORMAL,str);
	}

	if(bLastFile){
		m_ulNFramesInFile=0;
		m_fpExperimentFile=m_fpNextExperimentFile=NULL;
	}
	return(0);
}

int CContImageView::RemoveExperiemntFiles(){
	char *pcDirectoryName=((CContImageApp*)AfxGetApp())->m_strDataDirectory.GetBuffer(0);
	char strFullFileName[FILENAME_LENGHT_MAX];
	int i,iError=0;
	char str[384];

	for(i=0;i<m_iNExperimentFiles;i++){
		strcpy(strFullFileName,pcDirectoryName);
		strcat(strFullFileName,m_strExperimentFileNames+i*FILENAME_SIZE);
		if(remove(strFullFileName)==-1){
			iError++;
			sprintf(str,"REF: Cannot remove file %i %s errno = %i",i,strFullFileName,errno);
			PrintMessage(LEVEL_ERROR,str);
		}
		else{
			sprintf(str,"REF: Removed file %s",strFullFileName);
			PrintMessage(LEVEL_NORMAL,str);
		}
	}
	m_iNExperimentFiles=0;
	return(iError);
}


int CContImageView::GenerateFileName(char *pcFileName){
	char *pcCurrentFileName;
	char *pcDirectoryName=((CContImageApp*)AfxGetApp())->m_strDataDirectory.GetBuffer(0);
	ULONG ulDirectoryNameSize;
	SOFT_CHUNK *pSOFTChunk = NULL;
	int i,j;
	struct _stat structFileStat;

	if(m_iNExperimentFiles==m_iMaxNExperimentFiles){
		m_iMaxNExperimentFiles+=FILENAME_SCHEME_MAX;
		if(!(m_strExperimentFileNames = (char*)realloc(m_strExperimentFileNames,m_iMaxNExperimentFiles*FILENAME_SIZE))){
			PrintMessage(LEVEL_ERROR,"GFN: Cannot realloc for m_strExperimentFileNames");
			return(9);
		}
	}

	pcCurrentFileName=m_strExperimentFileNames+m_iNExperimentFiles*FILENAME_SIZE;
//	memcpy(pcCurrentFileName,m_strExperimentFileNameTemplate,strlen(m_strExperimentFileNameTemplate));
	memcpy(pcCurrentFileName,m_strExperimentFileNameTemplate,FILENAME_SIZE);
	pcCurrentFileName[FILENAME_EXPERIMENT_POSITION_FILE]=NumberToChar(m_iNExperimentFiles%FILENAME_SCHEME_MAX);
	memset(pcFileName,0,FILENAME_LENGHT_MAX);
	strcpy(pcFileName,pcDirectoryName);
	strcat(pcFileName,pcCurrentFileName);
	ulDirectoryNameSize=strlen(pcDirectoryName);
	i=j=0;
	while (!(_stat(pcFileName, &structFileStat))){
		if(i==FILENAME_SCHEME_MAX){
			i=0;
			if(j==FILENAME_SCHEME_MAX){
				PrintMessage(LEVEL_ERROR,"GFN: Cannot auto-save file, double naming scheme failure");
				return(10);
			}
			pcCurrentFileName[FILENAME_EXPERIMENT_POSITION_OVERWRITE_EXTRA]=
			pcFileName[ulDirectoryNameSize+FILENAME_EXPERIMENT_POSITION_OVERWRITE_EXTRA]=NumberToChar(j++);
			PrintMessage(LEVEL_WARNING,"GFN: Added extra char to Experiment filename");
		}
		pcCurrentFileName[FILENAME_EXPERIMENT_POSITION_OVERWRITE]=
		pcFileName[ulDirectoryNameSize+FILENAME_EXPERIMENT_POSITION_OVERWRITE]=NumberToChar(i++);
	}
//	char str[512];
//	sprintf(str,"GFN %s %i %i",pcCurrentFileName,i,j);
//	sprintf(str,"GFN %s %i %i",pcFileName,i,j);
//	PrintMessage(str);

	return(0);
}

void CContImageView::OnAcquireSourceProperties(){
	char str[256];
	char *strSourceKinds[5]={"NONE_SRC","CAMERA_SRC","HOST_BUFFER_SRC","IMAGE_SRC","LAST_SRC"};

	sprintf(str,"Source Size: X=%i Y=%i",m_sizeROI.cx,m_sizeROI.cy);
	PrintMessage(str);
	sprintf(str,"Source Binned Size: X=%i Y=%i",m_sizeROIBinned.cx,m_sizeROIBinned.cy);
	PrintMessage(str);
	sprintf(str,"Source Binning: X=%i Y=%i T=%i",*m_piSpatialBinningX,*m_piSpatialBinningY,*m_piTemporalBinning);
	PrintMessage(str);
	if(m_hImageSource){
		sprintf(str,"Source: %#x",m_hImageSource);
		PrintMessage(str);
		sprintf(str,"Source Frame Size: X=%i Y=%i",m_hImageSource->FrameWidth(),m_hImageSource->FrameHeight());
		PrintMessage(str);
		sprintf(str,"Source Size: X=%i Y=%i",m_hImageSource->GetWidth(),m_hImageSource->GetHeight());
		PrintMessage(str);
		sprintf(str,"Source Position: X=%i Y=%i",m_hImageSource->GetAoiStartX(),m_hImageSource->GetAoiStartY());
		PrintMessage(str);
		sprintf(str,"Source Bits Per Pixel: %i",m_hImageSource->GetBitsPP());
		PrintMessage(str);
		sprintf(str,"Source Line Pitch: %i",m_hImageSource->GetLinePitch());
		PrintMessage(str);
		sprintf(str,"Source Source Type: %i %s",m_hImageSource->GetKind(),strSourceKinds[m_hImageSource->GetKind()]);
		PrintMessage(str);
		sprintf(str,"Source Buffer Address: %#x",m_hImageSource->GetBufferAddr());
		PrintMessage(str);
	}
	else{
		PrintMessage("Image Source is not available");
	}
}

void CContImageView::OnAcquireDestinationProperties(){
	char str[256];
	char *strDestianationKinds[]={"NONE_SINK","DIB_SINK","DDRAW_SINK","YCRCB_SINK","IMAGE_SINK","LAST_SINK"};

	sprintf(str,"Destination Size: X=%u Y=%u",m_sizeROIView.cx,m_sizeROIView.cy);
	PrintMessage(str);
	sprintf(str,"Destination Zoom: X=%f Y=%f",m_fZoomX,m_fZoomY);
	PrintMessage(str);
	sprintf(str,"Destination Raw Zoom: X=%f Y=%f",m_fRawZoomX,m_fRawZoomY);
	PrintMessage(str);
	if(m_hImageDestination){
		sprintf(str,"Destination: %#x",m_hImageDestination);
		PrintMessage(str);
		sprintf(str,"Destination Size: X=%u Y=%u",m_hImageDestination->GetWidth(),m_hImageDestination->GetHeight());
		PrintMessage(str);
		sprintf(str,"Destination Position: X=%u Y=%u",m_hImageDestination->GetAoiStartX(),m_hImageDestination->GetAoiStartY());
		PrintMessage(str);
		sprintf(str,"Destination Bits Per Pixel: %u",m_hImageDestination->GetBitsPP());
		PrintMessage(str);
		sprintf(str,"Destination Line Pitch: %u",m_hImageDestination->GetLinePitch());
		PrintMessage(str);
		sprintf(str,"Destination Type: %i %s",m_hImageDestination->GetKind(),strDestianationKinds[m_hImageDestination->GetKind()]);
		PrintMessage(str);
		sprintf(str,"Destination Color Key: %#x",m_hImageDestination->GetDestColorKey());
		PrintMessage(str);
		sprintf(str,"Destination Strech: Min=%u Max=%u",m_hImageDestination->GetMinStretch(),m_hImageDestination->GetMaxStretch());
		PrintMessage(str);
		double x,y;
		m_hImageDestination->GetZoom(&x,&y);
		sprintf(str,"Destination Zoom: X=%f Y=%f",x,y);
		PrintMessage(str);
	}
	else{
		PrintMessage("Destination Source is not available");
	}
}

void CContImageView::OnAcquireConnectionProperties(){
	char str[256];
	char *strOverlayKinds[3]={"NONE_OVERLAY","SW_OVERLAY","HW_OVERLAY"};
	if(m_hImageConnection){
		sprintf(str,"Connection: %#x",m_hImageConnection);
		PrintMessage(str);
		sprintf(str,"Connection Source: %#x",m_hImageConnection->GetSrc());
		PrintMessage(str);
		sprintf(str,"Connection Destination: %#x",m_hImageConnection->GetSink());
		PrintMessage(str);
		sprintf(str,"Connection Speed FPS: %f",m_hImageConnection->GetLiveImageFPS());
		PrintMessage(str);
		if(m_hImageConnection->GetOverlay()){
			sprintf(str,"Connection Overlay: %#x",m_hImageConnection->GetOverlay());
			PrintMessage(str);
			sprintf(str,"Connection Overlay Size: X=%u Y=%u",m_hImageConnection->GetOverlayWidth(),m_hImageConnection->GetOverlayHeight());
			PrintMessage(str);
			sprintf(str,"Connection Overlay Bits Per Pixel: %u",m_hImageConnection->GetOverlayBitsPP());
			PrintMessage(str);
			sprintf(str,"Connection Overlay Type: %i %s",m_hImageConnection->GetOverlayKind(),strOverlayKinds[m_hImageConnection->GetOverlayKind()]);
			PrintMessage(str);
			sprintf(str,"Connection Overlay Strech: Min=%u Max=%u",m_hImageConnection->GetOverlayMinStretch(),m_hImageConnection->GetOverlayMaxStretch());
			PrintMessage(str);
		}
		else{
			PrintMessage("Connection Overlay is not available");
		}
	}
	else{
		PrintMessage("Connection Source is not available");
	}
	sprintf(str,"Histogram %p",m_wndHistogram);
	PrintMessage(str);
}



void CContImageView::OnToolHistogram(){
	if(!m_wndHistogram){
		HBRUSH brushHistogram = CreateSolidBrush(0xff0000); 
		LPCTSTR lpszClassName = AfxRegisterWndClass(CS_CLASSDC,LoadCursor(NULL,IDC_CROSS),
			brushHistogram,LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_HISTOGRAM)));

		if(!(m_wndHistogram = new CHistogram)){
			PrintMessage(LEVEL_ERROR,"Cannot create CHistogram");
			return;
		}

		RECT r;
		GetWindowRect(&r);

		if(!m_wndHistogram->Create((int)NumberToChar(*m_piViewNumber), r.left,r.top,256,256,this->m_hWnd,lpszClassName,"Histogram")){
			PrintMessage(LEVEL_ERROR,"Cannot create Histogram window");
			TRACE0("Failed to create Histogram\n");
			return;	
		}
		m_wndHistogram->CreateHistogramBitmap();
		m_wndHistogram->ShowWindow(SW_SHOW);
		m_wndHistogram->UpdateWindow();
		m_bHistogram=TRUE;
		PrintMessage(LEVEL_NORMAL,"Created Histogram window");
	}
	else{
		m_bHistogram=FALSE;
		m_wndHistogram->SendMessage(WM_CLOSE);
		m_wndHistogram=NULL;
	}
}

void CContImageView::OnUpdateToolHistogram(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(m_wndHistogram!=NULL);
}

LRESULT CContImageView::OnHistogramDestroy(WPARAM wp,LPARAM lp){
	m_wndHistogram=NULL;
	m_bHistogram=FALSE;
	return(0);
}

LRESULT CContImageView::OnUpdateHistogram(WPARAM wp,LPARAM lp){
	if(m_wndHistogram) m_wndHistogram->UpdateHistogram(m_ulNBins,m_pulHistogram,
										FIRST_COLOR_NOT_IGNORED_SW_REMAP,LAST_COLOR_NOT_IGNORED_SW_REMAP);
	return(0);
}


void CContImageView::OnToolTrace(){
	if(!m_wndTrace){
		HBRUSH brushHistogram = CreateSolidBrush(0xff0000); 
		LPCTSTR lpszClassName = AfxRegisterWndClass(CS_CLASSDC,LoadCursor(NULL,IDC_CROSS),
			brushHistogram,LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_TRACE)));

		if(!(m_wndTrace = new CTrace(*m_piTemporalBinning*(((CContImageApp*)AfxGetApp())->m_pFrameServer->m_dwInterFrameTimeUsec)))){
			PrintMessage(LEVEL_ERROR,"Cannot create CTrace");
			return;
		}

		RECT r;
		GetWindowRect(&r);

		if(!m_wndTrace->Create((int)NumberToChar(*m_piViewNumber), r.left,r.top,400,150,this->m_hWnd,lpszClassName,"Trace")){
			PrintMessage(LEVEL_ERROR,"Cannot create Histogram window");
			TRACE0("Failed to create Histogram\n");
			return;	
		}
		m_wndTrace->CreateTraceBitmap();
		m_wndTrace->ShowWindow(SW_SHOW);
		m_wndTrace->UpdateWindow();
		m_bTrace=TRUE;
		PrintMessage(LEVEL_NORMAL,"Created Trace window");
	}
	else{
		m_bTrace=FALSE;
		m_wndTrace->SendMessage(WM_CLOSE);
		m_wndTrace=NULL;
	}
}

void CContImageView::OnUpdateToolTrace(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(m_wndTrace!=NULL);
}

LRESULT CContImageView::OnTraceDestroy(WPARAM wp,LPARAM lp){
	m_wndTrace=NULL;
	m_bTrace=FALSE;
	m_iLastPixel=-1;
	memset(m_plPixelCord,0,sizeof(long)*TRACE_MAX_NTRACES);
	m_ulNTraces = 0;
	return(0);
}

LRESULT CContImageView::OnUpdateTrace(WPARAM wp,LPARAM lp){
//	ULONG ul=(ULONG)lp;
//	ul=(ULONG)(1000.0*(2.0-sin(0.05*(ULONG)wp)));
	if(m_ulNTraces){
		for(ULONG i=0;i<m_ulNTraces;i++){
			if(m_plPixelCord[i]<0){ 
				if(m_bTraceAverage) m_pulPixelVal[i]=(ULONG)lp;
			}
			else{
				m_pulPixelVal[i]=m_pulLocalStorageBuffer[m_plPixelCord[i]]>>4;
			}
		}
		if(m_wndTrace) m_wndTrace->UpdateTrace(m_ulNTraces,m_pulPixelVal,(ULONG)wp,0);
	}
	return(0);
}

void CContImageView::OnAddTrace(){
	CTraceDlg dlg;
	dlg.m_strTitle="Add Trace";
	dlg.m_nTraceX=0;
	dlg.m_nTraceY=0;
	dlg.m_nTraceMaxX=m_sizeROIBinned.cx-1;
	dlg.m_nTraceMaxY=m_sizeROIBinned.cy-1;
	if(dlg.DoModal()==IDOK){
		OnAddTrace(dlg.m_nTraceX+dlg.m_nTraceY*m_sizeROIBinned.cx);
	}
}

void CContImageView::OnAddTrace(long lPixel){
	char str[64];
	if(lPixel<0 || lPixel>=m_sizeROIBinned.cx*m_sizeROIBinned.cy){
		sprintf(str,"Pixel out of bound %i",lPixel);
		PrintMessage(LEVEL_ERROR,str);
		return;
	}
	m_iLastPixel=(m_iLastPixel+1)%TRACE_MAX_NTRACES;
	sprintf(str,"OnAddTrace N %lu Last %i",m_ulNTraces,m_iLastPixel);
	PrintMessage(LEVEL_NORMAL,str);
	if(m_plPixelCord[m_iLastPixel]<0 && m_iLastPixel != (int)m_ulNTraces) m_bTraceAverage=FALSE;
	m_plPixelCord[m_iLastPixel]=lPixel;
	m_ulNTraces = m_ulNTraces+1 < TRACE_MAX_NTRACES ? m_ulNTraces+1 : TRACE_MAX_NTRACES;

	sprintf(str,"Trace N %lu Last %i Coord %i",m_ulNTraces,m_iLastPixel,m_plPixelCord[m_iLastPixel]);
	PrintMessage(LEVEL_NORMAL,str);
	sprintf(str,"%i %i",m_plPixelCord[m_iLastPixel]%m_sizeROIBinned.cx,m_plPixelCord[m_iLastPixel]/m_sizeROIBinned.cx);
	m_wndTrace->AddTrace(str);
}

void CContImageView::OnAddAvarageTrace(){
	char str[64];
	if(m_wndTrace && !m_bTraceAverage){
		m_bTraceAverage = TRUE;

		m_iLastPixel=(m_iLastPixel+1)%TRACE_MAX_NTRACES;
		m_plPixelCord[m_iLastPixel]=-1;
		m_ulNTraces = m_ulNTraces+1 < TRACE_MAX_NTRACES ? m_ulNTraces+1 : TRACE_MAX_NTRACES;

		sprintf(str,"AvarageTrace N %lu Last %i Coord %i",m_ulNTraces,m_iLastPixel,m_plPixelCord[m_iLastPixel]);
		PrintMessage(LEVEL_NORMAL,str);
		m_wndTrace->AddTrace("Average");
	}
}

void CContImageView::OnRemoveTrace(UINT nID){
	char str[128];
	UINT n=nID-ID_TRACE_REMOVE0;
	if(m_ulNTraces){
		if(m_plPixelCord[n]<0) m_bTraceAverage=FALSE;
		if(m_wndTrace) m_wndTrace->RemoveTrace(n);
		for(UINT i=n+1;i<m_ulNTraces;i++) m_plPixelCord[i-1]=m_plPixelCord[i];
		m_ulNTraces--;
		m_iLastPixel=(int)m_ulNTraces-1;
	}
	sprintf(str,"CContImageView::OnRemoveTrace N %lu Last %i",n,m_iLastPixel);
	PrintMessage(str);
}

void CContImageView::RemoveAllTraces(){
	if(m_wndTrace){
		int j=m_ulNTraces;
		for(int i=0;i<j;i++) OnRemoveTrace(ID_TRACE_REMOVE0);
		m_wndTrace->UpdateTrace(0,NULL,0,0);
	}
}


void CContImageView::OnSubstituteTrace(UINT nID){
	char str[128];
	UINT n=nID-ID_TRACE_SUBSTITUTE0;
	if(m_ulNTraces){
		CTraceDlg dlg;
		if(m_plPixelCord[n]<0){
			dlg.m_nTraceX=0;
			dlg.m_nTraceY=0;
		}
		else{
			dlg.m_nTraceX=m_plPixelCord[n]%m_sizeROIBinned.cx;
			dlg.m_nTraceY=m_plPixelCord[n]/m_sizeROIBinned.cx;
		}

		dlg.m_strTitle="Substitute Trace";
		dlg.m_nTraceMaxX=m_sizeROIBinned.cx-1;
		dlg.m_nTraceMaxY=m_sizeROIBinned.cy-1;
		if(dlg.DoModal()==IDOK){
			long lPixel=dlg.m_nTraceX+dlg.m_nTraceY*m_sizeROIBinned.cx;

			if(m_plPixelCord[n]<0) m_bTraceAverage=FALSE;
			m_plPixelCord[n]=lPixel;
			sprintf(str,"%i %i",dlg.m_nTraceX,dlg.m_nTraceY);
			if(m_wndTrace) m_wndTrace->SubstituteTrace(n,str);
			m_iLastPixel=(int)n;
		}
	}
	sprintf(str,"CContImageView::OnSubstituteTrace N %lu Last %i",n,m_iLastPixel);
	PrintMessage(str);
}

void CContImageView::OnShowPixel(UINT nID){
	int iX,iY;
	UINT n=nID-ID_TRACE_SHOW0;
	CPoint point=GetScrollPosition();
	RECT rectW,rectC;
	GetWindowRect(&rectW);
	GetClientRect(&rectC);
	iX=(int)((m_plPixelCord[n]%m_sizeROIBinned.cx)*m_fZoomX)-point.x+(rectW.right+rectW.left-rectC.right)/2;
	iY=(int)((m_plPixelCord[n]/m_sizeROIBinned.cx)*m_fZoomY)-point.y+(rectW.bottom+rectW.top-rectC.bottom)/2;
	SetCursorPos(iX,iY);
}


void CContImageView::OnContextMenu(CWnd* pWnd, CPoint point){
	char str[128];
	ULONG i;
    int iMenuItem = 0;
	if(!m_bTrace) return;

	SetFocus();
    CMenu menu;
    menu.CreatePopupMenu();

	if(m_ulNTraces!=TRACE_MAX_NTRACES)
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION, ID_TRACE_ADD, _T("&Add"));
	if(!m_bTraceAverage)
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION, ID_TRACE_ADD_AVERAGE, _T("Add Average"));

	if(m_ulNTraces){
		CMenu subMenuSubstitute;
		subMenuSubstitute.CreatePopupMenu();
		for(i=0;i<m_ulNTraces;i++){
			if(m_plPixelCord[i]<0){
				if(m_bTraceAverage) sprintf(str,"Average");
				else sprintf(str,"Negative, Not Average");
			}
			else{ 
				sprintf(str,"%i %i",m_plPixelCord[i]%m_sizeROIBinned.cx,m_plPixelCord[i]/m_sizeROIBinned.cx);
			}
			subMenuSubstitute.InsertMenu(i, MF_BYPOSITION, ID_TRACE_SUBSTITUTE0+i, _T(str));
		}
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION | MF_POPUP, (UINT)subMenuSubstitute.m_hMenu, _T("&Substitute"));

		CMenu subMenuRemove;
		subMenuRemove.CreatePopupMenu();
		for(i=0;i<m_ulNTraces;i++){
			if(m_plPixelCord[i]<0){
				if(m_bTraceAverage) sprintf(str,"Average");
				else sprintf(str,"Negative, Not Average");
			}
			else{
				sprintf(str,"%i %i",m_plPixelCord[i]%m_sizeROIBinned.cx,m_plPixelCord[i]/m_sizeROIBinned.cx);
			}
			subMenuRemove.InsertMenu(i, MF_BYPOSITION, ID_TRACE_REMOVE0+i, _T(str));
		}
		menu.InsertMenu(iMenuItem++, MF_BYPOSITION | MF_POPUP, (UINT)subMenuRemove.m_hMenu, _T("&Remove"));

		CMenu subMenuShow;
		subMenuShow.CreatePopupMenu();
		int j=0;
		for(i=0;i<m_ulNTraces;i++){
			if(m_plPixelCord[i]>=0){
				j++;
				sprintf(str,"%i %i",m_plPixelCord[i]%m_sizeROIBinned.cx,m_plPixelCord[i]/m_sizeROIBinned.cx);
				subMenuShow.InsertMenu(i, MF_BYPOSITION, ID_TRACE_SHOW0+i, _T(str));
			}
		}
		if(j) menu.InsertMenu(iMenuItem++, MF_BYPOSITION | MF_POPUP, (UINT)subMenuShow.m_hMenu, _T("&Show"));
	}

	menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
}

BOOL CContImageView::CheckModeConsistency(char *strCall){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	char str[128];
	BOOL bResult;
	if((int)m_dwServerDynamicMode != theApp->m_iServerDynamicMode){
		bResult = FALSE;
		sprintf(str,"%s Server Mode incosistent: Local %i Global %i",strCall,m_dwServerDynamicMode,theApp->m_iServerDynamicMode);
		PrintMessage(LEVEL_ERROR,str);
	}
	if((int)m_dwApplicationMode != theApp->m_iApplicationMode){
		bResult = FALSE;
		sprintf(str,"%s Application Mode incosistent: Local %i Global %i",strCall,m_dwApplicationMode,theApp->m_iApplicationMode);
		PrintMessage(LEVEL_ERROR,str);
	}
	return(bResult);
}

LRESULT CContImageView::OnChangeModes(WPARAM wp, LPARAM lp){
	PrintMessage("CContImageView::OnChangeModes");
	if(m_dwServerDynamicMode == (DWORD)wp && m_dwApplicationMode == (DWORD)lp){
		PrintMessage(LEVEL_WARNING,"Modes had been set");		
		return((LRESULT)FALSE);
	}
	if(m_bRunningExperiment){
		PrintMessage(LEVEL_ERROR,"Cannot changes modes: running experiment");
		return((LRESULT)FALSE);
	}

	BOOL bRestart=FALSE;
	if(m_bRunningFocus){
		bRestart=TRUE;
		OnStopGrabbing();
	}
	CloseDevices();

	m_dwServerDynamicMode = (DWORD)wp;
	m_dwApplicationMode = (DWORD)lp;

	OpenDevices();
	if(bRestart) OnStartGrabbing();
	return((LRESULT)TRUE);
}

