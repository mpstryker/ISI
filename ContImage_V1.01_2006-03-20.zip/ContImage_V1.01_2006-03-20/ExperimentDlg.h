#if !defined(AFX_EXPERIMENTDLG_H__68653844_2F94_4B16_AD8C_09BCEE891959__INCLUDED_)
#define AFX_EXPERIMENTDLG_H__68653844_2F94_4B16_AD8C_09BCEE891959__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ExperimentDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExperimentDlg dialog

class CExperimentDlg : public CDialog
{
// Construction
public:
	CExperimentDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CExperimentDlg)
	enum { IDD = IDD_EXPERIMENT_DIALOG };
	CButton	m_buttonLogDirectory;
	CButton	m_buttonDataDirectory;
	CButton	m_buttonCancel;
	CButton	m_buttonLogDirectorySameAsData;
	UINT	m_nNFrames;
	CString	m_strDataDirectory;
	CString	m_strLogDirectory;
	int		m_iSpatialExperimentBinning;
	int		m_iTemporalExperimentBinning;
	CString	m_strUserName;
	short	m_sMonth;
	short	m_sDay;
	short	m_sYear;
	short	m_sExperimentNumber;
	short	m_sExperimentRun;
	CString	m_strFileName;
	int		m_iExperimentContinuousMode;
	int		m_iTotalExperimentBinning;
	int		m_iDataType;
	UINT	m_nWaveLength;
	CString	m_strComments;
	CString	m_strSubjectID;
	double	m_dStimulationPeriod;
	double	m_dStimulationCycles;
	UINT	m_nNFramesStim;
	UINT	m_nNFramesITI;
	UINT	m_nNFramesTotal;
	UINT	m_nNFramesBlank;
	UINT	m_nNBinnedFramesStim;
	UINT	m_nNBinnedFramesITI;
	UINT	m_nNBinnedFramesTotal;
	UINT	m_nNBinnedFramesBlank;
	UINT	m_nNConditions;
	UINT	m_nNRepetitions;
	BOOL	m_bRandomize;
	float	m_fNConditionsTime;
	float	m_fNRepetitionsTime;
	float	m_fNFramesStimTime;
	float	m_fNFramesITITime;
	float	m_fNFramesTotalTime;
	float	m_fNFramesBlankTime;
	float	m_fStimulationTime;
	float	m_fInterFrameTimeMsec;
	UINT	m_nOpticsFocalLengthBottom;
	UINT	m_nOpticsFocalLengthTop;
	UINT	m_nFilterWidth;
	UINT	m_nNBinnedFrames;
	float	m_fInterFrameTimeBinnedMsec;
	//}}AFX_DATA

	DWORD m_dwInterFrameTimeUsec;
	DWORD m_dwMaxCommentCharacters;
	BOOL  m_bDisableAll;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExperimentDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExperimentDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDirectoryLogSameAsData();
	afx_msg void OnUpdateDirectoryData();
	afx_msg void OnPaint();
	afx_msg void OnUpdateNframesStim();
	afx_msg void OnUpdateNframesITI();
	afx_msg void OnUpdateNframesBlank();
	afx_msg void OnUpdateNConditions();
	afx_msg void OnUpdateNRepetitions();
	afx_msg void OnDataDirectoryButton();
	afx_msg void OnLogDirectoryButton();
	afx_msg void OnUpdateUsername();
	afx_msg void OnUpdateSubjectId();
	//}}AFX_MSG
	afx_msg void OnUpdateYMDNumRun(UINT nID);
	afx_msg void OnUpdateBinning(UINT nID);
	afx_msg void OnUpdateExperimentContinuousMode(UINT nID);
	afx_msg void OnKillfocusStimulusParameters(UINT nID);
	afx_msg void OnKillfocusOptics(UINT nID);
	DECLARE_MESSAGE_MAP()

	char* DirectoryButtonDlg(char *pcName,char *pcInitDir);
	void DisableAll(BOOL bDisable);

private:
	CBitmap m_hFolderBitmap;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPERIMENTDLG_H__68653844_2F94_4B16_AD8C_09BCEE891959__INCLUDED_)
