#if !defined(AFX_FOCUSDLG_H__B0149ABB_BFE6_46B2_A88C_C6CA5E7A9134__INCLUDED_)
#define AFX_FOCUSDLG_H__B0149ABB_BFE6_46B2_A88C_C6CA5E7A9134__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FocusDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFocusDlg dialog

class CFocusDlg : public CDialog
{
// Construction
public:
	CFocusDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFocusDlg)
	enum { IDD = IDD_FOCUS_DIALOG };
	int		m_iFocusDynamicMode;
	int		m_iFocusSaveMode;
	UINT	m_nFilterWidth;
	UINT	m_nWaveLength;
	int		m_iFocusBinningSpatialROI;
	int		m_iFocusBinningTemporalROI;
	int		m_iFocusBinningSpatialExperiment;
	int		m_iFocusBinningTemporalExperiment;
	//}}AFX_DATA

	BOOL m_bMainROIOnly;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFocusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFocusDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	afx_msg void OnUpdateFocusRadio(UINT nID);
	afx_msg void OnUpdateFocusSaveMode(UINT nID);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOCUSDLG_H__B0149ABB_BFE6_46B2_A88C_C6CA5E7A9134__INCLUDED_)
