// TraceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "contimage.h"
#include "TraceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTraceDlg dialog


CTraceDlg::CTraceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTraceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTraceDlg)
	m_nTraceX = 0;
	m_nTraceY = 0;
	//}}AFX_DATA_INIT
	m_nTraceMinX=0;
	m_nTraceMinY=0;
	m_nTraceMaxX=1023;
	m_nTraceMaxY=1023;
}


void CTraceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTraceDlg)
	DDX_Text(pDX, IDC_TRACE_X, m_nTraceX);
	DDV_MinMaxUInt(pDX, m_nTraceX, m_nTraceMinX, m_nTraceMaxX);
	DDX_Text(pDX, IDC_TRACE_Y, m_nTraceY);
	DDV_MinMaxUInt(pDX, m_nTraceY, m_nTraceMinY, m_nTraceMaxY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTraceDlg, CDialog)
	//{{AFX_MSG_MAP(CTraceDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTraceDlg message handlers

BOOL CTraceDlg::OnInitDialog(){
	CDialog::OnInitDialog();
	char str[128];
	SetWindowText(m_strTitle);
	sprintf(str,"(%i-%i)",m_nTraceMinX,m_nTraceMaxX);
	GetDlgItem(IDC_TRACE_X_RANGE)->SetWindowText(str);
	sprintf(str,"(%i-%i)",m_nTraceMinY,m_nTraceMaxY);
	GetDlgItem(IDC_TRACE_Y_RANGE)->SetWindowText(str);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
