// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ContImage.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const UINT UWM_PRINT_THREAD_MESSAGE = ::RegisterWindowMessage(_T("UWM_PRINT_THREAD_MESSAGE"));
static const UINT UWM_SWITCH_FOCUS_MODE = ::RegisterWindowMessage(_T("UWM_SWITCH_FOCUS_MODE"));
static const UINT UWM_ON_SAVE_GREEN = ::RegisterWindowMessage(_T("UWM_ON_SAVE_GREEN"));
static const UINT UWM_ON_SAVE_IMAGE_FILE = ::RegisterWindowMessage(_T("UWM_ON_SAVE_IMAGE_FILE"));
static const UINT UWM_ON_CHANGE_MODES = ::RegisterWindowMessage(_T("UWM_ON_CHANGE_MODES"));

static const UINT UWM_TRIGGER_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_TRIGGER_THREAD_FINISHED"));
static const UINT UWM_EXPERIMENT_THREAD_FINISHED = ::RegisterWindowMessage(_T("UWM_EXPERIMENT_THREAD_FINISHED"));

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_MONITOR_BOX, OnViewMonitorBox)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MONITOR_BOX, OnUpdateViewMonitorBox)
	ON_WM_COPYDATA()
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_COMMAND(ID_FILE_SAVE_ALL, OnFileSaveAll)
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_COMMAND(ID_FOCUS, OnFocus)
	ON_COMMAND(ID_EXPERIMENT, OnExperiment)
	ON_COMMAND(ID_ACQUIRE_MISC_WINDOWS, OnAcquireMiscWindows)
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpFinder)

	ON_REGISTERED_MESSAGE(UWM_ON_CHANGE_MODES, OnChangeModes)

	ON_REGISTERED_MESSAGE(UWM_PRINT_THREAD_MESSAGE, OnPrintThreadMessage)
	ON_REGISTERED_MESSAGE(UWM_TRIGGER_THREAD_FINISHED, OnTriggerThreadFinished)
	ON_REGISTERED_MESSAGE(UWM_EXPERIMENT_THREAD_FINISHED, OnExperimentThreadFinished)

	// Toolbar Message Map

	ON_COMMAND(ID_FOCUS1, OnFocus1)
	ON_COMMAND(ID_EXPERIMENT1, OnExperiment1)

	//	ON_COMMAND_RANGE(ID_FOCUS, ID_EXPERIMENT, OnToolBarState)
//	ON_UPDATE_COMMAND_UI_RANGE(ID_FOCUS, ID_EXPERIMENT, OnUpdateToolBarState)

//	ON_COMMAND(ID_FOCUS, OnFocus)
//	ON_COMMAND(ID_EXPERIMENT, OnExperiment)

	ON_UPDATE_COMMAND_UI(ID_FOCUS, OnUpdateFocus)
	ON_UPDATE_COMMAND_UI(ID_EXPERIMENT, OnUpdateExperiment)

	ON_COMMAND(ID_FOCUS_GREEN , OnFocusGreen)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_GREEN, OnUpdateFocusGreen)
	ON_COMMAND(ID_FOCUS_EXPOSURE , OnFocusExposure)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_EXPOSURE, OnUpdateFocusExposure)
	ON_COMMAND(ID_FOCUS_RUN , OnFocusRun)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_RUN, OnUpdateFocusRun)
	ON_COMMAND(ID_FOCUS_STOP , OnFocusStop)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_STOP, OnUpdateFocusStop)
	ON_COMMAND(ID_FOCUS_SAVE , OnFocusSave)
//	ON_UPDATE_COMMAND_UI(ID_FOCUS_SAVE, OnUpdateFocusSave)

	ON_COMMAND(ID_EXPERIMENT_RUN , OnExperimentRun)
	ON_UPDATE_COMMAND_UI(ID_EXPERIMENT_RUN, OnUpdateExperimentRun)
	ON_COMMAND(ID_EXPERIMENT_PAUSE , OnExperimentPause)
	ON_UPDATE_COMMAND_UI(ID_EXPERIMENT_PAUSE, OnUpdateExperimentPause)
	ON_COMMAND(ID_EXPERIMENT_STOP , OnExperimentStop)
	ON_UPDATE_COMMAND_UI(ID_EXPERIMENT_STOP, OnUpdateExperimentStop)
	ON_COMMAND(ID_EXPERIMENT_ABORT , OnExperimentAbort)
	ON_UPDATE_COMMAND_UI(ID_EXPERIMENT_ABORT, OnUpdateExperimentAbort)

	ON_COMMAND(ID_FOCUS_DISPLAY , OnFocusDisplay)
	ON_UPDATE_COMMAND_UI(ID_FOCUS_DISPLAY, OnUpdateFocusDisplay)
	ON_COMMAND(ID_EXPERIMENT_DISPLAY , OnExperimentDisplay)

END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CURSOR_POSITION,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame(){
	m_hFocusBitmap.LoadBitmap(IDB_FOCUS_BUTTON);
	m_hExperimentBitmap.LoadBitmap(IDB_EXPERIMENT_BUTTON);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct){
	if(CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if(!m_wndToolBar.Create(this) || !m_wndToolBar.LoadToolBar(IDR_MAINFRAME)){
		TRACE0("Failed to create toolbar\n");
		return -1;
	}
	m_wndToolBar.SetWindowText(_T("Main"));
//	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	int i;
	CRect rect;
//	for(i=0;m_wndToolBar.GetItemID(i) != ID_FOCUS;i++);
	i = m_wndToolBar.CommandToIndex( ID_FOCUS );
	m_wndToolBar.SetButtonInfo(i, ID_FOCUS, TBBS_SEPARATOR ,100);
	m_wndToolBar.GetItemRect(i, &rect);
	if (!m_buttonFocus.Create("Focus",WS_CHILD|WS_VISIBLE|BS_BITMAP|BS_PUSHLIKE, rect,&m_wndToolBar ,ID_FOCUS)){
		PrintMessage(LEVEL_ERROR,"Failed to create Focus button");        
		TRACE0("Failed to create Focus button\n");        
		return FALSE; 
	}
	m_buttonFocus.SetBitmap((HBITMAP)(m_hFocusBitmap));

	for(i=0;m_wndToolBar.GetItemID(i) != ID_EXPERIMENT;i++);
	m_wndToolBar.SetButtonInfo(i, ID_EXPERIMENT, TBBS_SEPARATOR ,100);
	m_wndToolBar.GetItemRect(i, &rect);
	if (!m_buttonExperiment.Create("Experiment",WS_CHILD|WS_VISIBLE|BS_BITMAP|BS_PUSHLIKE, rect,&m_wndToolBar ,ID_EXPERIMENT)){
		PrintMessage(LEVEL_ERROR,"Failed to create Focus button");        
		TRACE0("Failed to create Focus button\n");        
		return FALSE; 
	}
	m_buttonExperiment.SetBitmap((HBITMAP)(m_hExperimentBitmap));



	if(!m_wndModeToolBar.Create(this)){
		TRACE0("Failed to create the Mode toolbar.\n");
		return -1;
	}
//	m_wndModeToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	if(!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT))){
		TRACE0("Failed to create status bar\n");
		return -1;
	}

	// MonitorBox creation
	if (!m_wndMonitorBox.Create(_T("MonitorBox"), this, 124)){
		TRACE0("Failed to create MonitorBox\n");
		return -1;
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndMonitorBox.SetBarStyle(m_wndMonitorBox.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these lines if you don't want the toolbars to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndModeToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndMonitorBox.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);

	DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP);
	RecalcLayout(TRUE);
	CRect r;	
	m_wndToolBar.GetWindowRect(&r);
	r.OffsetRect(r.right-r.left,0);
	DockControlBar(&m_wndModeToolBar,AFX_IDW_DOCKBAR_TOP,&r);
	DockControlBar(&m_wndMonitorBox, AFX_IDW_DOCKBAR_RIGHT);

  SetTitle(g_szVersion);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
//	::MessageBox(NULL,"CMainFrame::PreCreateWindow","",MB_OK);
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
/*
void CMainFrame::OnToolBarState(UINT nID){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if(m_wndModeToolBar.ReloadToolBar(nID-ID_FOCUS,theApp->m_iDisplayFrames)){
		if(nID == ID_FOCUS)			theApp->SetApplicationMode(APPLICATION_MODE_FOCUS);
		if(nID == ID_EXPERIMENT)	theApp->SetApplicationMode(APPLICATION_MODE_EXPERIMENT);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
}
*/

void CMainFrame::OnFocus(){
//	PrintMessage("CMainFrame::OnFocus");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if(m_wndModeToolBar.ReloadToolBar(0,theApp->m_iDisplayFrames)){
		theApp->SetApplicationMode(APPLICATION_MODE_FOCUS);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
//	m_wndModeToolBar.SetFocus();
//	m_buttonFocus.SetState(TRUE);
//	m_buttonExperiment.SetState(FALSE);

}

void CMainFrame::OnExperiment(){
//	PrintMessage("CMainFrame::OnExperiment");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if(m_wndModeToolBar.ReloadToolBar(2,theApp->m_iDisplayFrames)){
		theApp->SetApplicationMode(APPLICATION_MODE_EXPERIMENT);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
//	m_wndModeToolBar.SetFocus();
//	m_buttonFocus.SetState(FALSE);
//	m_buttonExperiment.SetState(TRUE);
}

LRESULT CMainFrame::OnChangeModes(WPARAM wp, LPARAM lp){
//	PrintMessage("CMainFrame::OnChangeModes");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if((int)lp == APPLICATION_MODE_FOCUS){
		m_wndModeToolBar.ReloadToolBar(0,theApp->m_iDisplayFrames);
	}
	if((int)lp == APPLICATION_MODE_EXPERIMENT){
		m_wndModeToolBar.ReloadToolBar(2,theApp->m_iDisplayFrames);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
	return((LRESULT)TRUE);
}


void CMainFrame::OnFocus1(){
	PrintMessage("CMainFrame::OnFocus11111111111");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if(m_wndModeToolBar.ReloadToolBar(0,theApp->m_iDisplayFrames)){
		theApp->SetApplicationMode(APPLICATION_MODE_FOCUS);
//	m_wndModeToolBar.SetFocus();
	m_buttonFocus.SetState(TRUE);
	m_buttonExperiment.SetState(FALSE);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);

}

void CMainFrame::OnExperiment1(){
	PrintMessage("CMainFrame::OnExperiment1111111111111");
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	if(m_wndModeToolBar.ReloadToolBar(2,theApp->m_iDisplayFrames)){
		theApp->SetApplicationMode(APPLICATION_MODE_EXPERIMENT);
//	m_wndModeToolBar.SetFocus();
	m_buttonFocus.SetState(FALSE);
	m_buttonExperiment.SetState(TRUE);
	}
	if(!m_wndModeToolBar.IsVisible()) ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
}

void CMainFrame::OnUpdateFocus(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(m_wndModeToolBar.m_nModeToolBar == TOOLBAR_FOCUS);
	pCmdUI->Enable(!((CContImageApp*)AfxGetApp())->m_bRunningExperiment && MDIGetActive());
}

void CMainFrame::OnUpdateExperiment(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(m_wndModeToolBar.m_nModeToolBar == TOOLBAR_EXPERIMENT);
	pCmdUI->Enable(!((CContImageApp*)AfxGetApp())->m_bRunningFocus && MDIGetActive());
}
/*
void CMainFrame::OnUpdateToolBarState(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(m_wndModeToolBar.m_nModeToolBar == pCmdUI->m_nID - ID_FOCUS);
}
*/


void CMainFrame::OnAcquireMiscWindows(){
	char str[64];

	sprintf(str,"App\t\t%p",AfxGetApp());
	PrintMessage(str);
	sprintf(str,"Frame\t\t%p",this);
	PrintMessage(str);
	
	CMDIChildWnd *pChildWin = MDIGetActive();
	if(pChildWin){
		sprintf(str,"Active child\t%p",pChildWin);
		PrintMessage(str);

		CDocument *pDoc = pChildWin->GetActiveDocument();
		if(pDoc){
			sprintf(str,"Active document\t%p",pDoc);
			PrintMessage(str);
		}
		else{
			PrintMessage("No active documents");
		}

		CFrameWnd *pFrmWin =  pChildWin->GetActiveFrame( );
		if(pFrmWin){
			sprintf(str,"Active frame\t%p",pFrmWin);
			PrintMessage(str);
		}
		else{
			PrintMessage("No active frames");
		}

		CView *pView = pChildWin->GetActiveView();
		if(pView){
			sprintf(str,"Active view\t%p",pView);
			PrintMessage(str);
		}
		else{
			PrintMessage("No active views");
		}

	}
	else{
		PrintMessage("No active child windows");
	}	
}

void CMainFrame::OnViewMonitorBox(){
	ShowControlBar(&m_wndMonitorBox, !m_wndMonitorBox.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewMonitorBox(CCmdUI* pCmdUI) {
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_wndMonitorBox.IsVisible());
}


BOOL CMainFrame::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct){
	switch (pCopyDataStruct->dwData){

	case LEVEL_DEBUG:
#ifdef PRINT_DEBUG_MESSAGES
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_DEBUG);
#endif
		break;

	case LEVEL_LOW:
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_LOW);
		break;

	case LEVEL_NORMAL:
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_NORMAL);
		break;

	case LEVEL_HIGH:
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_HIGH);
		break;

	case LEVEL_ERROR:
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_ERROR);
		break;

	case LEVEL_THREAD:
		m_wndMonitorBox.Append("USE PrintThreadMessage for threads",strlen("USE PrintThreadMessage for threads")+1,LEVEL_ERROR);
		m_wndMonitorBox.Append((LPCSTR)pCopyDataStruct->lpData,pCopyDataStruct->cbData,LEVEL_THREAD);
		break;
	}
	
	return CMDIFrameWnd::OnCopyData(pWnd, pCopyDataStruct);
}

LRESULT CMainFrame::OnPrintThreadMessage(WPARAM dwData,LPARAM str){

	switch (dwData){

	case LEVEL_DEBUG:
	case LEVEL_THREAD:
		m_wndMonitorBox.Append((LPCSTR)str,strlen((LPCSTR)str)+1,LEVEL_THREAD);
		break;

	case LEVEL_NORMAL:
		m_wndMonitorBox.Append((LPCSTR)str,strlen((LPCSTR)str)+1,LEVEL_NORMAL);
		break;

	case LEVEL_HIGH:
		m_wndMonitorBox.Append((LPCSTR)str,strlen((LPCSTR)str)+1,LEVEL_HIGH);
		break;

	case LEVEL_ERROR:
		m_wndMonitorBox.Append((LPCSTR)str,strlen((LPCSTR)str)+1,LEVEL_ERROR);
		break;

	}
	free((void*)(LPCSTR)str);
	return(LRESULT)TRUE;
}

BOOL CMainFrame::DestroyWindow() {
	/*
	CString sProfile = _T("MonitorBox");
	CSizingControlBar::GlobalSaveState(this, sProfile);
	SaveBarState(sProfile);
	*/
	return CMDIFrameWnd::DestroyWindow();
}


void CMainFrame::OnFocusGreen(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	theApp->SetFocusMode(FOCUS_MODE_GREEN);
	SendMessageToDescendants(UWM_SWITCH_FOCUS_MODE,FOCUS_MODE_GREEN);
}

void CMainFrame::OnUpdateFocusGreen(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(((CContImageApp*)AfxGetApp())->m_iFocusMode == FOCUS_MODE_GREEN);
}

void CMainFrame::OnFocusExposure(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	theApp->SetFocusMode(FOCUS_MODE_EXPOSURE);
	SendMessageToDescendants(UWM_SWITCH_FOCUS_MODE,FOCUS_MODE_EXPOSURE);
}

void CMainFrame::OnUpdateFocusExposure(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(((CContImageApp*)AfxGetApp())->m_iFocusMode == FOCUS_MODE_EXPOSURE);
}


void CMainFrame::OnFocusRun(){
	m_buttonExperiment.SendMessage(WM_ENABLE,FALSE,0); 
//	m_buttonExperiment.EnableWindow(FALSE);
//	m_buttonExperiment.ShowWindow(SW_HIDE);
	((CContImageApp*)AfxGetApp())->StartGrabbing();
}

void CMainFrame::OnUpdateFocusRun(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(((CContImageApp*)AfxGetApp())->m_bRunningFocus);
	pCmdUI->Enable(!((CContImageApp*)AfxGetApp())->m_bRunningFocus);
}

void CMainFrame::OnFocusStop(){
	((CContImageApp*)AfxGetApp())->StopGrabbing();
}

void CMainFrame::OnUpdateFocusStop(CCmdUI* pCmdUI){
	pCmdUI->Enable(((CContImageApp*)AfxGetApp())->m_bRunningFocus);
}

void CMainFrame::OnFocusSave(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	theApp->UpdateFileHeader();
	SendMessageToDescendants(UWM_ON_SAVE_GREEN);
	theApp->m_bGreenSaved=TRUE;
}
/*
void CMainFrame::OnUpdateFocusSave(CCmdUI* pCmdUI){
	pCmdUI->Enable(1);
}
*/

void CMainFrame::OnExperimentRun(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	m_wndMonitorBox.CloseLogFile();
	m_wndMonitorBox.OpenLogFile(theApp->m_strBaseFileName,theApp->m_strLogDirectory.GetBuffer(0));
	theApp->StartGrabbing();
}

void CMainFrame::OnUpdateExperimentRun(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(((CContImageApp*)AfxGetApp())->m_bRunningExperiment);
	pCmdUI->Enable(!((CContImageApp*)AfxGetApp())->m_bRunningExperiment);
}

void CMainFrame::OnExperimentPause(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	theApp->m_bExperimentPaused	= !theApp->m_bExperimentPaused;
}

void CMainFrame::OnUpdateExperimentPause(CCmdUI* pCmdUI){
	pCmdUI->SetCheck(((CContImageApp*)AfxGetApp())->m_bExperimentPaused);
	pCmdUI->Enable(((CContImageApp*)AfxGetApp())->m_bRunningExperiment);
}

void CMainFrame::OnExperimentStop(){
	((CContImageApp*)AfxGetApp())->StopGrabbing(THREAD_SHUTDOWN_STOP);
	m_wndMonitorBox.CloseLogFile();
}

void CMainFrame::OnUpdateExperimentStop(CCmdUI* pCmdUI){
	pCmdUI->Enable(((CContImageApp*)AfxGetApp())->m_bRunningExperiment);
}

void CMainFrame::OnExperimentAbort(){
	PrintMessage("Abort");
	((CContImageApp*)AfxGetApp())->StopGrabbing(THREAD_SHUTDOWN_ABORT);
	m_wndMonitorBox.CloseLogFile();
}

void CMainFrame::OnUpdateExperimentAbort(CCmdUI* pCmdUI){
	pCmdUI->Enable(((CContImageApp*)AfxGetApp())->m_bRunningExperiment);
}

void CMainFrame::OnFocusDisplay(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	m_wndModeToolBar.m_wndDisplay.SetCheck((theApp->m_iDisplayFrames = 1-theApp->m_iDisplayFrames));
}

void CMainFrame::OnUpdateFocusDisplay(CCmdUI* pCmdUI){
	pCmdUI->Enable(((CContImageApp*)AfxGetApp())->m_iServerDynamicMode!=SERVER_DYNAMIC_MODE_FAST);
}

void CMainFrame::OnExperimentDisplay(){
	CContImageApp *theApp = (CContImageApp*)AfxGetApp();
	m_wndModeToolBar.m_wndDisplay.SetCheck((theApp->m_iDisplayFrames = 1-theApp->m_iDisplayFrames));
}


//BOOL CMainFrame::OnCommand(WPARAM wParam, LPARAM lParam) {
//	PrintMessage("CMainFrame::OnCommand");
//	char str[128];
//	if(LOWORD(wParam) == ID_FOCUS1){
//		sprintf(str,"For %i %i %lu",LOWORD(wParam),HIWORD(wParam),lParam);
//		PrintMessage(LEVEL_ERROR,str);
//	}

//	return CMDIFrameWnd::OnCommand(wParam, lParam);
//}


//BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo){
//	char *str = (char*) ::_alloca( 128 );
//	sprintf(str,"Command %u\n",nID);
//	PrintMessage(str);
//	if(nID == ID_FOCUS1 && nCode != 0 && nCode != -1){
//		char *str = (char*) ::_alloca( 128 );
//		sprintf(str,"ID_FOCUS1 %i\n",nCode);
//		PrintMessage(LEVEL_ERROR,str);
//	}
//	if(nID == ID_EXPERIMENT1) PrintMessage(LEVEL_ERROR,"ID_EXPERIMENT1");
/*
	if(nID == ID_FILE_NEW) PrintMessage("ID_FILE_NEW");
	if(nID == ID_FILE_OPEN) PrintMessage("ID_FILE_OPEN");
	if(nID == ID_FILE_SAVE) PrintMessage("ID_FILE_SAVE");
	if(nID == ID_FILE_CLOSE) PrintMessage("ID_FILE_CLOSE");
	if(nID == ID_FILE_PRINT) PrintMessage("ID_FILE_PRINT");
	if(nID == ID_EDIT_UNDO) PrintMessage("ID_EDIT_UNDO");
	if(nID == ID_NEXT_PANE) PrintMessage("ID_NEXT_PANE");
	if(nID == ID_PREV_PANE) PrintMessage("ID_PREV_PANE");
	if(nID == ID_CONTEXT_HELP) PrintMessage("ID_CONTEXT_HELP");
	if(nID == ID_HELP) PrintMessage("ID_HELP");
	*/
//	return CMDIFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
//}


void CMainFrame::OnActiveDocuments(int iActiveDocs){
	static BOOL bActiveDoc=TRUE;
	if(iActiveDocs){
		if(!bActiveDoc){
			ShowControlBar(&m_wndModeToolBar, TRUE, FALSE);
			bActiveDoc=TRUE;
		}
	}
	else{
		ShowControlBar(&m_wndModeToolBar, FALSE, FALSE);
		bActiveDoc=FALSE;
	}
}


void CMainFrame::OnUpdateFileOpen(CCmdUI* pCmdUI){
	pCmdUI->Enable(!MDIGetActive());
}


void CMainFrame::OnFileSaveAll(){
	PrintMessage("CMainFrame::OnFileSaveAll");
	SendMessageToDescendants(UWM_ON_SAVE_IMAGE_FILE);
}

LRESULT CMainFrame::OnTriggerThreadFinished(WPARAM wp, LPARAM lp){
	PrintMessage("CMainFrame::OnTriggerThreadFinished");
	char str[128];
	sprintf(str,"TriggerThread finished with Exit Code %i",(int)wp);
	PrintMessage(LEVEL_NORMAL,str);
	OnExperimentStop();
	return(LRESULT)TRUE;
}

LRESULT CMainFrame::OnExperimentThreadFinished(WPARAM wp, LPARAM lp){
	PrintMessage("CMainFrame::OnTriggerThreadFinished");
	char str[128];
	sprintf(str,"MF ExperimentThread %i finished with Exit Code %i",(int)lp,(int)wp);
	PrintMessage(LEVEL_NORMAL,str);

	PrintMessage("MF Calling dequeuer");
	((CContImageApp*)AfxGetApp())->m_pFrameServer->DequeThread((int)lp);
	return((LRESULT)TRUE);
}


void CMainFrame::OnUpdateFileNew(CCmdUI* pCmdUI){
	pCmdUI->Enable(!((CContImageApp*)AfxGetApp())->m_bMainROIOpened);
}


