// FrameServer.cpp: implementation of the CFrameServer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ContImage.h"

#ifdef _DEBUG_NO_CAMERA

#include "FakeFrameServer.h"

#include "HardwareDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

extern DWORD UsableLinesPerFrame[N_VERTICAL_BINNING];
extern DWORD HorizontalOffset[N_VERTICAL_BINNING];
extern DWORD VerticalOffset[N_VERTICAL_BINNING];

//typedef CICapMod*(*ptFun1)(char *,DWORD, char *);
//ptFun1 dddd=(CICapMod*(*)(char *,unsigned long,char *))IfxCreateCaptureModule;
//CICapMod* (*CreateFrameGrabber)(char *,unsigned long,char *) = (CICapMod* (*) (char *,unsigned long,char *))IfxCreateCaptureModule;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFrameServer::CFrameServer(DWORD dwNRingBufferFrames){
	char modName[128];
	char fileName[128];

	m_bFrameServerReady	= FALSE;

	m_bTriggerThreadShutdown = FALSE;
	m_piOtherThreadsShutdown = NULL;
	m_hTriggerThread = NULL;
	m_dwTriggerThreadID = 0;
	m_phEvents = NULL;
	m_iNEvents = 0;
	m_pulFrameLockState = NULL;
	m_ppbFrameBufferEntry = NULL;
	m_ppbFrameHeaderBufferEntry = NULL;

	m_bMemoryFixedFrameBuffer = TRUE;
	m_bMemoryAvailablePercent = FALSE;
	m_nPhysicalMemoryAllowedPercent = DEFAULT_PHYSICAL_MEMORY_TO_USE_PERCENT;
	m_ulMemoryUsedByFrameServerB = 0;

	m_ulFrameBufferSizeB = 0;

	m_pbHostFrameBuffer = NULL;
	m_pbHostFrameHeaderBuffer = NULL;

	m_ulFrameHeaderSizeB = 0;

	if(dwNRingBufferFrames) m_dwNFramesRingBuffer = dwNRingBufferFrames;
	else m_dwNFramesRingBuffer = DEFAULT_NFRAMES_RING_BUFFER;

	m_bCameraType			= SMD_M30_CAMERA_TYPE;
	m_bControlRegister		= (BYTE)0x0;
	m_dwInterFrameTimeUsec	= 33333;
	m_dwIntegrationTimeUsec	= m_dwInterFrameTimeUsec - SMD_M30_MIN_DATA_SHIFT_TIME_USEC;
	m_dwVideoGain			= 1;
	m_lPixelOffset			= 0;
	m_dwHardwareBinningV	= 1;
	m_dwHardwareBinningH	= 1;
	m_dwResolutionX			= 1024;
	m_dwResolutionY			= 1024;
	m_dwSynchronization		= 0;

//	m_hGrabID = NULL;
	m_bGrabbing = FALSE;

	m_iGrabMode = DEFAULT_SERVER_DYNAMIC_MODE;
	m_iApplicationMode = DEFAULT_APPLICATION_MODE;

	strcpy(modName,DEFAULT_CAMERA_CONFIGURATION_MODE);
	strcpy(fileName,DEFAULT_CAMERA_CONFIGURATION_FILE);

/*
	if (!(m_pFrameGrabber=IfxCreateCaptureModule(modName,0,fileName))) {
		if (!(m_pFrameGrabber=IfxCreateCaptureModule(modName,0))) {
			::MessageBox(NULL,"No Image Capture Module detected","Frame Server",MB_OK);
		}
    exit(1);
	}

	n_dwAvailableContiguousMemory = m_pFrameGrabber->ContiguousMemAvailable();
	if(!m_pFrameGrabber->EnableJitGrabMemLock()){
		::MessageBox(NULL,"Cannot Enable Just-In-Time Grab Memory Lock","Frame Server",MB_OK);
	}

	if (!(m_pCamera = m_pFrameGrabber->GetCam(0))) {
		::MessageBox(NULL,"Port 0 Camera object cannot be obtained.","Frame Server",MB_OK);
		exit(2);
	}
*/
	m_pCOMPort = new CSerialPortControl();

//	SetHardwareBinning(m_dwHardwareBinningV,m_dwHardwareBinningH);
//	m_pCamera->OffsetLut(INPUT_LUT1,-256,LUT_FULL_WORD);
//	m_pCamera->OffsetLut(INPUT_LUT2,-256,LUT_FULL_WORD);
//	m_pCamera->SetLutHostPage(INPUT_LUT1,IFC_LUT_PIX_SIZE_12,0,FALSE);
//	m_pCamera->SetLutHostPage(INPUT_LUT2,IFC_LUT_PIX_SIZE_12,0,FALSE);
//	m_pCamera->LinearizeLut(INPUT_LUT1,LUT_FULL_WORD);
//	m_pCamera->LinearizeLut(INPUT_LUT2,LUT_FULL_WORD);
//	m_pCamera->SetLutPathPage(INPUT_LUT1,IFC_LUT_PIX_SIZE_12,0);
//	m_pCamera->SetLutPathPage(INPUT_LUT2,IFC_LUT_PIX_SIZE_12,0);

	m_pbLastFrame=NULL;

}

CFrameServer::~CFrameServer(){
	if(m_pulFrameLockState) free((void*)m_pulFrameLockState);
	if(m_ppbFrameBufferEntry) free(m_ppbFrameBufferEntry);
	if(m_ppbFrameHeaderBufferEntry) free(m_ppbFrameHeaderBufferEntry);
	if(m_pbHostFrameBuffer) GlobalFree(m_pbHostFrameBuffer);
//	if(m_pFrameGrabber) delete m_pFrameGrabber;
	delete m_pCOMPort;
}

BOOL CFrameServer::FreeFrameBuffer(){
/*
	char str[128];
	if(m_pbHostFrameBuffer){ 
		if(GlobalFree(m_pbHostFrameBuffer)){
			sprintf(str,"Cannot free main frame buffer LastError=%lu",GetLastError());
			PrintMessage(LEVEL_ERROR,str);
			::MessageBox(NULL,str,"Frame Server",MB_OK);
			return(FALSE);
		}
		m_ulMemoryUsedByFrameServerB -= m_ulFrameBufferSizeB;
		m_ulFrameBufferSizeB = 0;
	}
*/
	return(TRUE);
}

BOOL CFrameServer::ReallocateFrameBuffer(){
	PrintMessage("CFrameServer::ReallocateFrameBuffer");
/*
	ULONG	ulAllowedPhysicalB;
	ULONG	ulAvailablePhysicalB;
	ULONG	ulTotalPhysicalB;
	ULONG	ulTotalVirtualB;
	ULONG	ul;
	char str[128];
	MemoryStatus(0,&ulAvailablePhysicalB,&ulTotalPhysicalB,&ulTotalVirtualB);
	ulAvailablePhysicalB += m_ulFrameBufferSizeB;

	if(!FreeFrameBuffer()) return(FALSE);

	m_ulFrameSizeB=m_dwResolutionX*m_dwResolutionY*m_CameraAttributes.dwBytesPerPixel;
	
	if(!m_bMemoryFixedFrameBuffer){
		if(m_bMemoryAvailablePercent) ulAllowedPhysicalB = (ULONG)(ulAvailablePhysicalB*0.01*m_nPhysicalMemoryAllowedPercent);
		else  ulAllowedPhysicalB = (ULONG)(ulTotalPhysicalB*0.01*m_nPhysicalMemoryAllowedPercent);
		m_dwNFramesRingBuffer = ulAllowedPhysicalB/m_ulFrameSizeB;
		if(m_dwNFramesRingBuffer < DEFAULT_MIN_NFRAMES_RING_BUFFER){
			sprintf(str,"Requires at least %i frames in buffer",DEFAULT_MIN_NFRAMES_RING_BUFFER);
			PrintMessage(LEVEL_ERROR,str);
			PrintMessage(LEVEL_WARNING,"Trying default");
			m_dwNFramesRingBuffer = DEFAULT_MIN_NFRAMES_RING_BUFFER;
		}
	}

	m_ulFrameBufferSizeB = m_ulFrameSizeB*m_dwNFramesRingBuffer;


	sprintf(str,"Total %lu Available %lu",ulTotalPhysicalB,ulAvailablePhysicalB);
	PrintMessage(LEVEL_NORMAL,str);
//	::MessageBox(NULL,str,"Frame Server",MB_OK);
	sprintf(str,"Frames %lu Buffer %lu",m_dwNFramesRingBuffer,m_ulFrameBufferSizeB);
	PrintMessage(LEVEL_NORMAL,str);
//	::MessageBox(NULL,str,"Frame Server",MB_OK);

	m_pbHostFrameBuffer=(BYTE*)GlobalAlloc(GMEM_FIXED,m_ulFrameBufferSizeB+sizeof(unsigned long));

	if(!m_pbHostFrameBuffer){
		sprintf(str,"Cannot allocate for main frame buffer LastError=%lu",GetLastError());
		PrintMessage(LEVEL_ERROR,str);
		::MessageBox(NULL,str,"Frame Server",MB_OK);
		m_ulFrameBufferSizeB=0;
		m_bFrameServerReady = FALSE;
		return(FALSE);
	}
	m_bFrameServerReady = TRUE;

	m_ulMemoryUsedByFrameServerB += m_ulFrameBufferSizeB;

	m_pbLastFrame=m_pbHostFrameBuffer;

	if(m_pulFrameLockState) free((void*)m_pulFrameLockState);
	if(!(m_pulFrameLockState=(ULONG* volatile)calloc(m_dwNFramesRingBuffer,sizeof(ULONG)))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for m_pulFrameLockState");
		return(FALSE);
	}

	if(m_ppbFrameBufferEntry) free((void*)m_ppbFrameBufferEntry);
	if(!(m_ppbFrameBufferEntry=(BYTE**)calloc(m_dwNFramesRingBuffer,sizeof(BYTE*)))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for m_ppbFrameBufferEntry");
	}
	for(ul=0;ul<m_dwNFramesRingBuffer;ul++) m_ppbFrameBufferEntry[ul]=m_pbHostFrameBuffer+ul*m_ulFrameSizeB;

	if(m_ppbFrameHeaderBufferEntry) free((void*)m_ppbFrameHeaderBufferEntry);
	if(!(m_ppbFrameHeaderBufferEntry=(BYTE**)calloc(m_dwNFramesRingBuffer,sizeof(BYTE*)))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for m_ppbFrameHeaderBufferEntry");
	}
	if(TestFrameGrabber()){
		PrintMessage("FrameGrabber: OK");
	}
*/
  return(TRUE);
}

BOOL CFrameServer::TestFrameGrabber(){
/*
	GRAB_HANDLE	hTmpGrabID;
	DWORD	dwTimeOut=1000;
	int		iRing;
	BYTE	*pb;
	int		i,iSpin=3;
	char str[128];

	if((hTmpGrabID = m_pCamera->Grab(0,m_pbHostFrameBuffer, m_dwNFramesRingBuffer))==NULL){
		PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer Failed to start grabbing");
		::MessageBox(NULL,"Failed to start grab","Frame Grabber Test",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;
	}
	for(i=0;i<iSpin;i++){
		if((iRing=m_pCamera->GrabWaitFrameEx(hTmpGrabID, &pb,IFC_WAIT_NEWER_FRAME, dwTimeOut)) <0){
			sprintf(str,"Test: Timed out after %i msec",dwTimeOut);
			PrintThreadMessage(LEVEL_ERROR,str);
			PrintThreadMessage(LEVEL_ERROR,"Make sure camera is on");
			::MessageBox(NULL,"Make sure camera is on","Frame Grabber Test",MB_OK|MB_ICONEXCLAMATION);
			break;
		}
		m_pCamera->GrabRelease(hTmpGrabID, iRing);
	}
	m_pCamera->Freeze(hTmpGrabID);
	if(i==iSpin) return(TRUE);
	else return(FALSE);
*/
  return TRUE;
}

void CFrameServer::GetCameraAttributes(){
//	m_pCamera->GetAttr(&m_CameraAttributes);
}

BOOL CFrameServer::StartFrameServer(int iMode,int iApplicationMode,int iNEvents){
	PrintMessage("CFrameServer::StartFrameServer");
/*
  if(!m_bFrameServerReady){
		PrintMessage(LEVEL_WARNING,"Frame Server is not ready");
		return FALSE;
	}
	if(m_bGrabbing){
		PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer Grab has been started already");
		return FALSE;
	}
	else{
		m_iGrabMode = iMode;
		m_iApplicationMode = iApplicationMode;
		PrintMessage(m_iGrabMode,m_iApplicationMode);

    switch(m_iGrabMode){
		case SERVER_DYNAMIC_MODE_ROI:

			if((m_hGrabID = m_pCamera->Grab(0,//IFC_GOPT_AUTO_FRAME_LOCK, //| IFC_GOPT_FRAME_TIME_TAG,
											m_pbHostFrameBuffer, m_dwNFramesRingBuffer))==NULL){
				PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer Failed to start grabbing ROI");
				return FALSE;
			}
			break;
		case SERVER_DYNAMIC_MODE_FAST:
			m_pCamera->Grab();
			break;
		case SERVER_DYNAMIC_MODE_EXPERIMENT:
			if((m_hGrabID = m_pCamera->Grab(0,//IFC_GOPT_AUTO_FRAME_LOCK, //| IFC_GOPT_FRAME_TIME_TAG,
											m_pbHostFrameBuffer, m_dwNFramesRingBuffer))==NULL){
				PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer Failed to start grabbing Experiment");
				return FALSE;
			}
			if(m_iApplicationMode == APPLICATION_MODE_EXPERIMENT){
				if(!StartTriggerThread(iNEvents)){
					StopFrameServer();
					PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer Failure to start Trigger Thread");
					return(FALSE);
				}
				PrintMessage("CFrameServer::StartFrameServer Started Trigger Thread");
			}
			break;
		default:
			PrintMessage(LEVEL_ERROR,"CFrameServer::StartFrameServer: Unknown Server Dynamic Mode");
			return FALSE;
		}
		m_bGrabbing = TRUE;
	}
	return(m_bGrabbing);
*/
  return TRUE;
}

BOOL CFrameServer::StopFrameServer(int iShutdown){
	PrintMessage("CFrameServer::StopFrameServer");
/*
	if(m_bGrabbing){
		m_bGrabbing = FALSE;

		if (m_pCamera){
			if (m_hGrabID){
				if(m_iApplicationMode == APPLICATION_MODE_EXPERIMENT) StopTriggerThread(iShutdown);

				CAMERA_STATISTICS	structCameraStats;
				m_pCamera->GetGrabStats(m_hGrabID,&structCameraStats);

				int iLastFilledFrameSeqNum;
				iLastFilledFrameSeqNum=m_pCamera->Freeze(m_hGrabID);
				m_hGrabID = NULL;

				m_pbLastFrame =	m_pbHostFrameBuffer;
				if(iLastFilledFrameSeqNum != -1) m_pbLastFrame+=m_ulFrameSizeB*(iLastFilledFrameSeqNum%m_dwNFramesRingBuffer);

				char str[256];
				sprintf(str,"FS Frames: Locked %i Lost %i Missed %i",structCameraStats.NumberOfFramesLocked,
					structCameraStats.NumberOfFramesLost,structCameraStats.NumberOfFramesMissed);
				PrintThreadMessage(LEVEL_NORMAL,str);
				sprintf(str,"FS Frames: Next %i Await %i",
					structCameraStats.CurrentFrameSeqNum,structCameraStats.NumberOfFramesAwaitDelivery);
				PrintThreadMessage(LEVEL_NORMAL,str);
			} 
			else{
				m_pCamera->Freeze();
				m_pbLastFrame = NULL;
			}
		}
		return(TRUE);
	}
	else return(FALSE);
*/

  return TRUE;
}


BOOL CFrameServer::OnSettingsHardware(){
/*
	CContImageApp *theApp=(CContImageApp*)AfxGetApp();
	CHardwareDlg dlg;

	dlg.m_dwHardwareMinDataShiftTime=SMD_M30_MIN_DATA_SHIFT_TIME_USEC;
	dlg.m_dwHardwareInterFrameTime=m_dwInterFrameTimeUsec;
	dlg.m_dwHardwareIntegrationTime=m_dwIntegrationTimeUsec;
	dlg.m_dHardwareFrameRate=1.0e-3*floor(1.0e+9/(double)m_dwInterFrameTimeUsec);

	dlg.m_dwHardwareBinning=m_dwHardwareBinningV;
	dlg.m_dwHardwareGain=m_dwVideoGain;
	dlg.m_lHardwareOffset=m_lPixelOffset;

	dlg.m_ulAvailablePhysicalB = MemoryAvailablePhysical(&dlg.m_ulTotalPhysicalB);
	dlg.m_iPhysicalMemoryUsagePercent = m_nPhysicalMemoryAllowedPercent;
	dlg.m_nPhysicalMemoryUsageFrames = m_dwNFramesRingBuffer;
	if(m_bMemoryFixedFrameBuffer) dlg.m_iRadioMemoryAllocationOption=0;
		else{
		if(m_bMemoryAvailablePercent) dlg.m_iRadioMemoryAllocationOption=2;
		else  dlg.m_iRadioMemoryAllocationOption=1;
	}

	dlg.m_bDisableAll = theApp->m_bRunningExperiment;

	if(dlg.DoModal()==IDOK){
		switch(dlg.m_iRadioMemoryAllocationOption){
		case 0:
			m_bMemoryFixedFrameBuffer=TRUE;
			break;
		case 1:
			m_bMemoryFixedFrameBuffer=FALSE;
			m_bMemoryAvailablePercent=FALSE;
			break;
		case 2:
			m_bMemoryFixedFrameBuffer=FALSE;
			m_bMemoryAvailablePercent=TRUE;
			break;
		default:
			PrintMessage(LEVEL_ERROR,"Unknown option in CFrameServer::OnSettingsHardware");
			return(FALSE);
		}
		m_dwNFramesRingBuffer = dlg.m_nPhysicalMemoryUsageFrames;
		m_nPhysicalMemoryAllowedPercent = dlg.m_iPhysicalMemoryUsagePercent;
		BOOL bReallocateFrameBuffer = (dlg.m_ulPhysicalMemoryUsageB != m_ulFrameBufferSizeB);

		if(dlg.m_bHardwareResetCamera){
			bReallocateFrameBuffer = FALSE;

			theApp->ResetHardwareBinning(dlg.m_dwHardwareBinning);	
			SetInterFrameTime(dlg.m_dwHardwareInterFrameTime);
			SetIntegrationTime(dlg.m_dwHardwareIntegrationTime);
			SetUserGain(dlg.m_dwHardwareGain);
			SetUserOffset(dlg.m_lHardwareOffset);
		}
		else{
			if(dlg.m_dwHardwareBinning != m_dwHardwareBinningV){
				PrintMessage(LEVEL_LOW,"ResetHardwareBinning");
				bReallocateFrameBuffer = FALSE;
				theApp->ResetHardwareBinning(dlg.m_dwHardwareBinning);
			}
			if(dlg.m_dwHardwareInterFrameTime != m_dwInterFrameTimeUsec)
				SetInterFrameTime(dlg.m_dwHardwareInterFrameTime);
			if(dlg.m_dwHardwareIntegrationTime != m_dwIntegrationTimeUsec)
				SetIntegrationTime(dlg.m_dwHardwareIntegrationTime);
			if(dlg.m_dwHardwareGain != m_dwVideoGain)
				SetUserGain(dlg.m_dwHardwareGain);
			if(dlg.m_lHardwareOffset != m_lPixelOffset)
				SetUserOffset(dlg.m_lHardwareOffset);
		}

		if(bReallocateFrameBuffer){			
			BOOL bRestart = m_bGrabbing;	
			if(bRestart){
				theApp->OnFrameServerStop();
				StopFrameServer();
			}
			if(!ReallocateFrameBuffer()) return(FALSE);
			if(bRestart){
				StartFrameServer(m_iGrabMode,m_iApplicationMode);
				theApp->OnFrameServerStart(FRAME_SERVER_MESSAGE_BUFFER_CHANGE);
			}
		}
		return(TRUE);
	}	
	return(FALSE);
*/
  return TRUE;
}



BOOL CFrameServer::ResetADCBoard(){
	PrintMessage("CFrameServer::ResetADCBoard");
	return( m_pCOMPort->SerialPortCommand(WRITE_SOFT_RESET,NULL) );
}

BOOL CFrameServer::ResetCamera(){
	PrintMessage("CFrameServer::ResetCamera");
	m_bControlRegister		= (BYTE)0x0;
	return( m_pCOMPort->SerialPortCommand(WRITE_CAMERA_RESET,NULL) );
}

BOOL CFrameServer::SetControlRegister(BYTE bControlRegister){
	PrintMessage("CFrameServer::SetControlRegister");
	DWORD_BYTE db;
	char str[256];
	db.dw=bControlRegister;
	sprintf(str,"ControlRegister %#x",db.dw);
	PrintMessage(str);
	return( m_pCOMPort->SerialPortCommand(WRITE_CONTROL_REGISTER,db.str) );
}

BOOL CFrameServer::SetControlRegisterBit(BYTE bControlRegisterBit){
	PrintMessage("CFrameServer::SetControlRegisterBit");
	m_bControlRegister |= bControlRegisterBit;
	return( SetControlRegister(m_bControlRegister) );
}

BOOL CFrameServer::UnsetControlRegisterBit(BYTE bControlRegisterBit){
	PrintMessage("CFrameServer::UnsetControlRegisterBit");
	m_bControlRegister &= ~bControlRegisterBit;
	return( SetControlRegister(m_bControlRegister) );
}

BYTE CFrameServer::GetControlRegister(){
	PrintMessage("CFrameServer::GetControlRegister");
	DWORD_BYTE db;
	char str[256];
	db.dw=0;
	if( m_pCOMPort->SerialPortCommand(READ_CONTROL_REGISTER,db.str) ){
		sprintf(str,"Control Register: Hardware %#x Software %#x", db.str[0],m_bControlRegister);
		PrintMessage(str);
		return(db.str[0]);
	}
	else{
		PrintMessage(LEVEL_ERROR,"Could not read control register");
		return(0);
	}
}

BYTE CFrameServer::GetCameraType(){
	PrintMessage("CFrameServer::GetCameraType");
	DWORD_BYTE db;
	char str[256];
	db.dw=0;
	if( m_pCOMPort->SerialPortCommand(READ_CAMERA_TYPE,db.str) ){
		sprintf(str,"Camera Type: Hardware %#x Software %#x", db.str[0], m_bCameraType);
		PrintMessage(str);
		return(db.str[0]);
	}
	else{
		PrintMessage(LEVEL_ERROR,"Could not read camera type");
		return(0);
	}
}

BYTE CFrameServer::GetFirmwareRevision(){
	PrintMessage("CFrameServer::GetFirmwareRevision");
	DWORD_BYTE db;
	char str[256];
	db.dw=0;
	if( m_pCOMPort->SerialPortCommand(READ_FIRMWARE_REVISION,db.str) ){
		sprintf(str,"Firmware Revision: %#x", db.str[0]);
		PrintMessage(str);
		return(db.str[0]);
	}
	else{
		PrintMessage(LEVEL_ERROR,"Could not read firmware revision");
		return(0);
	}
}

BOOL CFrameServer::SetUserGain(DWORD dwUserGain){
	PrintMessage("CFrameServer::SetUserOffset");
	DWORD_BYTE db;
	char str[256];

	if(dwUserGain<1 || dwUserGain>10){
		sprintf(str,"User gain %u is out of range (1-10)",dwUserGain);
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}
	db.dw=(DWORD)(32768.0*log10((double)dwUserGain));
	sprintf(str,"Gain %u %u -> %#x %#x",dwUserGain, db.dw ,db.str[0] ,db.str[1]);
	PrintMessage(str);
	if( m_pCOMPort->SerialPortCommand(WRITE_USER_GAIN,db.str) ){
		m_dwVideoGain = dwUserGain;
		return(TRUE);
	}
	else{
		return(FALSE);
	}
}

DWORD CFrameServer::GetUserGain(){
	PrintMessage("CFrameServer::GetUserGain");
	DWORD dwUserGain;
	DWORD_BYTE db;
	char str[256];
	db.dw=0;
	if( m_pCOMPort->SerialPortCommand(READ_USER_GAIN,db.str) ){
		dwUserGain = (DWORD)exp(log(10.0) * (double)db.dw/32768.0);
		sprintf(str,"Gain: Hardware %u -> %u Software %u", db.dw, dwUserGain,m_dwVideoGain);
		PrintMessage(str);
		return(dwUserGain);
	}
	else{
		PrintMessage(LEVEL_ERROR,"Could not read user gain");
		return(0);
	}
}

BOOL CFrameServer::SetUserOffset(long lUserOffset){
	PrintMessage("CFrameServer::SetUserOffset");
	DWORD_BYTE db;
	char str[128];

	if(lUserOffset<-4095 || lUserOffset>4095){
		sprintf(str,"User offset %i is out of range (-4095 - 4095)",lUserOffset);
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}
	db.dw=(DWORD)((8*lUserOffset)/m_dwVideoGain);
	sprintf(str,"Offset %u -> %#x %#x",db.dw ,db.str[0] ,db.str[1]);
	PrintMessage(str);
	if( m_pCOMPort->SerialPortCommand(WRITE_USER_OFFSET,db.str) ){
		m_lPixelOffset=lUserOffset;
		return(TRUE);
	}
	else{
		return(FALSE);
	}
}

long CFrameServer::GetUserOffset(){
	PrintMessage("CFrameServer::GetUserOffset");
	long lUserOffset;
	DWORD_BYTE db;
	char str[256];
	db.dw=0;
	if( m_pCOMPort->SerialPortCommand(READ_USER_OFFSET,db.str) ){
		lUserOffset = (long)((db.dw*m_dwVideoGain)/8);
		sprintf(str,"Offset: Hardware %u -> %u Software %u", db.dw, lUserOffset,m_lPixelOffset);
		PrintMessage(str);
		return(lUserOffset);
	}
	else{
		PrintMessage(LEVEL_ERROR,"Could not read user gain");
		return(0);
	}
}

BOOL CFrameServer::SetFrameRate(double dFrameRate){
	PrintMessage("CFrameServer::SetFrameRate");
	return(SetInterFrameTime((DWORD)(1000000.0/dFrameRate)));
}

BOOL CFrameServer::SetInterFrameTime(DWORD dwInterFrameTimeUsec){
	PrintMessage("CFrameServer::SetInterFrameTime");
	DWORD_BYTE db;
	char str[128];
	UnsetControlRegisterBit(CONTROL_REGISTER_ET_MODE);
	db.dw=dwInterFrameTimeUsec;
	sprintf(str,"Inter-Frame Time %u -> %#x %#x %#x (%u)",db.dw ,db.str[0] ,db.str[1] ,db.str[2],db.dw&0x3ffff);
	PrintMessage(str);
	m_dwInterFrameTimeUsec=dwInterFrameTimeUsec;
	return( m_pCOMPort->SerialPortCommand(WRITE_FRAME_RATE,db.str) );
}

BOOL CFrameServer::SetIntegrationTime(DWORD dwIntegrationTimeUsec){
	PrintMessage("CFrameServer::SetIntegrationTime");
	DWORD_BYTE db;
	char str[128];
	UnsetControlRegisterBit(CONTROL_REGISTER_INTG_MODE);
	db.dw=dwIntegrationTimeUsec;
	sprintf(str,"Integration Time %u -> %#x %#x %#x (%u)",db.dw ,db.str[0] ,db.str[1] ,db.str[2],db.dw&0x3ffff);
	PrintMessage(str);
	m_dwIntegrationTimeUsec=dwIntegrationTimeUsec;
	return( m_pCOMPort->SerialPortCommand(WRITE_INTEGRATION_TIME,db.str) );
}

// Vertical binning = X binning, Horizontal binning = Y binning
BOOL CFrameServer::SetHardwareBinning(DWORD ulBinningX,DWORD ulBinningY){
	PrintMessage("CFrameServer::SetHardwareBinning 0");
/*
	DWORD_BYTE db;
	char str[128];

	if(ulBinningX<1 || ulBinningX>8){
		sprintf(str,"Hardware X Binning %u is out of range (1-8)",ulBinningX);
		PrintMessage(LEVEL_ERROR,str);
		PrintMessage(LEVEL_WARNING,"Using default");
		ulBinningX = 1;
	}
	if(ulBinningY<1 || ulBinningY>8){
		sprintf(str,"Hardware Y Binning %u is out of range (1-8)",ulBinningY);
		PrintMessage(LEVEL_ERROR,str);
		PrintMessage(LEVEL_WARNING,"Using default");
		ulBinningY = 1;
	}
	m_dwHardwareBinningV=ulBinningX;
	m_dwHardwareBinningH=ulBinningY;
	db.dw=m_dwHardwareBinningH & 0x7; // H nibble aka Y binning
	db.dw<<=4;
	db.dw|=m_dwHardwareBinningV & 0x7; // V nibble aka X binning
	sprintf(str,"Hardware Binning %u -> %#x",db.dw ,db.str[0]);
	PrintMessage(str);
	sprintf(str,"Usable Lines %u",UsableLinesPerFrame[m_dwHardwareBinningV-1]);
	PrintMessage(str);
	m_dwResolutionX=UsableLinesPerFrame[m_dwHardwareBinningV-1];//1024/m_dwHardwareBinningV;
	m_dwResolutionY=1024/m_dwHardwareBinningH;

	m_pCamera->SetAcqParam(P_WIDTH_PIXELS,m_dwResolutionX);
	m_pCamera->SetAcqParam(P_HEIGHT_PIXELS,m_dwResolutionY);
	m_pCamera->SetAcqParam(P_HORZ_OFF,HorizontalOffset[m_dwHardwareBinningV-1]);
//	m_pCamera->SetAcqParam(P_VERT_OFF,VerticalOffset[m_dwHardwareBinningV-1]);
//	m_pCamera->SetAcqParam(P_COLOR_SPACE_CONV,IFC_CSC_RGB_TO_RGB);
//	m_pCamera->SetAcqParam(P_PIXEL_COLOR,IFC_RGB);

	if( m_pCOMPort->SerialPortCommand(WRITE_BINNING_REGISTER,db.str) ){
		GetCameraAttributes();
		if(!ReallocateFrameBuffer()){
//			PrintMessage(LEVEL_ERROR,"ReallocateFrameBuffer failed");
//			::MessageBox(NULL,"ReallocateFrameBuffer failed","CFrameServer::SetHardwareBinning",MB_OK);
			return(FALSE);
		}
	}
	else{
		PrintMessage(LEVEL_ERROR,"Cannot write WRITE_BINNING_REGISTER to SP");
		return(FALSE);
	}
*/
	return(TRUE);
}

BOOL CFrameServer::SetHardwareBinning(DWORD ulBinning){
	PrintMessage("CFrameServer::SetHardwareBinning 1");
	return(SetHardwareBinning(ulBinning,ulBinning));
}

BOOL CFrameServer::ResetHardware(){
/*
	if(!SetHardwareBinning(m_dwHardwareBinningV,m_dwHardwareBinningH)) return FALSE;
	if(!SetInterFrameTime(m_dwInterFrameTimeUsec)) return FALSE;
	if(!SetIntegrationTime(m_dwIntegrationTimeUsec)) return FALSE;
	if(!SetUserGain(m_dwVideoGain)) return FALSE;
	return(SetUserOffset(m_lPixelOffset));
*/
  return 0;
}

ULONG CFrameServer::MemoryStatus(int iPercent,ULONG *pulAvailablePhysicalB,ULONG *pulTotalPhysicalB,ULONG *pulTotalVirtualB,int *piLoad){
	MEMORYSTATUS structMemoryStatus;
	ULONG ulRequestedMemoryB;
	char str[128];

	GlobalMemoryStatus(&structMemoryStatus);

	if(iPercent<0 || iPercent>100){
		sprintf(str,"Requested memory chunk %i%% is out of bound",iPercent);
		PrintMessage(LEVEL_WARNING,str);
		sprintf(str,"Using default %i%%",DEFAULT_PHYSICAL_MEMORY_TO_USE_PERCENT);
		PrintMessage(LEVEL_WARNING,str);
		ulRequestedMemoryB=(ULONG)(((double)structMemoryStatus.dwTotalPhys)*0.01*DEFAULT_PHYSICAL_MEMORY_TO_USE_PERCENT);
	}
	else{
		ulRequestedMemoryB=(ULONG)(((double)structMemoryStatus.dwTotalPhys)*0.01*iPercent);
	}

	if(ulRequestedMemoryB >= structMemoryStatus.dwAvailPhys){
		sprintf(str,"Memory Requested %luMB > Available %luMB",ulRequestedMemoryB>>20,structMemoryStatus.dwTotalPhys>>20);
		PrintMessage(LEVEL_WARNING,str);
		PrintMessage(LEVEL_WARNING,"Page swapping is possible");
		if(ulRequestedMemoryB >= structMemoryStatus.dwTotalVirtual){
			sprintf(str,"Memory Requested %luMB > Total Virtual %luMB",ulRequestedMemoryB>>20,structMemoryStatus.dwTotalVirtual>>20);
			PrintMessage(LEVEL_ERROR,str);
			PrintMessage(LEVEL_ERROR,"Operation will fail!");
			PrintMessage(LEVEL_ERROR,"How did you get here anyway");
		}
	}
	
	*pulAvailablePhysicalB = structMemoryStatus.dwAvailPhys;
	if(pulTotalPhysicalB) *pulTotalPhysicalB = structMemoryStatus.dwTotalPhys;
	if(pulTotalVirtualB) *pulTotalVirtualB = structMemoryStatus.dwTotalVirtual;
	if(piLoad) *piLoad = structMemoryStatus.dwMemoryLoad;
	return(ulRequestedMemoryB);
}

ULONG CFrameServer::MemoryStatus(int iPercent){
	ULONG ulRequestedMemoryB;
	ULONG ulTotalPhysicalB;
	ULONG ulAvailablePhysicalB;
	ULONG ulTotalVirtualB;
	int iLoad;
	char str[128];

	ulRequestedMemoryB=MemoryStatus(iPercent,&ulAvailablePhysicalB,&ulTotalPhysicalB,&ulTotalVirtualB,&iLoad);

	sprintf(str,"Total Physical %luMB",ulTotalPhysicalB>>20);
	PrintMessage(str);
	sprintf(str,"Available Physical %luMB",ulAvailablePhysicalB>>20); 
	PrintMessage(str);
	sprintf(str,"Total Virtual %luMB",ulTotalVirtualB>>20);
	PrintMessage(str);
	sprintf(str,"Memory Load %i",iLoad);
	PrintMessage(str);
	sprintf(str,"Memory Used by Frame Server %lukB",m_ulMemoryUsedByFrameServerB>>10);
	PrintMessage(str);
//	sprintf(str,"Available Contiguous Memory %luB",m_pFrameGrabber->ContiguousMemAvailable());
	PrintMessage(str);
	return(ulRequestedMemoryB);
}

ULONG CFrameServer::MemoryAvailablePhysical(ULONG *pulTotalPhysicalB){
	ULONG ulAvailablePhysicalB;
	MemoryStatus(0,&ulAvailablePhysicalB,pulTotalPhysicalB);
	return(ulAvailablePhysicalB+m_ulMemoryUsedByFrameServerB);
}

BOOL CFrameServer::StartTriggerThread(int iNEvents){

	PrintMessage("CFrameServer::StartTriggerThread");

/*
  CContImageApp *theApp=(CContImageApp*)AfxGetApp();
	void *pFrameHeaderTemplate;
	ULONG (*pfunExperimentCallback)(WPARAM,LPARAM,double);
	ULONG ul;
	char str[256];
	
	if(m_hTriggerThread){
		PrintMessage(LEVEL_ERROR,"TriggerThread has been started already");
		return(FALSE);
	}
	sprintf(str,"Starting TriggerThread with %i events",iNEvents);
	PrintMessage(LEVEL_NORMAL,str);

	// Ask the application about experiment specific params
	m_ulFrameHeaderSizeB = theApp->m_ulFrameHeaderSize;

	if(!(pFrameHeaderTemplate = theApp->m_pFrameHeaderTemplate)){
		PrintMessage(LEVEL_ERROR,"Frame Header Template pointer is not set");
		return(FALSE);
	}

	if(!(pfunExperimentCallback = theApp->m_pfunExperimentCallback)){
		PrintMessage(LEVEL_ERROR,"Experiment Callback pointer is not set");
		return(FALSE);
	}

	// Craete frame header buffer and fill out the entries m_pbHostFrameHeaderBuffer
	if(!(m_pbHostFrameHeaderBuffer=(BYTE*)realloc((void*)m_pbHostFrameHeaderBuffer,m_ulFrameHeaderSizeB*m_dwNFramesRingBuffer))){
		PrintMessage(LEVEL_ERROR,"Cannot rellocate for m_pbHostFrameHeaderBuffer");
	}

	for(ul=0;ul<m_dwNFramesRingBuffer;ul++){ 
		m_ppbFrameHeaderBufferEntry[ul]=m_pbHostFrameHeaderBuffer+ul*m_ulFrameHeaderSizeB;
		memcpy((void*)(m_ppbFrameHeaderBufferEntry[ul]),pFrameHeaderTemplate,m_ulFrameHeaderSizeB);
	}

	m_bTriggerThreadShutdown = FALSE;
	m_dwTriggerThreadID = 0;

	if(m_piOtherThreadsShutdown) free((void*)m_piOtherThreadsShutdown);
	if(!(m_piOtherThreadsShutdown=(int* volatile)calloc(iNEvents,sizeof(int)))){
		PrintMessage(LEVEL_ERROR,"Cannot allocate for m_piOtherThreadsShutdown");
		return(FALSE);
	}

	if(m_iNEvents){
		for(int i=0;i<m_iNEvents;i++) if(m_phEvents[i]) CloseHandle(m_phEvents[i]);
		free((void*)m_phEvents);
		m_phEvents=NULL;
		m_iNEvents = 0;
	}

	if(iNEvents){
		m_iNEvents = iNEvents;
		if(!(m_phEvents=(HANDLE* volatile)calloc(iNEvents,sizeof(HANDLE)))){
			PrintMessage(LEVEL_ERROR,"Cannot allocate for m_phEvents");
			return(FALSE);
		}
	}
	else{
		m_iNEvents = 0;
		PrintMessage(LEVEL_WARNING,"FS TT has no events");
	}

	for(int i=0;i<iNEvents;i++){
		if(!(m_phEvents[i]=CreateEvent(NULL,TRUE,FALSE,NULL))){
			sprintf(str,"Cannot create event LastError=%lu",GetLastError());
			PrintMessage(LEVEL_ERROR,str);
			for(int j =0;j<i;j++) CloseHandle(m_phEvents[j]);
			free((void*)m_phEvents);
			m_phEvents=NULL;
			m_iNEvents = 0;
			return(FALSE);
		}
	}

	m_ulFrameLockMask = (~0UL)>>(32-iNEvents);

	sprintf(str,"Mask=%lu",m_ulFrameLockMask);
	PrintMessage(LEVEL_NORMAL,str);

	memset((void *)m_pulFrameLockState,0,m_dwNFramesRingBuffer*sizeof(ULONG));
	memset((void *)(&m_structTriggerThreadParams),0,sizeof(m_structTriggerThreadParams));

	m_structTriggerThreadParams.hMsgWnd = AfxGetMainWnd()->m_hWnd;
	m_structTriggerThreadParams.pCamera = m_pCamera;
	m_structTriggerThreadParams.hGrabID = m_hGrabID;
	m_structTriggerThreadParams.dwNFramesRingBuffer = m_dwNFramesRingBuffer;
	m_structTriggerThreadParams.pbShutdown = &m_bTriggerThreadShutdown;
	m_structTriggerThreadParams.piShutdownOther = m_piOtherThreadsShutdown;
	m_structTriggerThreadParams.iNEvents = iNEvents;
	m_structTriggerThreadParams.phEvents = m_phEvents;

	m_structTriggerThreadParams.pulFrameLockState = m_pulFrameLockState;
	m_structTriggerThreadParams.pulFrameLockMask = &m_ulFrameLockMask;
	m_structTriggerThreadParams.ppbFrameHeaderBufferEntry = m_ppbFrameHeaderBufferEntry;
	m_structTriggerThreadParams.pfunExperimentCallback = pfunExperimentCallback;

	m_structTriggerThreadParams.iNframes = theApp->m_nNFrames;
	m_structTriggerThreadParams.dwInterFrameTimeUsec = m_dwInterFrameTimeUsec;

	m_structTriggerThreadParams.pExperimentControl = theApp->m_pExperimentControl;
	pfunExperimentCallback((WPARAM)m_structTriggerThreadParams.pExperimentControl,NULL,0);

	theApp->OnAcquireMiscTest();

	m_dwPriorityClass=GetPriorityClass(GetCurrentProcess());

	if(!SetPriorityClass( GetCurrentProcess(), REALTIME_PRIORITY_CLASS)){
		sprintf(str,"Cannot set FrameServer priority class to REALTIME GetLastError=%lu",GetLastError());
		PrintMessage(LEVEL_ERROR,str);
	}

	m_hTriggerThread = CreateThread(NULL,(DWORD)0x10000,TriggerThread,(LPVOID)&m_structTriggerThreadParams,0x0,&m_dwTriggerThreadID );


	if(!m_hTriggerThread){
		sprintf(str,"Cannot start TriggerThread GetLastError=%lu",GetLastError());
		PrintMessage(LEVEL_ERROR,str);
		for(int i =0;i<iNEvents;i++) CloseHandle(m_phEvents[i]);
		free((void*)m_phEvents);
		m_phEvents=NULL;
		m_iNEvents = 0;
		return(FALSE);
	}

	if(!SetThreadPriority( m_hTriggerThread, THREAD_PRIORITY_TIME_CRITICAL)){
		sprintf(str,"Cannot set TriggerThread priority to TIME_CRITICAL GetLastError=%lu",GetLastError());
		PrintMessage(LEVEL_ERROR,str);
	}
*/
	return(TRUE);
}

BOOL CFrameServer::StopTriggerThread(int iShutdown){
	PrintMessage("CFrameServer::StopTriggerThread");
/*
	char str[128];
	if(m_hTriggerThread){
//		int i;
//		for(i=0;i<m_structTriggerThreadParams.iNEvents;i++) if(m_phEvents[i]) SetEvent(m_phEvents[i]);
		if(!StopGenericThread(&m_hTriggerThread,&m_bTriggerThreadShutdown,m_dwTriggerThreadID,"TriggerThread",NULL,iShutdown)){
			PrintMessage(LEVEL_ERROR,"Failure to stop TriggerThread");
			return(FALSE);
		}
		if(!SetPriorityClass( GetCurrentProcess(), m_dwPriorityClass)){
			sprintf(str,"Cannot reset FrameServer priority class to %i GetLastError=%lu",m_dwPriorityClass,GetLastError());
			PrintMessage(LEVEL_WARNING,str);
		}
		return(TRUE);
	}
	else{
		PrintMessage(LEVEL_WARNING,"TriggerThread is not running");
		return(FALSE);
	}
*/
  return TRUE;
}

BOOL CFrameServer::DequeThread(int iIndex){
/*
	char str[128];
	ULONG ulMask;
	int iCount=0;

	if(iIndex<0 || iIndex>m_structTriggerThreadParams.iNEvents){
		sprintf(str,"Thread %i is out of range (0-%i)", iIndex,m_structTriggerThreadParams.iNEvents);
		PrintMessage(LEVEL_ERROR,str);
		return(FALSE);
	}
	ulMask = 1UL<<iIndex;
	sprintf(str,"CFrameServer::DequeThread %i Mask %#x", iIndex,ulMask);
	PrintMessage(str);
	// Should use a mutex here
	if(m_phEvents[iIndex]){
		CloseHandle(m_phEvents[iIndex]);
		m_phEvents[iIndex] = NULL;
		if(!(m_ulFrameLockMask & ulMask)){
			sprintf(str,"Mask %i had been fixed already",m_ulFrameLockMask);
			PrintMessage(LEVEL_WARNING,str);
		}
		else m_ulFrameLockMask &= ~ulMask;
	}
	else{
		sprintf(str,"Thread %i had been dequed already", iIndex);
		PrintMessage(LEVEL_ERROR,str);
		if((m_ulFrameLockMask & ulMask)){
			m_ulFrameLockMask &= ~ulMask;
			PrintMessage(LEVEL_WARNING,"Fixing lock mask");		
		}
		return(FALSE);
	}

	for(ULONG i=0;i<m_dwNFramesRingBuffer;i++){
		if(m_pulFrameLockState[i] & ulMask){
			iCount++;
			m_pulFrameLockState[i] &= ~ulMask;
		}
	}
	if(iCount){
		sprintf(str,"Unlocked %i frames",iCount);
		PrintMessage(LEVEL_NORMAL,str);
	}

	if(!m_ulFrameLockMask) return(((CContImageApp*)AfxGetApp())->StopGrabbing());
*/
	return(TRUE);
}


#endif  //  #ifdef _DEBUG_NO_CAMERA
