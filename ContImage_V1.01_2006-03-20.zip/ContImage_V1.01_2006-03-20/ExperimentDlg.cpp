// ExperimentDlg.cpp : implementation file
//
// Val: 11-19-2002 fixed updates for Username and SubjectID
 
#include "stdafx.h"
#include "ContImage.h"
#include "ExperimentDlg.h"

#include <shlobj.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExperimentDlg dialog


CExperimentDlg::CExperimentDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExperimentDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExperimentDlg)
	m_nNFrames = 0;
	m_strDataDirectory = _T("\\C:\\TEMP\\");
	m_strLogDirectory = _T("\\C:\\TEMP\\");
	m_iSpatialExperimentBinning = 1;
	m_iTemporalExperimentBinning = 1;
	m_strUserName = _T("val");
	m_sMonth = 1;
	m_sDay = 1;
	m_sYear = 0;
	m_sExperimentNumber = 0;
	m_sExperimentRun = 0;
	m_strFileName = _T("T_011.00");
	m_iExperimentContinuousMode = -1;
	m_iTotalExperimentBinning = 1;
	m_iDataType = -1;
	m_nWaveLength = 510;
	m_strComments = _T("");
	m_strSubjectID = _T("");
	m_dStimulationPeriod = 0.0;
	m_dStimulationCycles = 0.0;
	m_nNFramesStim = 0;
	m_nNFramesITI = 0;
	m_nNFramesBlank = 0;
	m_nNBinnedFramesStim = 0;
	m_nNBinnedFramesITI = 0;
	m_nNBinnedFramesBlank = 0;
	m_nNConditions = 0;
	m_nNRepetitions = 0;
	m_bRandomize = FALSE;
	m_fNConditionsTime = 0.0f;
	m_fNRepetitionsTime = 0.0f;
	m_fNFramesStimTime = 0.0f;
	m_fNFramesITITime = 0.0f;
	m_fStimulationTime = 0.0f;
	m_fInterFrameTimeMsec = 0.0f;
	m_nOpticsFocalLengthBottom = 0;
	m_nOpticsFocalLengthTop = 0;
	m_nFilterWidth = 0;
	m_fInterFrameTimeBinnedMsec = 0.0f;
	m_nNBinnedFrames = 0;
	//}}AFX_DATA_INIT
	m_dwMaxCommentCharacters=1;
	m_hFolderBitmap.LoadBitmap(IDB_FOLDER);
	m_bDisableAll=FALSE;
}


void CExperimentDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExperimentDlg)
	DDX_Control(pDX, IDC_LOG_DIRECTORY_BUTTON, m_buttonLogDirectory);
	DDX_Control(pDX, IDC_DATA_DIRECTORY_BUTTON, m_buttonDataDirectory);
	DDX_Control(pDX, IDCANCEL, m_buttonCancel);
	DDX_Control(pDX, IDC_DIRECTORY_LOG_SAME_AS_DATA, m_buttonLogDirectorySameAsData);
	DDX_Text(pDX, IDC_NUMBER_FRAMES, m_nNFrames);
	DDX_Text(pDX, IDC_DIRECTORY_DATA, m_strDataDirectory);
	DDX_Text(pDX, IDC_DIRECTORY_LOG, m_strLogDirectory);
	DDX_Text(pDX, IDC_BINNING_SPATIAL, m_iSpatialExperimentBinning);
	DDV_MinMaxInt(pDX, m_iSpatialExperimentBinning, 1, 512);
	DDX_Text(pDX, IDC_BINNING_TEMPORAL, m_iTemporalExperimentBinning);
	DDV_MinMaxInt(pDX, m_iTemporalExperimentBinning, 1, 64);
	DDX_Text(pDX, IDC_USERNAME, m_strUserName);
	DDV_MaxChars(pDX, m_strUserName, 16);
	DDX_Text(pDX, IDC_MONTH, m_sMonth);
	DDV_MinMaxInt(pDX, m_sMonth, 1, 12);
	DDX_Text(pDX, IDC_DAY, m_sDay);
	DDV_MinMaxInt(pDX, m_sDay, 1, 31);
	DDX_Text(pDX, IDC_YEAR, m_sYear);
	DDV_MinMaxInt(pDX, m_sYear, 0, 99);
	DDX_Text(pDX, IDC_EXPERIMENT_NUMBER, m_sExperimentNumber);
	DDV_MinMaxInt(pDX, m_sExperimentNumber, 0, FILENAME_SCHEME_MAX-1);
//	DDV_MinMaxInt(pDX, m_sExperimentNumber, 0, 15);
	DDX_Text(pDX, IDC_EXPERIMENT_RUN, m_sExperimentRun);
	DDV_MinMaxInt(pDX, m_sExperimentRun, 0, FILENAME_SCHEME_MAX-1);
//	DDV_MinMaxInt(pDX, m_sExperimentRun, 0, 15);
	DDX_Text(pDX, IDC_FILENAME, m_strFileName);
	DDV_MaxChars(pDX, m_strFileName, 8);
	DDX_Radio(pDX, IDC_RADIO_CONTINUOUS, m_iExperimentContinuousMode);
	DDX_Text(pDX, IDC_BINNING_TOTAL, m_iTotalExperimentBinning);
	DDX_Radio(pDX, IDC_DATATYPE_UCHAR, m_iDataType);
	DDX_Text(pDX, IDC_WAVE_LENGTH, m_nWaveLength);
	DDX_Text(pDX, IDC_COMMENTS, m_strComments);
	DDV_MaxChars(pDX, m_strComments, m_dwMaxCommentCharacters);
	DDX_Text(pDX, IDC_SUBJECT_ID, m_strSubjectID);
	DDV_MaxChars(pDX, m_strSubjectID, 16);
	DDX_Text(pDX, IDC_STIMULUS_PERIOD, m_dStimulationPeriod);
	DDX_Text(pDX, IDC_STIMULUS_NCYCLES, m_dStimulationCycles);
	DDX_Text(pDX, IDC_NFRAMES_STIM, m_nNFramesStim);
	DDX_Text(pDX, IDC_NFRAMES_ITI, m_nNFramesITI);
	DDX_Text(pDX, IDC_NFRAMES_TOTAL, m_nNFramesTotal);
	DDX_Text(pDX, IDC_NFRAMES_PRE_POST, m_nNFramesBlank);
	DDX_Text(pDX, IDC_NBINNED_FRAMES_STIM, m_nNBinnedFramesStim);
	DDX_Text(pDX, IDC_NBINNED_FRAMES_ITI, m_nNBinnedFramesITI);
	DDX_Text(pDX, IDC_NBINNED_FRAMES_TOTAL, m_nNBinnedFramesTotal);
	DDX_Text(pDX, IDC_NBINNED_FRAMES_PRE_POST, m_nNBinnedFramesBlank);
	DDX_Text(pDX, IDC_NCONDITIONS, m_nNConditions);
	DDX_Text(pDX, IDC_NREPETITIONS, m_nNRepetitions);
	DDX_Check(pDX, IDC_RANDOMIZE, m_bRandomize);
	DDX_Text(pDX, IDC_NCONDITIONS_TIME, m_fNConditionsTime);
	DDX_Text(pDX, IDC_NREPETITIONS_TIME, m_fNRepetitionsTime);
	DDX_Text(pDX, IDC_NFRAMES_STIM_TIME, m_fNFramesStimTime);
	DDX_Text(pDX, IDC_NFRAMES_ITI_TIME, m_fNFramesITITime);
	DDX_Text(pDX, IDC_NFRAMES_TOTAL_TIME, m_fNFramesTotalTime);
	DDX_Text(pDX, IDC_NFRAMES_PRE_POST_TIME, m_fNFramesBlankTime);
	DDX_Text(pDX, IDC_STIMULUS_TIME, m_fStimulationTime);
	DDX_Text(pDX, IDC_INTERFRAME_TIME, m_fInterFrameTimeMsec);
	DDX_Text(pDX, IDC_OPTICS_LENS_BOTTOM, m_nOpticsFocalLengthBottom);
	DDX_Text(pDX, IDC_OPTICS_LENS_TOP, m_nOpticsFocalLengthTop);
	DDX_Text(pDX, IDC_FILTER_WIDTH, m_nFilterWidth);
	DDX_Text(pDX, IDC_INTERFRAME_TIME_BINNED, m_fInterFrameTimeBinnedMsec);
	DDX_Text(pDX, IDC_NUMBER_TBINNED_FRAMES, m_nNBinnedFrames);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExperimentDlg, CDialog)
	//{{AFX_MSG_MAP(CExperimentDlg)
	ON_BN_CLICKED(IDC_DIRECTORY_LOG_SAME_AS_DATA, OnDirectoryLogSameAsData)
	ON_EN_UPDATE(IDC_DIRECTORY_DATA, OnUpdateDirectoryData)
	ON_WM_PAINT()
	ON_EN_UPDATE(IDC_NBINNED_FRAMES_STIM, OnUpdateNframesStim)
	ON_EN_UPDATE(IDC_NBINNED_FRAMES_ITI, OnUpdateNframesITI)
	ON_EN_UPDATE(IDC_NBINNED_FRAMES_PRE_POST, OnUpdateNframesBlank)
	ON_EN_UPDATE(IDC_NCONDITIONS, OnUpdateNConditions)
	ON_EN_UPDATE(IDC_NREPETITIONS, OnUpdateNRepetitions)
	ON_BN_CLICKED(IDC_DATA_DIRECTORY_BUTTON, OnDataDirectoryButton)
	ON_BN_CLICKED(IDC_LOG_DIRECTORY_BUTTON, OnLogDirectoryButton)
	ON_EN_UPDATE(IDC_USERNAME, OnUpdateUsername)
	ON_EN_UPDATE(IDC_SUBJECT_ID, OnUpdateSubjectId)
	//}}AFX_MSG_MAP
	ON_CONTROL_RANGE(EN_UPDATE, IDC_YEAR, IDC_EXPERIMENT_RUN, OnUpdateYMDNumRun)
	ON_CONTROL_RANGE(EN_UPDATE, IDC_BINNING_SPATIAL, IDC_BINNING_TEMPORAL, OnUpdateBinning)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_RADIO_CONTINUOUS, IDC_RADIO_EPISODIC, OnUpdateExperimentContinuousMode)
	ON_CONTROL_RANGE(EN_KILLFOCUS, IDC_STIMULUS_PERIOD, IDC_STIMULUS_NCYCLES, OnKillfocusStimulusParameters)
	ON_CONTROL_RANGE(EN_KILLFOCUS, IDC_OPTICS_LENS_TOP, IDC_OPTICS_LENS_BOTTOM, OnKillfocusOptics)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExperimentDlg message handlers


BOOL CExperimentDlg::OnInitDialog(){
	CDialog::OnInitDialog();

	m_buttonDataDirectory.SetBitmap((HBITMAP)(m_hFolderBitmap));
	m_buttonLogDirectory.SetBitmap((HBITMAP)(m_hFolderBitmap));
	m_buttonLogDirectorySameAsData.SetCheck(m_strDataDirectory == m_strLogDirectory);
	OnDirectoryLogSameAsData();

	OnUpdateBinning(IDC_BINNING_SPATIAL);

	if(IDC_RADIO_CONTINUOUS+m_iExperimentContinuousMode == IDC_RADIO_CONTINUOUS){
		OnUpdateNframesStim();
	}
	else{
		OnKillfocusStimulusParameters(0);
	}
	OnUpdateExperimentContinuousMode(IDC_RADIO_CONTINUOUS+m_iExperimentContinuousMode);
	OnKillfocusOptics(0);
	DisableAll(m_bDisableAll);
	return TRUE; 
}


void CExperimentDlg::OnUpdateUsername(){
		UpdateData (TRUE);
}

void CExperimentDlg::OnUpdateSubjectId(){
		UpdateData (TRUE);
}

void CExperimentDlg::OnDirectoryLogSameAsData(){
	if(m_buttonLogDirectorySameAsData.GetCheck()){
		UpdateData (TRUE);
		m_strLogDirectory=m_strDataDirectory;
		GetDlgItem(IDC_DIRECTORY_LOG)->EnableWindow(FALSE);
		GetDlgItem(IDC_LOG_DIRECTORY_BUTTON)->ShowWindow(SW_HIDE);//EnableWindow(FALSE);
		UpdateData(FALSE);
	}
	else{
		GetDlgItem(IDC_DIRECTORY_LOG)->EnableWindow(TRUE);
		GetDlgItem(IDC_LOG_DIRECTORY_BUTTON)->ShowWindow(SW_SHOW);//EnableWindow(FALSE);
	}
}

void CExperimentDlg::OnUpdateDirectoryData(){
	if(m_buttonLogDirectorySameAsData.GetCheck()){
		UpdateData (TRUE);
		m_strLogDirectory=m_strDataDirectory;
		UpdateData (FALSE);
	}
}

void CExperimentDlg::OnUpdateYMDNumRun(UINT nID){
	int iPos = nID - IDC_YEAR + FILENAME_TAG_OFFSET;
	UpdateData (TRUE);
	switch(nID){
	case IDC_YEAR:
		m_strFileName.SetAt(iPos,NumberToChar(m_sYear%10));
		break;
	case IDC_MONTH:
		m_strFileName.SetAt(iPos,NumberToChar(m_sMonth));
		break;
	case IDC_DAY:
		m_strFileName.SetAt(iPos,NumberToChar(m_sDay));
		break;
	case IDC_EXPERIMENT_NUMBER:
		m_strFileName.SetAt(iPos+1,NumberToChar(m_sExperimentNumber));
		break;
	case IDC_EXPERIMENT_RUN:
		m_strFileName.SetAt(iPos+1,NumberToChar(m_sExperimentRun));
		break;
	}
	UpdateData (FALSE);
}

void CExperimentDlg::OnUpdateBinning(UINT nID){
	UpdateData (TRUE);

	m_iTotalExperimentBinning=m_iTemporalExperimentBinning*m_iSpatialExperimentBinning*m_iSpatialExperimentBinning;
	if(m_iTotalExperimentBinning > 16){
		GetDlgItem(IDC_DATATYPE_ULONG)->EnableWindow(TRUE);
		GetDlgItem(IDC_DATATYPE_FLOAT)->EnableWindow(TRUE);	
	}
	else{
		if(m_iDataType > DEFAULT_DATATYPE-DATATYPE_UCHAR){
			m_iDataType=DEFAULT_DATATYPE-DATATYPE_UCHAR;
		}
		GetDlgItem(IDC_DATATYPE_ULONG)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATATYPE_FLOAT)->EnableWindow(FALSE);
	}
	m_fInterFrameTimeBinnedMsec = m_fInterFrameTimeMsec*m_iTemporalExperimentBinning;
	UpdateData (FALSE);
	if(IDC_RADIO_CONTINUOUS+m_iExperimentContinuousMode == IDC_RADIO_CONTINUOUS){
		OnKillfocusStimulusParameters(0);
	}
	else{
		OnUpdateNframesStim();
	}
}

void CExperimentDlg::OnUpdateExperimentContinuousMode(UINT nID){
	GetDlgItem(IDC_STIMULUS_PERIOD)->EnableWindow(nID == IDC_RADIO_CONTINUOUS);
	GetDlgItem(IDC_STIMULUS_NCYCLES)->EnableWindow(nID == IDC_RADIO_CONTINUOUS);
	GetDlgItem(IDC_STIMULUS_TIME)->EnableWindow(nID == IDC_RADIO_CONTINUOUS);

	GetDlgItem(IDC_NBINNED_FRAMES_STIM)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_STIM)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_STIM_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_NBINNED_FRAMES_ITI)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_ITI)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_ITI_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_NBINNED_FRAMES_TOTAL)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_TOTAL)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_TOTAL_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_NBINNED_FRAMES_PRE_POST)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_PRE_POST)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NFRAMES_PRE_POST_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_NCONDITIONS)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NCONDITIONS_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_NREPETITIONS)->EnableWindow(nID == IDC_RADIO_EPISODIC);
	GetDlgItem(IDC_NREPETITIONS_TIME)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	GetDlgItem(IDC_RANDOMIZE)->EnableWindow(nID == IDC_RADIO_EPISODIC);

	if(nID == IDC_RADIO_CONTINUOUS){
		OnKillfocusStimulusParameters(0);
	}
	else{
		OnUpdateNframesStim();
	}
}

void CExperimentDlg::OnUpdateNframesStim(){
	UpdateData (TRUE);
	m_nNFramesStim=m_nNBinnedFramesStim*m_iTemporalExperimentBinning;
	m_fNFramesStimTime=(float)(1.0e-3*(double)m_dwInterFrameTimeUsec*m_nNFramesStim);
	UpdateData (FALSE);
	OnUpdateNframesITI();
}

void CExperimentDlg::OnUpdateNframesITI(){
	UpdateData (TRUE);
	m_nNFramesITI=m_nNBinnedFramesITI*m_iTemporalExperimentBinning;
	m_fNFramesITITime=(float)(1.0e-3*(double)m_dwInterFrameTimeUsec*m_nNFramesITI);
	m_nNBinnedFramesTotal=m_nNBinnedFramesStim+m_nNBinnedFramesITI;
	m_nNFramesTotal=m_nNFramesStim+m_nNFramesITI;
	m_fNFramesTotalTime=m_fNFramesITITime+m_fNFramesStimTime;
	UpdateData (FALSE);
	OnUpdateNframesBlank();
}

void CExperimentDlg::OnUpdateNframesBlank(){
	UpdateData (TRUE);
	m_nNFramesBlank=m_nNBinnedFramesBlank*m_iTemporalExperimentBinning;
	m_fNFramesBlankTime=(float)(1.0e-3*(double)m_dwInterFrameTimeUsec*m_nNFramesBlank);
	UpdateData (FALSE);
	OnUpdateNConditions();
}

void CExperimentDlg::OnUpdateNConditions(){
	UpdateData (TRUE);
	m_fNConditionsTime=(float)(1.0e-6*(double)m_dwInterFrameTimeUsec*(m_nNFramesStim+m_nNFramesITI)*m_nNConditions);
	UpdateData (FALSE);
	OnUpdateNRepetitions();
}

void CExperimentDlg::OnUpdateNRepetitions(){
	UpdateData (TRUE);
	m_fNRepetitionsTime=m_fNConditionsTime*m_nNRepetitions;
	m_nNFrames=(m_nNRepetitions*m_nNConditions*(m_nNFramesStim+m_nNFramesITI))+m_nNFramesBlank+m_nNFramesBlank;
	m_nNBinnedFrames = m_nNFrames/m_iTemporalExperimentBinning;
	UpdateData (FALSE);
}

void CExperimentDlg::OnKillfocusStimulusParameters(UINT nID){
	if(m_buttonCancel.GetState() == 0x70) return;
	UpdateData (TRUE);
	if(nID == IDC_STIMULUS_PERIOD){
		if(m_dStimulationPeriod < 0.0){
			GetDlgItem(nID)->SetFocus();
			return;
		}
	}
	if(nID == IDC_STIMULUS_NCYCLES){
		if(m_dStimulationCycles < 0.0){
			GetDlgItem(nID)->SetFocus();
			return;
		}
	}
	if(m_dStimulationPeriod > 0.0 && m_dStimulationCycles > 0.0){
		m_fStimulationTime=(float)(m_dStimulationPeriod*m_dStimulationCycles);
		m_nNFrames=(UINT)(1.0e+6*(double)m_fStimulationTime/(double)(m_dwInterFrameTimeUsec));
		m_nNBinnedFrames = m_nNFrames/m_iTemporalExperimentBinning;
	}
	UpdateData (FALSE);
}

void CExperimentDlg::OnKillfocusOptics(UINT nID){
	if(m_buttonCancel.GetState() == 0x70) return;
	UpdateData (TRUE);
	if(m_nOpticsFocalLengthBottom != 0){
		char str[32];
		float fOpticalMagnification=(float)m_nOpticsFocalLengthTop/(float)m_nOpticsFocalLengthBottom;
		sprintf(str,"%.2f",fOpticalMagnification);
		GetDlgItem(IDC_OPTICAL_MAGNIFICATION)->SetWindowText(str);
	}
	UpdateData (FALSE);
}



void CExperimentDlg::OnDataDirectoryButton(){
	m_strDataDirectory = DirectoryButtonDlg("Select Data Directory",m_strDataDirectory.GetBuffer(0));
	UpdateData (FALSE);
	OnUpdateDirectoryData();
}

void CExperimentDlg::OnLogDirectoryButton(){
	m_strLogDirectory = DirectoryButtonDlg("Select Log Directory",m_strLogDirectory.GetBuffer(0));
	UpdateData (FALSE);
}

int CALLBACK BrowseCallbackProc(HWND hwnd,UINT uMsg,LPARAM lp, LPARAM pData){
	switch(uMsg) {
	case BFFM_INITIALIZED:
	SendMessage(hwnd,BFFM_SETSELECTION,TRUE,pData);
		break;
	}
	return(0);
}

char* CExperimentDlg::DirectoryButtonDlg(char *pcTitle,char *pcInitDir){

	CString strPath;
	static char pBuffer[MAX_PATH]={"\0"};
	char *pChar = pcInitDir;
	LPMALLOC pMalloc;

	if (::SHGetMalloc(&pMalloc) == NOERROR){
		BROWSEINFO structBroseInfo;
		ITEMIDLIST* pItemIDList;
		structBroseInfo.hwndOwner = GetSafeHwnd();
		structBroseInfo.pidlRoot = NULL;
		structBroseInfo.pszDisplayName = pBuffer;
		structBroseInfo.lpszTitle = _T(pcTitle);
		structBroseInfo.ulFlags = BIF_RETURNFSANCESTORS | BIF_RETURNONLYFSDIRS;
		structBroseInfo.lpfn = BrowseCallbackProc;
		structBroseInfo.lParam = (LPARAM)pcInitDir;
		if((pItemIDList = ::SHBrowseForFolder(&structBroseInfo))){
			if(::SHGetPathFromIDList(pItemIDList, pBuffer)){
				int i;
				if(pBuffer[(i=strlen(pBuffer))-1] != '\\'){
					pBuffer[i]='\\';
					pBuffer[i+1]='\0';
				}
				pChar=pBuffer;
			}
			else PrintMessage(LEVEL_WARNING,"Cannot access this directory");
			pMalloc->Free(pItemIDList);
		}
		pMalloc->Release();
	}
	return(pChar);
}

void CExperimentDlg::DisableAll(BOOL bDisable){
	if(bDisable){
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDC_USERNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_BINNING_SPATIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_BINNING_TEMPORAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_DIRECTORY_DATA)->EnableWindow(FALSE);
		GetDlgItem(IDC_DIRECTORY_LOG)->EnableWindow(FALSE);
		GetDlgItem(IDC_DIRECTORY_LOG_SAME_AS_DATA)->EnableWindow(FALSE);
		GetDlgItem(IDC_YEAR)->EnableWindow(FALSE);
		GetDlgItem(IDC_MONTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_DAY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EXPERIMENT_NUMBER)->EnableWindow(FALSE);
		GetDlgItem(IDC_EXPERIMENT_RUN)->EnableWindow(FALSE);
		GetDlgItem(IDC_FILENAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_CONTINUOUS)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_EPISODIC)->EnableWindow(FALSE);
		GetDlgItem(IDC_BINNING_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATATYPE_UCHAR)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATATYPE_USHORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATATYPE_ULONG)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATATYPE_FLOAT)->EnableWindow(FALSE);
		GetDlgItem(IDC_OPTICAL_MAGNIFICATION)->EnableWindow(FALSE);
		GetDlgItem(IDC_WAVE_LENGTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_NREPETITIONS)->EnableWindow(FALSE);
		GetDlgItem(IDC_NCONDITIONS)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_STIM)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_ITI)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_PRE_POST)->EnableWindow(FALSE);
		GetDlgItem(IDC_NBINNED_FRAMES_STIM)->EnableWindow(FALSE);
		GetDlgItem(IDC_NBINNED_FRAMES_ITI)->EnableWindow(FALSE);
		GetDlgItem(IDC_NBINNED_FRAMES_TOTAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_NBINNED_FRAMES_PRE_POST)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_ITI_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_STIM_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_TOTAL_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_NFRAMES_PRE_POST_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_NCONDITIONS_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_NREPETITIONS_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_RANDOMIZE)->EnableWindow(FALSE);
		GetDlgItem(IDC_STIMULUS_PERIOD)->EnableWindow(FALSE);
		GetDlgItem(IDC_STIMULUS_NCYCLES)->EnableWindow(FALSE);
		GetDlgItem(IDC_STIMULUS_TIME)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMMENTS)->EnableWindow(FALSE);
		GetDlgItem(IDC_SUBJECT_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_OPTICS_LENS_TOP)->EnableWindow(FALSE);
		GetDlgItem(IDC_OPTICS_LENS_BOTTOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_FILTER_WIDTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_DATA_DIRECTORY_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_LOG_DIRECTORY_BUTTON)->EnableWindow(FALSE);
	}
}


void CExperimentDlg::OnPaint(){
	CPaintDC dc(this); 
	CRect r1,r2;
	CPoint p1,p2;

	CPen *hPen = new CPen(PS_SOLID | PS_JOIN_BEVEL | PS_ENDCAP_ROUND,1,RGB(0,0,255));
	dc.SelectObject(hPen);

	GetDlgItem(IDC_DIRECTORY_LOG_SAME_AS_DATA)->GetWindowRect(&r1);
	ScreenToClient(&r1);
	GetDlgItem(IDC_DIRECTORY_DATA)->GetWindowRect(&r2);
	ScreenToClient(&r2);

	p1.x=(r1.left+r1.right)/2;
	p1.y=r1.top;
	p2.x=r2.left;
	p2.y=(r2.top+r2.bottom)/2;

	dc.MoveTo(p2);
	dc.LineTo(p1.x,p2.y);
	dc.LineTo(p1);

	GetDlgItem(IDC_DIRECTORY_LOG)->GetWindowRect(&r2);
	ScreenToClient(&r2);

	p1.y=r1.bottom;
	p2.x=r2.left;
	p2.y=(r2.top+r2.bottom)/2;

	dc.MoveTo(p2);
	dc.LineTo(p1.x,p2.y);
	dc.LineTo(p1);

	// Arrow head
	p1.x=6;
	p1.y=2;
	p2.x-=1;

	dc.MoveTo(p2);
	dc.LineTo(p2.x-p1.x,p2.y-p1.y);
	dc.MoveTo(p2);
	dc.LineTo(p2.x-p1.x,p2.y+p1.y);

	delete(hPen);
}

