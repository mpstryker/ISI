// SerialPortControl.cpp: implementation of the CSerialPortControl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ContImage.h"
#include "SerialPortControl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


const BYTE pbCommandReadControlRegistert[1]={
	COMMAND_READ_CONTROL_REGISTER};

const BYTE pbCommandReadCameraType[1]={
	COMMAND_READ_CAMERA_TYPE};

const BYTE pbCommandReadFirmwareRevision[1]={
	COMMAND_READ_FIRMWARE_REVISION};

const BYTE pbCommandReadUserOffset[2]={
	COMMAND_READ_LSB_USER_OFFSET,
	COMMAND_READ_MSB_USER_OFFSET};

const BYTE pbCommandReadUserGain[2]={
	COMMAND_READ_LSB_USER_GAIN,
	COMMAND_READ_MSB_USER_GAIN};


const BYTE pbCommandWriteSoftReset[1]={
	COMMAND_WRITE_SOFT_RESET};

const BYTE pbCommandWriteCameraReset[1]={
	COMMAND_WRITE_CAMERA_RESET};

const BYTE pbCommandWriteControlRegister[1]={
	COMMAND_WRITE_CONTROL_REGISTER};

const BYTE pbCommandWriteBinningRegister[1]={
	COMMAND_WRITE_BINNING_REGISTER};

const BYTE pbCommandWriteUserOffset[2]={
	COMMAND_WRITE_LSB_USER_OFFSET,
	COMMAND_WRITE_MSB_USER_OFFSET};

const BYTE pbCommandWriteUserGain[2]={
	COMMAND_WRITE_LSB_USER_GAIN,
	COMMAND_WRITE_MSB_USER_GAIN};

const BYTE pbCommandWriteIntegrationTime[3]={
	COMMAND_WRITE_INTEGRATION_TIME0,
	COMMAND_WRITE_INTEGRATION_TIME1,
	COMMAND_WRITE_INTEGRATION_TIME2};

const BYTE pbCommandWriteFrameRate[3]={
	COMMAND_WRITE_FRAME_RATE0,
	COMMAND_WRITE_FRAME_RATE1,
	COMMAND_WRITE_FRAME_RATE2};

CSerialPortControl::CSerialPortControl(){
	m_bCOMPortReady	= FALSE;
	m_dwAccess		= GENERIC_READ | GENERIC_WRITE;
	m_dwCreation	= OPEN_EXISTING;
	m_dwFlags		= FILE_ATTRIBUTE_NORMAL;
	if((m_hCOMPort=CreateFile(DEFAULT_COM_PORT,m_dwAccess,0,NULL,m_dwCreation,m_dwFlags,NULL)) != (HANDLE)(-1)){
		if(m_bCOMPortReady	= GetCommState(m_hCOMPort,&m_DCB)){
			m_DCB.BaudRate	= CBR_9600;
			m_DCB.ByteSize	= 8;
			m_DCB.StopBits	= ONESTOPBIT;           
			m_DCB.Parity	= NOPARITY;
			m_DCB.fAbortOnError = TRUE;

			m_CommTimeouts.ReadIntervalTimeout = 50;
			m_CommTimeouts.ReadTotalTimeoutConstant = 50;
			m_CommTimeouts.ReadTotalTimeoutMultiplier = 10;
			m_CommTimeouts.WriteTotalTimeoutConstant = 50;
			m_CommTimeouts.WriteTotalTimeoutMultiplier = 10;


			m_bCOMPortReady	= SetCommState(m_hCOMPort,&m_DCB) && SetCommTimeouts (m_hCOMPort, &m_CommTimeouts);
		}
	}
}

CSerialPortControl::~CSerialPortControl(){
	CloseHandle(m_hCOMPort);
}



BOOL CSerialPortControl::SerialPortCommand(SERIAL_PORT_COMMAND spCommand,BYTE *pbValue){
	switch(spCommand){
	case READ_CONTROL_REGISTER:
	case READ_CAMERA_TYPE:
	case READ_FIRMWARE_REVISION:
	case READ_USER_OFFSET:
	case READ_USER_GAIN:
		return(SerialPortCommandRead(spCommand,pbValue));

	case WRITE_SOFT_RESET:
	case WRITE_CAMERA_RESET:
	case WRITE_USER_OFFSET:
	case WRITE_USER_GAIN:
	case WRITE_CONTROL_REGISTER:
	case WRITE_BINNING_REGISTER:
	case WRITE_INTEGRATION_TIME:
	case WRITE_FRAME_RATE:
		return(SerialPortCommandWrite(spCommand,pbValue));

	default:
		char str[128];
		sprintf(str,"Unknown command=%u",spCommand);
		PrintMessage(LEVEL_ERROR,str);
		return FALSE;
	}
}

BOOL CSerialPortControl::SerialPortCommandRead(SERIAL_PORT_COMMAND spCommand,BYTE *pbValue){
	const BYTE* pbCommand;
	DWORD dwNumberOfBytes;
	int iByteCount;
	int i;

	switch(spCommand){
	case READ_CONTROL_REGISTER:
		pbCommand=pbCommandReadControlRegistert;
		iByteCount=sizeof(pbCommandReadControlRegistert);
		break;
	case READ_CAMERA_TYPE:
		pbCommand=pbCommandReadCameraType;
		iByteCount=sizeof(pbCommandReadCameraType);
		break;
	case READ_FIRMWARE_REVISION:
		pbCommand=pbCommandReadFirmwareRevision;
		iByteCount=sizeof(pbCommandReadFirmwareRevision);
		break;
	case READ_USER_OFFSET:
		pbCommand=pbCommandReadUserOffset;
		iByteCount=sizeof(pbCommandReadUserOffset);
		break;
	case READ_USER_GAIN:
		pbCommand=pbCommandReadUserGain;
		iByteCount=sizeof(pbCommandReadUserGain);
		break;
	default:
		char str[128];
		sprintf(str,"Unknown read command=%u",spCommand);
		PrintMessage(LEVEL_ERROR,str);
		return FALSE;
	}

	for(i=0;i<iByteCount;i++){
		if(!WriteFile(m_hCOMPort, pbCommand,1,&dwNumberOfBytes,NULL)) return(SerialPortCommandWriteError(0));
		if(dwNumberOfBytes!=1) return(SerialPortCommandWriteError(1));

		if(!ReadFile(m_hCOMPort, pbValue+i, 1, &dwNumberOfBytes, NULL)) return(SerialPortCommandReadError(0));
		if(dwNumberOfBytes!=1) return(SerialPortCommandReadError(1));
	}
	return TRUE;
}

BOOL CSerialPortControl::SerialPortCommandWrite(SERIAL_PORT_COMMAND spCommand,BYTE *pbValue){
	const BYTE* pbCommand;
	BYTE pbCommandValue[2];
	DWORD dwNumberOfBytes;
	int iByteCount;
	int i;

	switch(spCommand){
	case WRITE_SOFT_RESET:
		if(!WriteFile(m_hCOMPort, pbCommandWriteSoftReset,1,&dwNumberOfBytes,NULL)) return(SerialPortCommandWriteError(0));
		if(dwNumberOfBytes!=1) return(SerialPortCommandWriteError(1));
		return(TRUE);
	case WRITE_CAMERA_RESET:
		if(!WriteFile(m_hCOMPort, pbCommandWriteCameraReset,1,&dwNumberOfBytes,NULL)) return(SerialPortCommandWriteError(0));
		if(dwNumberOfBytes!=1) return(SerialPortCommandWriteError(1));
		return(TRUE);
	case WRITE_CONTROL_REGISTER:
		pbCommand=pbCommandWriteControlRegister;
		iByteCount=sizeof(pbCommandWriteControlRegister);
		break;
	case WRITE_BINNING_REGISTER:
		pbCommand=pbCommandWriteBinningRegister;
		iByteCount=sizeof(pbCommandWriteBinningRegister);
		break;
	case WRITE_USER_OFFSET:
		pbCommand=pbCommandWriteUserOffset;
		iByteCount=sizeof(pbCommandWriteUserOffset);
		break;
	case WRITE_USER_GAIN:
		pbCommand=pbCommandWriteUserGain;
		iByteCount=sizeof(pbCommandWriteUserGain);
		break;
	case WRITE_INTEGRATION_TIME:
		pbCommand=pbCommandWriteIntegrationTime;
		iByteCount=sizeof(pbCommandWriteIntegrationTime);
		break;
	case WRITE_FRAME_RATE:
		pbCommand=pbCommandWriteFrameRate;
		iByteCount=sizeof(pbCommandWriteFrameRate);
		break;
	default:
		char str[128];
		sprintf(str,"Unknown write command=%u",spCommand);
		PrintMessage(LEVEL_ERROR,str);
		return FALSE;
	}

	for(i=0;i<iByteCount;i++){
		pbCommandValue[0]=*(pbCommand+i);
		pbCommandValue[1]=*(pbValue+i);
		if(!WriteFile(m_hCOMPort, pbCommandValue,2,&dwNumberOfBytes,NULL)) return(SerialPortCommandWriteError(0));
		if(dwNumberOfBytes!=2) return(SerialPortCommandWriteError(2));
	}
	return TRUE;

}

BOOL CSerialPortControl::SerialPortCommandReadError(int iError){
	char str[128];
	switch(iError){
	case 0:
		sprintf(str,"Cannot read from serial port, LastError=%u",GetLastError());
		break;
	case 1:
		sprintf(str,"Could not read a byte from serial port, LastError=%u",GetLastError());
		break;
	}
	PrintMessage(LEVEL_ERROR,str);
	PrintMessage(LEVEL_ERROR,"Make sure that camera is on and connected to the right COM port");
	return FALSE;
}

BOOL CSerialPortControl::SerialPortCommandWriteError(int iError){
	char str[128];
	switch(iError){
	case 0:
		sprintf(str,"Cannot write to serial port, LastError=%u",GetLastError());
		break;
	case 1:
		sprintf(str,"Could not write a byte to serial port, LastError=%u",GetLastError());
		break;
	case 2:
		sprintf(str,"Could not write 2 bytes to serial port, LastError=%u",GetLastError());
		break;
	}
	PrintMessage(LEVEL_ERROR,str);
	PrintMessage(LEVEL_ERROR,"Make sure you connected to the right COM port");
	return FALSE;
}

