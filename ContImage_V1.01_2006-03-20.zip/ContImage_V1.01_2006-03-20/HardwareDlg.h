#if !defined(AFX_HARDWAREDLG_H__9D8F4F9C_6512_485F_8FD5_FC1BFA6CC8B0__INCLUDED_)
#define AFX_HARDWAREDLG_H__9D8F4F9C_6512_485F_8FD5_FC1BFA6CC8B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// HardwareDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHardwareDlg dialog

class CHardwareDlg : public CDialog
{
// Construction
public:
	CHardwareDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHardwareDlg)
	enum { IDD = IDD_HARDWARE_DIALOG };
	CButton	m_buttonResetToDefaults;
	CButton	m_buttonCancel;
	CButton	m_buttonHardwareMaxIntegrationTime;
	DWORD	m_dwHardwareBinning;
	DWORD	m_dwHardwareGain;
	long	m_lHardwareOffset;
	double	m_dHardwareFrameRate;
	DWORD	m_dwHardwareIntegrationTime;
	DWORD	m_dwHardwareInterFrameTime;
	DWORD	m_dwHardwareResolution;
	float	m_fHardwareMaxFrameRate;
	DWORD	m_dwHardwareMaxInterFrameTime;
	DWORD	m_dwHardwareMinInterFrameTime;
	int		m_iTotalPhysicalMB;
	int		m_iAvailablePhysicalMB;
	UINT	m_nPhysicalMemoryUsageMB;
	int		m_iPhysicalMemoryUsagePercent;
	int		m_iRadioMemoryAllocationOption;
	UINT	m_nPhysicalMemoryUsageFrames;
	//}}AFX_DATA

	DWORD	m_dwHardwareMinDataShiftTime;
	float	m_fHardwareMinFrameRate;
	BOOL	m_bHardwareResetCamera;

	ULONG	m_ulTotalPhysicalB;
	ULONG	m_ulAvailablePhysicalB;
	ULONG	m_ulAllowedPhysicalB;
	ULONG	m_ulPhysicalMemoryUsageB;
	ULONG	m_ulFrameSizeB;
	ULONG	m_ulMaxFrames;

	BOOL  m_bDisableAll;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHardwareDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHardwareDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHardwareMaxIntegrationTime();
	afx_msg void OnPaint();
	afx_msg void OnKillfocusHardwareBinning();
	afx_msg void OnResetToDefaults();
	afx_msg void OnKillfocusHardwareIntegrationTime();
	afx_msg void OnKillfocusMemoryUsageFrames();
	afx_msg void OnKillfocusMemoryUsagePercent();
	//}}AFX_MSG
	afx_msg void OnKillfocusInterFrameTimeAndFrameRate(UINT nID);
	afx_msg void OnUpdateMemoryAllocationOption(UINT nID);
	DECLARE_MESSAGE_MAP()

	void CalculateInterFrameTimeAndFrameRate(UINT nID);
	void CalculateHardwareBinning();
	void CalculateFrameSize();
	void CalculateMaxFrames();

	void DisableAll(BOOL bDisable);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HARDWAREDLG_H__9D8F4F9C_6512_485F_8FD5_FC1BFA6CC8B0__INCLUDED_)
