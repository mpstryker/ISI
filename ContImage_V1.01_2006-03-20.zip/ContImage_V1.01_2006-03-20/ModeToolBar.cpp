// ModeToolBar.cpp : implementation file
//

#include "stdafx.h"
#include "ContImage.h"
#include "ModeToolBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// Mode Toolbar button definitions: arrays and titles

static UINT BASED_CODE ModeToolBarFocus[] =
{
	ID_SEPARATOR,
	ID_FOCUS_GREEN,
	ID_FOCUS_EXPOSURE,
	ID_FOCUS_RUN,
	ID_FOCUS_STOP,
	ID_FOCUS_SAVE,
	ID_SEPARATOR,
	ID_FOCUS_DISPLAY,
};

static UINT BASED_CODE ModeToolBarROI[] =
{	
	ID_SEPARATOR,
	ID_ROI_ADD,
	ID_ROI_REMOVE,
	ID_ROI_CANCEL,
	ID_ROI_EDIT,
};

static UINT BASED_CODE ModeToolBarExperiment[] =
{
	ID_SEPARATOR,
	ID_EXPERIMENT_RUN,
	ID_EXPERIMENT_PAUSE,
	ID_EXPERIMENT_STOP,
	ID_EXPERIMENT_ABORT,
	ID_SEPARATOR,
	ID_EXPERIMENT_DISPLAY,
};

static UINT BASED_CODE *ModeToolBar[]=
{
	ModeToolBarFocus,
	ModeToolBarROI,
	ModeToolBarExperiment,
};

static int piModeToolBarButtonCount[]=
{
	sizeof(ModeToolBarFocus)/sizeof(UINT),
	sizeof(ModeToolBarROI)/sizeof(UINT),
	sizeof(ModeToolBarExperiment)/sizeof(UINT),
};

static char ModeToolBarFocusTitle[]={"Focus"};
static char ModeToolBarROITitle[]={"ROI"};
static char ModeToolBarExperimentTitle[]={"Experiment"};

static char *ModeToolBarTitle[]={
	ModeToolBarFocusTitle,
	ModeToolBarROITitle,
	ModeToolBarExperimentTitle,
};

/////////////////////////////////////////////////////////////////////////////
// CModeToolBar

CModeToolBar::CModeToolBar(){
	m_nModeToolBar = -1;//INIT_TOOLBAR;
	m_hFont = NULL;
	m_sizeImage.cx=48;
	m_sizeImage.cy=16;
	m_sizeButton.cx=m_sizeImage.cx+7;
	m_sizeButton.cy=m_sizeImage.cy+6;
	m_hFocusBitmap.LoadBitmap(IDB_FOCUS_STATIC);
	m_hExperimentBitmap.LoadBitmap(IDB_EXPERIMENT_STATIC);
}

CModeToolBar::~CModeToolBar(){
}


BEGIN_MESSAGE_MAP(CModeToolBar, CToolBar)
	//{{AFX_MSG_MAP(CModeToolBar)
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

BOOL CModeToolBar::Create( CWnd* pParentWnd, DWORD dwStyle, UINT nID){
	CFont font;
	if(font.CreatePointFont(90, "DEFAULT", NULL)) m_hFont = (HFONT)font.Detach();

	if (!CToolBar::Create(pParentWnd, dwStyle | CBRS_TOOLTIPS | CBRS_FLYBY /*| CBRS_SIZE_DYNAMIC*/) ||
		!ReloadToolBar(INIT_TOOLBAR,TRUE)){
		return FALSE;
	}
	SetWindowText(_T(ModeToolBarTitle[m_nModeToolBar]));

	return TRUE;	
}

/////////////////////////////////////////////////////////////////////////////
// CModeToolBar message handlers

BOOL CModeToolBar::ReloadToolBar(UINT nBarIndex,int iDisplayFrames){
	if(m_nModeToolBar != nBarIndex){
		m_nModeToolBar = nBarIndex;
		SetSizes(m_sizeButton, m_sizeImage);
//		SetHeight(m_sizeButton.cy+10);
		SetButtons(ModeToolBar[m_nModeToolBar], piModeToolBarButtonCount[m_nModeToolBar]);
		LoadBitmap(IDB_FOCUS+m_nModeToolBar); 
		int i;
		CRect rect;
		BITMAP	structBitMap;
		if(m_nModeToolBar == 0){
			m_wndMode.DestroyWindow();
			SetButtonInfo(0, 0, TBBS_SEPARATOR ,28);
			GetItemRect(0, &rect);
			m_hFocusBitmap.GetBitmap(&structBitMap);
			rect.left+=3;
			rect.top+=3;
			rect.right=rect.left+structBitMap.bmWidth;
			rect.bottom=rect.top+structBitMap.bmHeight;
			if (!m_wndMode.Create("F",WS_CHILD|WS_VISIBLE|SS_BITMAP|SS_CENTERIMAGE,rect, this)){
				PrintMessage(LEVEL_ERROR,"Failed to create Mode static");        
				TRACE0("Failed to create Mode static\n");        
				return FALSE; 
			}
			m_wndMode.SetBitmap((HBITMAP)(m_hFocusBitmap));

			m_wndDisplay.DestroyWindow();
			for(i=0;GetItemID(i) != ID_FOCUS_DISPLAY;i++);
			SetButtonInfo(i, ID_FOCUS_DISPLAY, TBBS_SEPARATOR ,60);
			GetItemRect(i, &rect);
			if (!m_wndDisplay.Create("Display",BS_CHECKBOX|WS_CHILD|WS_VISIBLE, 
				rect, this,ID_FOCUS_DISPLAY)){
				PrintMessage(LEVEL_ERROR,"Failed to create Display check-box");        
				TRACE0("Failed to create Display check-box\n");        
				return FALSE; 
			}
			m_wndDisplay.SendMessage(WM_SETFONT,(WPARAM)m_hFont,TRUE);
			m_wndDisplay.SetCheck(iDisplayFrames);
		}

		if(m_nModeToolBar == 2){
			m_wndMode.DestroyWindow();
			SetButtonInfo(0, 0, TBBS_SEPARATOR ,28);
			GetItemRect(0, &rect);
			m_hExperimentBitmap.GetBitmap(&structBitMap);
			rect.left+=3;
			rect.top+=3;
			rect.right=rect.left+structBitMap.bmWidth;
			rect.bottom=rect.top+structBitMap.bmHeight;
			if (!m_wndMode.Create("E",WS_CHILD|WS_VISIBLE|SS_BITMAP|SS_CENTERIMAGE,rect, this)){
				PrintMessage(LEVEL_ERROR,"Failed to create Mode static");        
				TRACE0("Failed to create Mode static\n");        
				return FALSE; 
			}
			m_wndMode.SetBitmap((HBITMAP)(m_hExperimentBitmap));

			m_wndDisplay.DestroyWindow();
			for(i=0;GetItemID(i) != ID_EXPERIMENT_DISPLAY;i++);
			SetButtonInfo(i, ID_EXPERIMENT_DISPLAY, TBBS_SEPARATOR ,60);
			GetItemRect(i, &rect);
			if (!m_wndDisplay.Create("Display",BS_CHECKBOX|WS_CHILD|WS_VISIBLE, 
				rect, this,ID_EXPERIMENT_DISPLAY)){
				PrintMessage(LEVEL_ERROR,"Failed to create Display check-box");        
				TRACE0("Failed to create Display check-box\n");        
				return FALSE; 
			}
			m_wndDisplay.SendMessage(WM_SETFONT,(WPARAM)m_hFont,TRUE);
			m_wndDisplay.SetCheck(iDisplayFrames);
		}

		if(IsFloating() && GetParentFrame()->IsKindOf(RUNTIME_CLASS(CMiniDockFrameWnd))){
			m_pDockBar->SetWindowText(_T(ModeToolBarTitle[m_nModeToolBar]));
		}
		else{
			SetWindowText(_T(ModeToolBarTitle[m_nModeToolBar]));
		}
		GetParentFrame()->DelayRecalcLayout();
		
		PrintMessage(ModeToolBarTitle[m_nModeToolBar]);
		return TRUE;
	}
	else return FALSE;
}
