#if !defined(AFX_CANVASWND_H__AC2700EB_3293_4834_853C_D46B1FCC7221__INCLUDED_)
#define AFX_CANVASWND_H__AC2700EB_3293_4834_853C_D46B1FCC7221__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CanvasWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCanvasWnd window

class CCanvasWnd : public CWnd
{
    DECLARE_DYNAMIC(CCanvasWnd);
// Construction
public:
	CCanvasWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCanvasWnd)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual BOOL Create(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hwndParent, HMENU nIDorHMenu = NULL, LPVOID lpParam = NULL );
	virtual BOOL Create(int iNumber, int x,int y, int iWidth, int iHeight, HWND hwndParent,LPCTSTR lpszClassName,  char *strWindowName);
	virtual BOOL Create(int iNumber, int x,int y, HWND hwndParent,LPCTSTR lpszClassName, char *strWindowName);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCanvasWnd();

	void CreateCanvasBitmap();
	void UpdateCanvasBitmap(ULONG ulBins,ULONG *pulVals);

	// Generated message map functions
protected:
	//{{AFX_MSG(CCanvasWnd)
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	char* m_strWindowName;
	HWND  m_hMsgWnd;
	ULONG* m_pulBuffer;
	CBitmap*	m_pLocalBitmap;
	ULONG m_ulWidth,m_ulHeight;
	ULONG m_ulMax,m_ulMaxC;

public:
	CBitmap*	m_pBitmap;
	

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CANVASWND_H__AC2700EB_3293_4834_853C_D46B1FCC7221__INCLUDED_)
