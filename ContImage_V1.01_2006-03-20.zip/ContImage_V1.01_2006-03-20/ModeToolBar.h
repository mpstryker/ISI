#if !defined(AFX_MODETOOLBAR_H__95857098_D6D6_4103_BDC7_478FEC93EFEC__INCLUDED_)
#define AFX_MODETOOLBAR_H__95857098_D6D6_4103_BDC7_478FEC93EFEC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ModeToolBar.h : header file
//

#define TOOLBAR_FOCUS		0 
#define TOOLBAR_ROI			1 
#define TOOLBAR_EXPERIMENT	2 
#define INIT_TOOLBAR		TOOLBAR_FOCUS

/////////////////////////////////////////////////////////////////////////////
// CModeToolBar window

class CModeToolBar : public CToolBar
{
// Construction
public:
	CModeToolBar();

// Attributes
public:

	UINT m_nModeToolBar; 
	SIZE m_sizeButton;
	SIZE m_sizeImage;

	CButton m_wndDisplay;
	CStatic m_wndMode;

	CBitmap m_hFocusBitmap;
	CBitmap m_hExperimentBitmap;

	HFONT	m_hFont;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModeToolBar)
	//}}AFX_VIRTUAL
BOOL Create( CWnd* pParentWnd, DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_TOP, UINT nID = AFX_IDW_TOOLBAR );


// Implementation
public:
	BOOL ReloadToolBar(UINT,int);
	virtual ~CModeToolBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CModeToolBar)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODETOOLBAR_H__95857098_D6D6_4103_BDC7_478FEC93EFEC__INCLUDED_)
