// SynchDIO.h: interface for the CSynchDIO class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNCHDIO_H__CB76D8C9_76FE_4E88_9236_5FCE18E6C3F1__INCLUDED_)
#define AFX_SYNCHDIO_H__CB76D8C9_76FE_4E88_9236_5FCE18E6C3F1__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "cbw.h"

#define N_PHYSICAL_PORTS	4
#define N_LOGICAL_PORTS		N_PHYSICAL_PORTS

typedef struct PHYSICAL_PORT{
	int iSeqPortNum;
	int iBoardNum;
	int iPort;
	int iDirection; // None, In, Out
	USHORT usBitCount;
	USHORT usBitMask;
	int  (*pfunWrite)(ULONG);
	int  (*pfunRead)(ULONG&);
} PHYSICAL_PORT;

typedef struct LOGICAL_PORT{
	int iNumPhysicalPorts;
	struct PHYSICAL_PORT *ppPhysicalPorts[N_PHYSICAL_PORTS];
	int iDirection;
} LOGICAL_PORT;

typedef struct LOGICAL_EXTENDED_PORT{
	int iNumPhysicalPorts;
	struct PHYSICAL_PORT *ppPhysicalPorts[N_PHYSICAL_PORTS];
	int iDirection;
	USHORT	*piBitCount;
	USHORT	**ppiBitMask;
} LOGICAL_EXTENDED_PORT;


#define BOARD_NUM	1

class CSynchDIO{
public:
	CSynchDIO();
	virtual ~CSynchDIO();

	PHYSICAL_PORT m_PhysicalPorts[N_PHYSICAL_PORTS];
	LOGICAL_PORT m_LogicalPorts[N_PHYSICAL_PORTS];
	LOGICAL_EXTENDED_PORT *m_pLogicalExtendedPorts;

	int m_iNumLogicalPorts;


	int InitPhysicalPorts();
	void InitLogicalPorts();

	int WritePhysicalPort(int iPhysicalPort,USHORT usData);
	int ReadPhysicalPort(int iPhysicalPort,USHORT& usData);

	int WriteLogicalPort(int iLogicalPort,ULONG ulData);
	int ReadLogicalPort(int iLogicalPort,ULONG& ulData);

	int DIO_Open();
	int DIO_Close();

	inline int DIO_WriteA(USHORT usDIO_Data){return(cbDOut (BOARD_NUM, FIRSTPORTA, usDIO_Data));}
	inline int DIO_WriteCL(USHORT usDIO_Data){return(cbDOut (BOARD_NUM, FIRSTPORTCL, usDIO_Data));}  
	inline int DIO_ReadB(USHORT *pusDIO_Data){return(cbDIn (BOARD_NUM, FIRSTPORTB, pusDIO_Data));}
	inline int DIO_ReadCH(USHORT *pusDIO_Data){return(cbDIn (BOARD_NUM, FIRSTPORTCH, pusDIO_Data));}
};

#endif // !defined(AFX_SYNCHDIO_H__CB76D8C9_76FE_4E88_9236_5FCE18E6C3F1__INCLUDED_)
